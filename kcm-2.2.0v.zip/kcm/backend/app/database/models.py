import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.database import Base


def new_id() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    conversations: Mapped[list["Conversation"]] = relationship(back_populates="user")


class Conversation(Base):
    __tablename__ = "conversations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="New conversation")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    user: Mapped[User] = relationship(back_populates="conversations")
    messages: Mapped[list["Message"]] = relationship(
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="Message.created_at",
    )


class Message(Base):
    __tablename__ = "messages"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    conversation_id: Mapped[str] = mapped_column(
        ForeignKey("conversations.id", ondelete="CASCADE"), index=True
    )
    role: Mapped[str] = mapped_column(String(16))  # system | user | assistant | (tool, later)
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    # KCM 2.2 optional context metadata (all nullable: 2.1 rows stay valid)
    importance: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0..1; >= protected_importance is protected
    token_count: Mapped[int | None] = mapped_column(Integer, nullable=True)  # cached tokenizer count of `content`
    embedding_reference: Mapped[str | None] = mapped_column(String(64), nullable=True)  # key in the embedding cache

    conversation: Mapped[Conversation] = relationship(back_populates="messages")


class LLMRequest(Base):
    """One row per LLM call; lets KCM later measure token savings."""

    __tablename__ = "llm_requests"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    conversation_id: Mapped[str | None] = mapped_column(
        ForeignKey("conversations.id", ondelete="SET NULL"), index=True, nullable=True
    )
    request_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    provider: Mapped[str] = mapped_column(String(32))
    model: Mapped[str] = mapped_column(String(100))
    input_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    latency_ms: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(16))  # ok | error
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    streamed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ConversationSummary(Base):
    """KCM 2.2: one rolling summary per conversation. Original messages are never deleted."""

    __tablename__ = "conversation_summaries"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    conversation_id: Mapped[str] = mapped_column(
        ForeignKey("conversations.id", ondelete="CASCADE"), unique=True, index=True
    )
    summary: Mapped[str] = mapped_column(Text)
    covered_message_start: Mapped[int] = mapped_column(Integer)  # position in the conversation (0-based)
    covered_message_end: Mapped[int] = mapped_column(Integer)  # inclusive
    token_count: Mapped[int] = mapped_column(Integer)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ContextTraceRow(Base):
    """KCM 2.2: one row per AI request, so context management can be measured (spec section 22)."""

    __tablename__ = "context_traces"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    request_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    conversation_id: Mapped[str | None] = mapped_column(
        ForeignKey("conversations.id", ondelete="SET NULL"), index=True, nullable=True
    )
    original_message_count: Mapped[int] = mapped_column(Integer)
    selected_message_count: Mapped[int] = mapped_column(Integer)
    original_token_count: Mapped[int] = mapped_column(Integer)
    selected_token_count: Mapped[int] = mapped_column(Integer)
    summary_used: Mapped[bool] = mapped_column(Boolean, default=False)
    summary_tokens: Mapped[int] = mapped_column(Integer, default=0)
    historical_messages_selected: Mapped[int] = mapped_column(Integer, default=0)
    historical_messages_removed: Mapped[int] = mapped_column(Integer, default=0)
    compression_level: Mapped[int] = mapped_column(Integer)
    context_build_ms: Mapped[float] = mapped_column(Float)
    tokenizer_exact: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
