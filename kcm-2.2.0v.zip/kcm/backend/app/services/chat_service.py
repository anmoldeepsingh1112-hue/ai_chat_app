from collections.abc import AsyncIterator

from app.core.config import Settings
from app.orchestrator.engine import EngineEvent, KCMEngine
from app.orchestrator.prompt_builder import validate_user_message
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.conversation_service import ConversationService


class ChatService:
    def __init__(self, conversations: ConversationService, engine: KCMEngine, settings: Settings):
        self.conversations = conversations
        self.engine = engine
        self.settings = settings

    async def _resolve(self, user_id: str, req: ChatRequest) -> tuple[str, str]:
        text = validate_user_message(req.message, self.settings.max_message_chars)  # before creating anything
        if req.conversation_id:
            await self.conversations.get(user_id, req.conversation_id)  # 404 if missing / not yours
            return req.conversation_id, text
        return (await self.conversations.create(user_id)).id, text

    async def send(self, user_id: str, req: ChatRequest) -> ChatResponse:
        conv_id, text = await self._resolve(user_id, req)
        result = await self.engine.process_message(conv_id, text, user_id)
        return ChatResponse(conversation_id=conv_id, message_id=result.message.id, content=result.message.content)

    async def stream(self, user_id: str, req: ChatRequest) -> AsyncIterator[EngineEvent]:
        conv_id, text = await self._resolve(user_id, req)
        async for event in self.engine.stream_message(conv_id, text, user_id):
            yield event
