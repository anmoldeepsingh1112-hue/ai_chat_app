from datetime import datetime

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.errors import ConversationNotFoundError
from app.database.models import ContextTraceRow, Conversation, ConversationSummary, Message, User, utcnow


class ConversationService:
    """All queries are scoped by user_id (user isolation)."""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def ensure_user(self, user_id: str) -> None:
        if await self.session.get(User, user_id) is None:
            self.session.add(User(id=user_id))
            await self.session.commit()

    async def create(self, user_id: str, title: str | None = None) -> Conversation:
        await self.ensure_user(user_id)
        conv = Conversation(user_id=user_id, title=(title or "New conversation")[:200])
        self.session.add(conv)
        await self.session.commit()
        return conv

    async def list(self, user_id: str) -> list[Conversation]:
        q = select(Conversation).where(Conversation.user_id == user_id).order_by(Conversation.updated_at.desc())
        return list((await self.session.scalars(q)).all())

    async def get(self, user_id: str, conversation_id: str, with_messages: bool = False) -> Conversation:
        q = select(Conversation).where(Conversation.id == conversation_id, Conversation.user_id == user_id)
        if with_messages:
            # populate_existing: a session that already holds this conversation must not serve stale messages
            q = q.options(selectinload(Conversation.messages)).execution_options(populate_existing=True)
        conv = (await self.session.scalars(q)).first()
        if conv is None:
            raise ConversationNotFoundError()
        return conv

    async def delete(self, user_id: str, conversation_id: str) -> None:
        conv = await self.get(user_id, conversation_id)
        await self.session.execute(delete(Message).where(Message.conversation_id == conv.id))
        await self.session.execute(delete(ConversationSummary).where(ConversationSummary.conversation_id == conv.id))
        await self.session.execute(delete(ContextTraceRow).where(ContextTraceRow.conversation_id == conv.id))
        await self.session.delete(conv)
        await self.session.commit()

    def add_message(self, conv: Conversation, role: str, content: str, created_at: datetime | None = None,
                    token_count: int | None = None, importance: float | None = None) -> Message:
        msg = Message(conversation_id=conv.id, role=role, content=content, created_at=created_at or utcnow(),
                      token_count=token_count, importance=importance)
        self.session.add(msg)
        return msg
