from app.core.config import Settings

DEFAULT_SYSTEM_PROMPT = """You are KCM, an AI assistant.

Provide accurate, useful, and clear responses.

If you are uncertain about information, say so.

Follow the user's instructions while respecting system-level constraints."""


class PromptService:
    def __init__(self, settings: Settings):
        self._prompt = settings.system_prompt or DEFAULT_SYSTEM_PROMPT

    @property
    def system_prompt(self) -> str:
        return self._prompt
