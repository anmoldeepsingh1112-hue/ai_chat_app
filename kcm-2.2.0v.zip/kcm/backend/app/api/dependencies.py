import hmac
import time
from abc import ABC, abstractmethod
from collections import defaultdict, deque

from fastapi import Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.context.factory import build_context_manager
from app.core.errors import AuthenticationError, NotFoundError, RateLimitExceededError
from app.orchestrator.engine import KCMEngine
from app.orchestrator.prompt_builder import PromptBuilder
from app.services.chat_service import ChatService
from app.services.conversation_service import ConversationService
from app.services.prompt_service import PromptService


# ---- authentication (interface; swap in the Angular app's real auth later) ----
class AuthProvider(ABC):
    @abstractmethod
    async def authenticate(self, request: Request) -> str:
        """Return the authenticated user id or raise AuthenticationError."""


class MockAuthProvider(AuthProvider):
    """Development only. Refused at startup when APP_ENV=production."""

    async def authenticate(self, request: Request) -> str:
        return request.headers.get("X-Mock-User", "dev-user")[:64]


# ---- rate limiting (interface; in-memory now, Redis implementation can drop in) ----
class RateLimiter(ABC):
    @abstractmethod
    async def check(self, key: str) -> None:
        """Raise RateLimitExceededError if the key is over its limit."""


class InMemoryRateLimiter(RateLimiter):
    def __init__(self, limit: int, window_seconds: float = 60.0):
        self.limit, self.window = limit, window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    async def check(self, key: str) -> None:
        now = time.monotonic()
        q = self._hits[key]
        while q and now - q[0] > self.window:
            q.popleft()
        if len(q) >= self.limit:
            raise RateLimitExceededError()
        q.append(now)


async def current_user(request: Request) -> str:
    return await request.app.state.auth_provider.authenticate(request)


async def rate_limited_user(request: Request, user_id: str = Depends(current_user)) -> str:
    await request.app.state.rate_limiter.check(user_id)
    return user_id


async def get_db(request: Request):
    async with request.app.state.session_factory() as session:
        yield session


def get_settings_dep(request: Request) -> Settings:
    return request.app.state.settings


def build_chat_service(app_state, session: AsyncSession) -> ChatService:
    settings: Settings = app_state.settings
    builder = PromptBuilder(PromptService(settings), settings.max_history_messages)
    cm = None
    if settings.context_manager_enabled and getattr(app_state, "context_runtime", None) is not None:
        cm = build_context_manager(app_state.context_runtime, session, app_state.provider, settings, builder.system_prompt)
    engine = KCMEngine(session, app_state.provider, settings, builder, cm)
    return ChatService(ConversationService(session), engine, settings)


async def get_chat_service(request: Request, session: AsyncSession = Depends(get_db)) -> ChatService:
    return build_chat_service(request.app.state, session)


async def get_conversation_service(session: AsyncSession = Depends(get_db)) -> ConversationService:
    return ConversationService(session)


async def require_dev(request: Request, x_kcm_dev_token: str | None = Header(default=None)) -> None:
    """Gate for developer-only endpoints. Answers a plain 404 (not 401/403) so they are not discoverable."""
    settings: Settings = request.app.state.settings
    if not settings.dev_mode:
        raise NotFoundError()
    expected = settings.dev_token.get_secret_value()
    if expected and not hmac.compare_digest(x_kcm_dev_token or "", expected):
        raise NotFoundError()
