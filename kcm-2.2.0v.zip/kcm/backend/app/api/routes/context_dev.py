"""Developer-only context inspection (spec sections 21 and 24). Hidden (404) unless DEV_MODE=true and, when
DEV_TOKEN is set, the X-KCM-Dev-Token header matches. Ownership is still enforced like every other route."""
from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.dependencies import current_user, get_db, require_dev
from app.context import ModelConfig, history_from_db
from app.context.factory import build_context_manager
from app.core.errors import NotFoundError
from app.orchestrator.prompt_builder import PromptBuilder
from app.services.conversation_service import ConversationService
from app.services.prompt_service import PromptService

router = APIRouter(prefix="/conversations", dependencies=[Depends(require_dev)])


async def _setup(request: Request, session: AsyncSession, user_id: str, conversation_id: str):
    st = request.app.state
    if st.context_runtime is None:
        raise NotFoundError()  # context manager disabled
    conv = await ConversationService(session).get(user_id, conversation_id, with_messages=True)
    prompt = PromptBuilder(PromptService(st.settings)).system_prompt
    cm = build_context_manager(st.context_runtime, session, st.provider, st.settings, prompt)
    s = st.settings
    mc = ModelConfig(s.llm_model, s.llm_context_limit, s.llm_max_tokens or s.context_reserved_output_tokens, st.provider.name)
    return cm, mc, history_from_db(conv.messages), prompt


@router.get("/{conversation_id}/context-preview")
async def context_preview(conversation_id: str, request: Request,
                          message: str = Query(default="", max_length=8000),
                          user_id: str = Depends(current_user), session: AsyncSession = Depends(get_db)):
    """What WOULD be sent for the next message. Dry run: persists nothing and never calls the LLM."""
    cm, mc, history, prompt = await _setup(request, session, user_id, conversation_id)
    return await cm.preview(conversation_id, mc, history=history, current_message=message)


@router.post("/{conversation_id}/summarize")
async def summarize(conversation_id: str, request: Request,
                    user_id: str = Depends(current_user), session: AsyncSession = Depends(get_db)):
    """Force-summarize everything older than the recent window (testing). Originals are kept."""
    cm, mc, history, prompt = await _setup(request, session, user_id, conversation_id)
    s = await cm.force_summarize(conversation_id, history)
    if s is None:
        return {"summary": None, "version": 0}
    return {"summary": s.summary, "version": s.version, "covered_message_start": s.covered_message_start,
            "covered_message_end": s.covered_message_end, "token_count": s.token_count}
