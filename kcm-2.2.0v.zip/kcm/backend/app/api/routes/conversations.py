from fastapi import APIRouter, Depends, Response

from app.api.dependencies import current_user, get_conversation_service
from app.schemas.conversation import ConversationCreate, ConversationDetail, ConversationOut
from app.services.conversation_service import ConversationService

router = APIRouter(prefix="/conversations")


@router.post("", response_model=ConversationOut, status_code=201)
async def create_conversation(
    body: ConversationCreate | None = None,
    user_id: str = Depends(current_user),
    svc: ConversationService = Depends(get_conversation_service),
):
    return await svc.create(user_id, body.title if body else None)


@router.get("", response_model=list[ConversationOut])
async def list_conversations(user_id: str = Depends(current_user), svc: ConversationService = Depends(get_conversation_service)):
    return await svc.list(user_id)


@router.get("/{conversation_id}", response_model=ConversationDetail)
async def get_conversation(conversation_id: str, user_id: str = Depends(current_user), svc: ConversationService = Depends(get_conversation_service)):
    return await svc.get(user_id, conversation_id, with_messages=True)


@router.delete("/{conversation_id}", status_code=204)
async def delete_conversation(conversation_id: str, user_id: str = Depends(current_user), svc: ConversationService = Depends(get_conversation_service)):
    await svc.delete(user_id, conversation_id)
    return Response(status_code=204)
