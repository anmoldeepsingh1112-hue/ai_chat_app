"""Chat endpoints.

Streaming uses Server-Sent Events (SSE) framing over a POST response. SSE is plain text over
HTTP (works through proxies, trivially debuggable with curl, no WebSocket infrastructure) and
we only need server->client flow. The browser EventSource API is GET-only, so Angular reads the
stream with fetch() + ReadableStream (see frontend ChatService).
"""
import json
from collections.abc import AsyncIterator

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.exc import SQLAlchemyError

from app.api.dependencies import build_chat_service, get_chat_service, rate_limited_user
from app.core.errors import DatabaseError, KCMError, error_body
from app.core.logging import get_logger
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.chat_service import ChatService

router = APIRouter(prefix="/chat")
logger = get_logger(__name__)


def sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


@router.post("", response_model=ChatResponse)
async def chat(body: ChatRequest, user_id: str = Depends(rate_limited_user), svc: ChatService = Depends(get_chat_service)):
    return await svc.send(user_id, body)


@router.post("/stream")
async def chat_stream(body: ChatRequest, request: Request, user_id: str = Depends(rate_limited_user)):
    app_state = request.app.state

    async def events() -> AsyncIterator[str]:
        # Own session: it must outlive the request handler while the stream is being sent.
        async with app_state.session_factory() as session:
            stream = build_chat_service(app_state, session).stream(user_id, body)
            started = False
            try:
                async for ev in stream:
                    started = True
                    yield sse(ev.type, ev.data)
            except Exception as exc:
                if not started:
                    raise  # before any bytes are sent: becomes a normal HTTP error response
                if isinstance(exc, KCMError):
                    err = exc
                elif isinstance(exc, SQLAlchemyError):
                    err = DatabaseError(detail=repr(exc))
                else:
                    logger.exception("stream_unhandled_error")
                    err = KCMError()
                logger.error("stream_error", extra={"error": err.code, "detail": err.detail or err.message})
                yield sse("error", error_body(err.code, err.message))
            finally:
                await stream.aclose()

    it = events()
    first = await it.__anext__()  # surfaces 404/422/etc. as proper HTTP errors

    async def body() -> AsyncIterator[str]:
        try:
            yield first
            async for chunk in it:
                yield chunk
        finally:
            await it.aclose()

    return StreamingResponse(
        body(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
