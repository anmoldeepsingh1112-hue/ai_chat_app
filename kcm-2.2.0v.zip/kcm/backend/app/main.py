from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.dependencies import InMemoryRateLimiter, MockAuthProvider
from app.api.routes import chat, context_dev, conversations, health
from app.context.factory import build_runtime
from app.core.config import Settings, get_settings
from app.core.errors import register_error_handlers
from app.core.logging import get_logger, setup_logging
from app.core.middleware import BodySizeLimitMiddleware, RequestIdMiddleware
from app.database.database import Base, make_engine, make_session_factory
from app.llm.base import LLMProvider
from app.llm.provider import RetryingProvider, build_provider

logger = get_logger("kcm")


def create_app(settings: Settings | None = None, provider: LLMProvider | None = None) -> FastAPI:
    settings = settings or get_settings()
    setup_logging(settings.log_level)

    auth_provider = MockAuthProvider()
    if settings.app_env.lower() == "production" and isinstance(auth_provider, MockAuthProvider):
        raise RuntimeError("MockAuthProvider must not be used when APP_ENV=production; wire a real AuthProvider.")

    if settings.dev_mode and settings.app_env.lower() == "production" and not settings.dev_token.get_secret_value():
        raise RuntimeError("DEV_MODE in production requires DEV_TOKEN.")

    engine = make_engine(settings.database_url)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if settings.auto_create_tables:
            async with engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
        logger.info("app_started", extra={"env": settings.app_env, "provider": settings.llm_provider})
        try:
            yield
        finally:
            await engine.dispose()

    app = FastAPI(title="KCM 2.2", version="2.2.0", lifespan=lifespan)
    app.state.settings = settings
    app.state.engine = engine
    app.state.session_factory = make_session_factory(engine)
    # Injected providers (tests, alternative wiring) get the same timeout/retry layer as configured ones.
    app.state.provider = (
        RetryingProvider(provider, settings.llm_timeout, settings.max_retries, settings.retry_delay)
        if provider is not None
        else build_provider(settings)
    )
    app.state.context_runtime = build_runtime(settings) if settings.context_manager_enabled else None
    app.state.auth_provider = auth_provider
    app.state.rate_limiter = InMemoryRateLimiter(settings.rate_limit_per_minute)

    # add_middleware: last added is outermost -> request id wraps everything, size limit runs before CORS.
    app.add_middleware(BodySizeLimitMiddleware, max_bytes=settings.max_request_bytes)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,  # explicit list (never "*") so credentials can be allowed
        allow_credentials=True,  # the Angular app sends session cookies (withCredentials / credentials: include)
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["Content-Type", "Authorization", "X-Request-ID", "X-KCM-Dev-Token"],
        expose_headers=["X-Request-ID"],
    )
    app.add_middleware(RequestIdMiddleware)

    register_error_handlers(app)
    app.include_router(health.router, prefix="/api")
    app.include_router(conversations.router, prefix="/api")
    app.include_router(context_dev.router, prefix="/api")
    app.include_router(chat.router, prefix="/api")
    return app


def _default_app() -> FastAPI:
    return create_app()


app = _default_app()
