"""Provider-neutral LLM interface. The rest of KCM only ever imports from here."""
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class ChatMessage:
    role: str  # system | user | assistant
    content: str

    def to_dict(self) -> dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass(frozen=True)
class TokenUsage:
    input_tokens: int | None = None
    output_tokens: int | None = None

    @property
    def total_tokens(self) -> int | None:
        if self.input_tokens is None and self.output_tokens is None:
            return None
        return (self.input_tokens or 0) + (self.output_tokens or 0)


@dataclass(frozen=True)
class LLMResult:
    content: str
    usage: TokenUsage | None = None


@dataclass(frozen=True)
class LLMChunk:
    """Streaming unit: text delta; the final chunk may carry usage (with empty text)."""

    text: str = ""
    usage: TokenUsage | None = None


class LLMProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def generate(
        self,
        messages: Sequence[ChatMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> LLMResult: ...

    @abstractmethod
    def stream(
        self,
        messages: Sequence[ChatMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> AsyncIterator[LLMChunk]: ...
