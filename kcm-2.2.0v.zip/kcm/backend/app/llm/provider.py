"""Provider registry/factory plus the retry + timeout wrapper."""
import asyncio
from collections.abc import AsyncIterator, Callable, Sequence

from app.core.config import Settings
from app.core.errors import InvalidRequestError, LLMError, LLMTimeoutError, StreamInterruptedError
from app.core.logging import get_logger
from app.llm.adapters.mock import MockLLMProvider
from app.llm.adapters.openai_compatible import OpenAICompatibleProvider
from app.llm.base import ChatMessage, LLMChunk, LLMProvider, LLMResult

logger = get_logger(__name__)

ProviderFactory = Callable[[Settings], LLMProvider]
_REGISTRY: dict[str, ProviderFactory] = {}


def register_provider(name: str, factory: ProviderFactory) -> None:
    _REGISTRY[name.lower()] = factory


def _openai(s: Settings) -> LLMProvider:
    key = s.llm_api_key.get_secret_value() if s.llm_api_key else None
    return OpenAICompatibleProvider(key, s.llm_base_url, s.llm_model, s.llm_timeout)


register_provider("mock", lambda s: MockLLMProvider())
register_provider("openai", _openai)
register_provider("openai_compatible", _openai)  # Ollama / LM Studio / vLLM via LLM_BASE_URL


class RetryingProvider(LLMProvider):
    """Adds a hard timeout and bounded retries around any provider.

    Streams are retried only before the first chunk is delivered; after that a failure is
    reported as STREAM_INTERRUPTED (retrying would duplicate text the client already saw).
    """

    def __init__(self, inner: LLMProvider, timeout: float, max_retries: int, retry_delay: float):
        self.inner = inner
        self.name = inner.name
        self.timeout = timeout
        self.max_retries = max(0, max_retries)
        self.retry_delay = retry_delay

    async def _backoff(self, attempt: int, exc: LLMError) -> None:
        logger.warning("llm_retry", extra={"attempt": attempt, "error": exc.code})
        await asyncio.sleep(self.retry_delay * (2 ** (attempt - 1)))

    async def generate(self, messages, model=None, temperature=0.7, max_tokens=None) -> LLMResult:
        attempt = 0
        while True:
            try:
                return await asyncio.wait_for(
                    self.inner.generate(messages, model, temperature, max_tokens), self.timeout
                )
            except asyncio.TimeoutError:
                err: LLMError = LLMTimeoutError(detail=f"no response within {self.timeout}s")
            except LLMError as e:
                err = e
            if not err.retryable or attempt >= self.max_retries:
                raise err
            attempt += 1
            await self._backoff(attempt, err)

    async def stream(self, messages, model=None, temperature=0.7, max_tokens=None) -> AsyncIterator[LLMChunk]:
        attempt = 0
        while True:
            started = False
            it = self.inner.stream(messages, model, temperature, max_tokens).__aiter__()
            err: LLMError | None = None
            try:
                while True:
                    try:
                        chunk = await asyncio.wait_for(it.__anext__(), self.timeout)
                    except StopAsyncIteration:
                        return
                    started = True
                    yield chunk
            except asyncio.TimeoutError:
                err = LLMTimeoutError(detail=f"no data within {self.timeout}s")
            except LLMError as e:
                err = e
            except Exception as e:  # unexpected provider failure
                err = LLMError(detail=repr(e))
            finally:
                aclose = getattr(it, "aclose", None)
                if aclose:
                    await aclose()
            if started:
                raise StreamInterruptedError(detail=err.detail or err.message) from err
            if not err.retryable or attempt >= self.max_retries:
                raise err
            attempt += 1
            await self._backoff(attempt, err)


def build_provider(settings: Settings) -> LLMProvider:
    name = settings.llm_provider.lower()
    factory = _REGISTRY.get(name)
    if factory is None:
        raise InvalidRequestError(f"Unknown LLM_PROVIDER '{name}'. Registered: {sorted(_REGISTRY)}")
    if name == "openai" and not settings.llm_api_key and "api.openai.com" in settings.llm_base_url:
        raise InvalidRequestError("LLM_API_KEY is required for the OpenAI provider.")
    return RetryingProvider(
        factory(settings), settings.llm_timeout, settings.max_retries, settings.retry_delay
    )
