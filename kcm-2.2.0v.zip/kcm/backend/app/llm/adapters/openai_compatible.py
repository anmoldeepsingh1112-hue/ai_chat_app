"""Adapter for any OpenAI-compatible /chat/completions API (OpenAI, Ollama, LM Studio, vLLM, ...)."""
import json
from collections.abc import AsyncIterator, Sequence

import httpx

from app.core.errors import (
    LLMAuthError,
    LLMBadRequestError,
    LLMError,
    LLMRateLimitError,
    LLMTimeoutError,
)
from app.llm.base import ChatMessage, LLMChunk, LLMProvider, LLMResult, TokenUsage


def _raise_for_status(status: int, body: str = "") -> None:
    detail = f"upstream status {status}: {body[:300]}"
    if status in (401, 403):
        raise LLMAuthError(detail=detail)
    if status == 429:
        raise LLMRateLimitError(detail=detail)
    if status in (408, 504):
        raise LLMTimeoutError(detail=detail)
    if status >= 500:
        raise LLMError(detail=detail)
    if status >= 400:
        raise LLMBadRequestError(detail=detail)


def _usage(obj: dict | None) -> TokenUsage | None:
    if not obj:
        return None
    return TokenUsage(obj.get("prompt_tokens"), obj.get("completion_tokens"))


class OpenAICompatibleProvider(LLMProvider):
    name = "openai"

    def __init__(
        self,
        api_key: str | None,
        base_url: str,
        default_model: str,
        timeout: float = 60.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self._api_key = api_key
        self._url = base_url.rstrip("/") + "/chat/completions"
        self._default_model = default_model
        self._timeout = timeout
        self._transport = transport  # injectable for tests

    def __repr__(self) -> str:  # never leak the key
        return f"OpenAICompatibleProvider(url={self._url!r})"

    def _request(self, messages: Sequence[ChatMessage], model, temperature, max_tokens, stream: bool):
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        payload: dict = {
            "model": model or self._default_model,
            "messages": [m.to_dict() for m in messages],
            "temperature": temperature,
            "stream": stream,
        }
        if max_tokens:
            payload["max_tokens"] = max_tokens
        if stream:
            payload["stream_options"] = {"include_usage": True}
        return headers, payload

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(timeout=self._timeout, transport=self._transport)

    async def generate(self, messages, model=None, temperature=0.7, max_tokens=None) -> LLMResult:
        headers, payload = self._request(messages, model, temperature, max_tokens, False)
        try:
            async with self._client() as client:
                r = await client.post(self._url, json=payload, headers=headers)
        except httpx.TimeoutException as e:
            raise LLMTimeoutError(detail=repr(e)) from e
        except httpx.HTTPError as e:
            raise LLMError(detail=repr(e)) from e
        _raise_for_status(r.status_code, r.text)
        try:
            data = r.json()
            return LLMResult(data["choices"][0]["message"]["content"] or "", _usage(data.get("usage")))
        except (KeyError, IndexError, ValueError) as e:
            raise LLMError(detail=f"malformed upstream response: {e!r}") from e

    async def stream(self, messages, model=None, temperature=0.7, max_tokens=None) -> AsyncIterator[LLMChunk]:
        headers, payload = self._request(messages, model, temperature, max_tokens, True)
        usage = None
        try:
            async with self._client() as client:
                async with client.stream("POST", self._url, json=payload, headers=headers) as r:
                    if r.status_code >= 400:
                        body = (await r.aread()).decode(errors="replace")
                        _raise_for_status(r.status_code, body)
                    async for line in r.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        obj = json.loads(data)
                        usage = _usage(obj.get("usage")) or usage
                        choices = obj.get("choices") or []
                        delta = (choices[0].get("delta") or {}).get("content") if choices else None
                        if delta:
                            yield LLMChunk(delta)
        except httpx.TimeoutException as e:
            raise LLMTimeoutError(detail=repr(e)) from e
        except httpx.HTTPError as e:
            raise LLMError(detail=repr(e)) from e
        except json.JSONDecodeError as e:
            raise LLMError(detail=f"malformed stream chunk: {e!r}") from e
        if usage:
            yield LLMChunk("", usage)
