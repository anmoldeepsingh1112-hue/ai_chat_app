import asyncio
import re
from collections.abc import AsyncIterator, Sequence

from app.llm.base import ChatMessage, LLMChunk, LLMProvider, LLMResult, TokenUsage


class MockLLMProvider(LLMProvider):
    """Deterministic provider for tests and key-less local development."""

    name = "mock"

    def __init__(
        self,
        response: str | None = None,
        delay: float = 0.0,
        fail_with: Exception | None = None,
        fail_after_chunks: int | None = None,
        fail_times: int | None = None,
    ):
        self.response = response
        self.delay = delay
        self.fail_with = fail_with
        self.fail_after_chunks = fail_after_chunks  # stream fails after N chunks
        self.fail_times = fail_times  # fail only the first N calls (for retry tests)
        self.calls: list[list[ChatMessage]] = []

    def _text_for(self, messages: Sequence[ChatMessage]) -> str:
        if self.response is not None:
            return self.response
        last = next((m.content for m in reversed(messages) if m.role == "user"), "")
        if last.strip().lower().startswith("hello"):
            return "Hello! I am KCM."
        return f"Mock reply to: {last}"

    def _usage(self, messages: Sequence[ChatMessage], text: str) -> TokenUsage:
        return TokenUsage(sum(len(m.content.split()) for m in messages), len(text.split()))

    def _maybe_fail(self) -> None:
        if self.fail_with is not None and (self.fail_times is None or len(self.calls) <= self.fail_times):
            raise self.fail_with

    async def generate(self, messages, model=None, temperature=0.7, max_tokens=None) -> LLMResult:
        self.calls.append(list(messages))
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail_after_chunks is None:
            self._maybe_fail()
        text = self._text_for(messages)
        return LLMResult(text, self._usage(messages, text))

    async def stream(self, messages, model=None, temperature=0.7, max_tokens=None) -> AsyncIterator[LLMChunk]:
        self.calls.append(list(messages))
        if self.fail_after_chunks is None:
            self._maybe_fail()
        text = self._text_for(messages)
        for i, piece in enumerate(re.findall(r"\S+\s*", text)):
            if self.delay:
                await asyncio.sleep(self.delay)
            if self.fail_after_chunks is not None and i >= self.fail_after_chunks:
                raise self.fail_with or RuntimeError("mock stream failure")
            yield LLMChunk(piece)
        yield LLMChunk("", self._usage(messages, text))
