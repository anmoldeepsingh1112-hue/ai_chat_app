"""Central configuration. Every value comes from environment variables (see .env.example)."""
from functools import lru_cache

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "development"
    database_url: str = "postgresql+asyncpg://kcm:kcm@localhost:5432/kcm"
    redis_url: str = "redis://localhost:6379/0"  # Redis-ready: not used until rate limiting/caching moves there
    auto_create_tables: bool = False  # dev/test convenience; production uses Alembic migrations

    llm_provider: str = "mock"  # mock | openai | openai_compatible
    llm_model: str = "mock-1"
    llm_api_key: SecretStr = SecretStr("")  # never repr'd or logged
    llm_base_url: str = "https://api.openai.com/v1"
    llm_temperature: float = 0.7
    llm_max_tokens: int | None = None
    llm_timeout: float = 30.0
    max_retries: int = 2
    retry_delay: float = 0.5

    log_level: str = "INFO"
    cors_origins: str = "http://localhost:4200"
    max_request_bytes: int = 64 * 1024
    max_message_chars: int = 8000
    max_history_messages: int = 50
    rate_limit_per_minute: int = 60
    system_prompt: str = ""  # empty -> PromptService falls back to DEFAULT_SYSTEM_PROMPT

    # ---- KCM 2.2 context management (all values are tunable heuristics; benchmark before trusting defaults) ----
    context_manager_enabled: bool = True  # False -> exact KCM 2.1 behaviour (last MAX_HISTORY_MESSAGES)
    llm_context_limit: int = 32_000  # context window of LLM_MODEL; set this to the real value for your model
    context_reserved_output_tokens: int = 1024  # used when LLM_MAX_TOKENS is not set
    recent_message_limit: int = Field(default=20, ge=0)
    summary_trigger_tokens: int = Field(default=20_000, ge=0)
    summary_target_tokens: int = Field(default=800, ge=50)
    summary_min_new_messages: int = Field(default=10, ge=1)  # batch incremental summary updates
    max_context_tokens: int | None = None  # optional cap below the model's context window
    context_compression_level: int = Field(default=3, ge=0, le=3)  # 0 none | 1 relevance | 2 summary | 3 both
    context_summarizer: str = "extractive"  # extractive (offline) | llm (uses the configured provider, falls back)
    context_recent_budget_fraction: float = Field(default=0.6, gt=0, le=1)
    context_alpha: float = 0.6  # S = alpha*R + beta*T + gamma*P
    context_beta: float = 0.15
    context_gamma: float = 0.25
    context_recency_half_life: int = Field(default=50, ge=1)
    context_min_relevance: float = Field(default=0.25, ge=0, le=1)
    context_max_relevant_messages: int = Field(default=8, ge=0)
    context_max_protected_messages: int = Field(default=6, ge=0)
    context_protected_importance: float = Field(default=0.8, ge=0, le=1)

    # ---- developer tooling (never enable for normal users) ----
    dev_mode: bool = False  # enables /context-preview, /summarize and context stats in the final stream event
    dev_token: SecretStr = SecretStr("")  # required in X-KCM-Dev-Token whenever set (mandatory in production)

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
