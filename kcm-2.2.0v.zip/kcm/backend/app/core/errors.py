"""Structured application errors. Internal detail is logged, never returned to clients."""
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError

from app.core.logging import get_logger

log = get_logger("kcm.errors")


class KCMError(Exception):
    status_code = 500
    code = "INTERNAL_ERROR"
    message = "An unexpected error occurred."
    retryable = False

    def __init__(self, message: str | None = None, detail: str | None = None):
        super().__init__(message or self.message)
        self.message = message or type(self).message  # safe, user-facing
        self.detail = detail  # internal only: logged, never serialized


class InvalidRequestError(KCMError):
    status_code, code, message = 422, "INVALID_REQUEST", "The request is invalid."


class AuthenticationError(KCMError):
    status_code, code, message = 401, "AUTHENTICATION_REQUIRED", "Authentication is required."


class RateLimitExceededError(KCMError):
    status_code, code, message = 429, "RATE_LIMIT_EXCEEDED", "Too many requests. Please slow down."


class NotFoundError(KCMError):
    status_code, code, message = 404, "NOT_FOUND", "Not found."


class ConversationNotFoundError(KCMError):
    status_code, code, message = 404, "CONVERSATION_NOT_FOUND", "Conversation not found."


class DatabaseError(KCMError):
    status_code, code, message = 500, "DATABASE_ERROR", "A database error occurred."


class LLMError(KCMError):
    status_code, code, message = 502, "LLM_ERROR", "The AI service returned an error."
    retryable = True


class LLMTimeoutError(LLMError):
    status_code, code, message = 504, "LLM_TIMEOUT", "The AI service timed out."


class LLMRateLimitError(LLMError):
    status_code, code, message = 429, "LLM_RATE_LIMIT", "The AI service is rate limited. Try again shortly."


class LLMAuthError(LLMError):
    status_code, code, message = 502, "LLM_AUTH_ERROR", "The AI service rejected our credentials."
    retryable = False


class LLMBadRequestError(LLMError):
    status_code, code, message = 502, "LLM_BAD_REQUEST", "The AI service rejected the request."
    retryable = False


class StreamInterruptedError(LLMError):
    status_code, code, message = 502, "STREAM_INTERRUPTED", "The response stream was interrupted."
    retryable = False


def error_body(code: str, message: str) -> dict:
    return {"error": {"code": code, "message": message}}


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(KCMError)
    async def _kcm(_: Request, exc: KCMError):
        log.warning("handled_error", extra={"error": exc.code, "detail": exc.detail})
        return JSONResponse(error_body(exc.code, exc.message), status_code=exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        log.info("validation_error", extra={"error": "INVALID_REQUEST"})
        return JSONResponse(error_body("INVALID_REQUEST", "The request is invalid."), status_code=422)

    @app.exception_handler(SQLAlchemyError)
    async def _db(_: Request, exc: SQLAlchemyError):
        log.error("database_error", extra={"error": "DATABASE_ERROR", "detail": repr(exc)})
        return JSONResponse(error_body(DatabaseError.code, DatabaseError.message), status_code=500)

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception):
        log.error("unhandled_exception", exc_info=exc)
        return JSONResponse(error_body("INTERNAL_ERROR", "An unexpected error occurred."), status_code=500)
