import re

from app.llm.base import ChatMessage

from .config import ContextConfig
from .relevance import message_importance, tokenize
from .token_manager import TokenManager
from .types import ContextResult


def _norm(t):
    return re.sub(r"\W+", " ", t.lower()).strip()


def _jaccard(a, b):
    a, b = set(tokenize(a)), set(tokenize(b))
    return len(a & b) / len(a | b) if a and b else 0.0


class ContextBuilder:
    """Assembles SYSTEM -> SUMMARY -> RELEVANT HISTORY -> RECENT -> CURRENT and enforces the budget.
    Trim order when over budget (lowest priority first):
      relevant history (lowest score first, protected last) -> summary (oldest lines first) -> recent (oldest first).
    P0 system and P1 current message are never trimmed."""

    def __init__(self, token_manager: TokenManager | None = None, config: ContextConfig | None = None):
        self.tm = token_manager or TokenManager()
        self.cfg = config or ContextConfig()

    def _dedupe(self, summary, recent, relevant):
        removed, kept = [], []
        seen = [_norm(m.content) for m in recent]
        rec_texts = [m.content for m in recent]
        sum_norm = _norm(summary or "")
        for m in relevant:
            n = _norm(m.content)
            dup = (n in seen or (n and n in sum_norm)
                   or any(_jaccard(m.content, r) >= self.cfg.dedup_similarity for r in rec_texts))
            # protected messages (corrections/constraints) keep their chronological position: a stale raw message
            # must never end up AFTER the summary line that supersedes it.
            if dup and message_importance(m) < self.cfg.protected_importance:
                removed.append(m)
            else:
                kept.append(m)
                seen.append(n)
        return kept, removed

    @staticmethod
    def _render(system_prompt, summary, relevant, recent, current):
        msgs = []
        if system_prompt:
            msgs.append(ChatMessage("system", system_prompt))
        if summary:
            msgs.append(ChatMessage("system", "Summary of earlier conversation:\n" + summary))
        if relevant:
            body = "\n".join(f"[{m.role}] {m.content}" for m in relevant)
            msgs.append(ChatMessage("system", "Relevant earlier messages (chronological):\n" + body))
        msgs += [m.to_chat() for m in recent]
        msgs.append(ChatMessage("user", current))
        return msgs

    async def build(self, system_prompt, current_message, recent_messages, summary, relevant_messages,
                    token_budget, scores: dict | None = None) -> ContextResult:
        """token_budget = tokens available for everything EXCEPT the system prompt (TokenManager.calculate_budget).
        The current message counts against it but is never cut."""
        scores = scores or {}
        recent = list(recent_messages)
        relevant, dup_removed = self._dedupe(summary, recent, list(relevant_messages))
        relevant.sort(key=lambda m: m.seq)
        removed = list(dup_removed)
        warnings = []

        def cost():
            return self.tm.count_messages(self._render("", summary, relevant, recent, current_message))

        order = sorted(relevant, key=lambda m: (message_importance(m) >= self.cfg.protected_importance, scores.get(m.id, 0.0)))
        while cost() > token_budget and order:
            m = order.pop(0)
            relevant.remove(m)
            removed.append(m)
        if summary and cost() > token_budget:
            lines = summary.splitlines()
            while lines and cost() > token_budget:
                lines.pop(0)
                summary = "\n".join(lines)
            summary = summary or None
        while cost() > token_budget and recent:
            removed.append(recent.pop(0))
        if cost() > token_budget:
            warnings.append("current_message_exceeds_budget")  # never truncated; the caller decides what to do

        msgs = self._render(system_prompt, summary, relevant, recent, current_message)
        return ContextResult(
            messages=msgs, system_context=system_prompt, recent_messages=recent, summary=summary,
            relevant_messages=relevant, total_tokens=self.tm.count_messages(msgs), available_tokens=token_budget,
            removed_messages=removed, compression_applied=0,
            scores={m.id: scores.get(m.id, 0.0) for m in relevant}, summary_used=bool(summary),
            summary_tokens=self.tm.count_tokens(summary) if summary else 0, historical_messages_used=len(relevant),
            warnings=warnings)
