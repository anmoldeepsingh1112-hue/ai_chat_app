from dataclasses import dataclass


@dataclass
class ContextConfig:
    """Every number here is a tunable heuristic, not a claimed optimum. Env-backed via core.config.Settings."""
    recent_message_limit: int = 20
    summary_trigger_tokens: int = 20_000  # summarize older messages once they exceed this
    summary_target_tokens: int = 800
    summary_min_new_messages: int = 10  # batch incremental updates to save LLM calls
    max_context_tokens: int | None = None  # optional cap below the model's own limit
    compression_level: int = 3  # 0 none | 1 relevance | 2 summary | 3 summary+relevance
    recent_budget_fraction: float = 0.6  # max share of the post-P0/P1 budget for recent messages
    alpha: float = 0.6  # S = alpha*R + beta*T + gamma*P  (engineering heuristic)
    beta: float = 0.15
    gamma: float = 0.25
    recency_half_life: int = 50  # in messages
    min_relevance_score: float = 0.25  # raw similarity below this -> priority 5 (dropped)
    max_relevant_messages: int = 8
    max_protected_messages: int = 6
    protected_importance: float = 0.8  # importance >= this is protected from low-similarity removal
    dedup_similarity: float = 0.95
    per_message_overhead_tokens: int = 4

    @classmethod
    def from_settings(cls, s) -> "ContextConfig":
        return cls(
            recent_message_limit=s.recent_message_limit, summary_trigger_tokens=s.summary_trigger_tokens,
            summary_target_tokens=s.summary_target_tokens, summary_min_new_messages=s.summary_min_new_messages,
            max_context_tokens=s.max_context_tokens, compression_level=s.context_compression_level,
            recent_budget_fraction=s.context_recent_budget_fraction, alpha=s.context_alpha, beta=s.context_beta,
            gamma=s.context_gamma, recency_half_life=s.context_recency_half_life,
            min_relevance_score=s.context_min_relevance, max_relevant_messages=s.context_max_relevant_messages,
            max_protected_messages=s.context_max_protected_messages, protected_importance=s.context_protected_importance,
        )
