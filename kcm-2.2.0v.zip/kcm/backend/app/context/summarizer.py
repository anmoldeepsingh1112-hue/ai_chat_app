import re

from app.core.logging import get_logger
from app.llm.base import ChatMessage, LLMProvider

from .relevance import _CONSTRAINT, _CORRECTION
from .token_manager import TokenManager

logger = get_logger(__name__)

SUMMARY_PROMPT = """You maintain a running summary of a conversation for an AI assistant.
Update the EXISTING SUMMARY with the NEW MESSAGES. Keep only information useful for continuing the conversation:
- current project/task; user requirements and constraints; decisions made (and why); important facts (names, versions, numbers);
- corrections (the latest value wins; note what it replaced); unresolved questions; important terminology.
Never write vague lines like "they discussed many things". Be concrete. Target at most {target} tokens. Output bullets only.

EXISTING SUMMARY:
{existing}

NEW MESSAGES:
{new}
"""

_CUES = re.compile(r"\b(decid|use[sd]?|using|build|project|prefer|want|need|name is|called|version|deadline|goal|plan|because|"
                   r"stack|database|language|framework|api|error|bug|fix|todo|unresolved|open question)\b", re.I)


class LLMSummarizer:
    """Incremental summarizer backed by the app's LLMProvider (existing summary + only the NEW messages)."""

    def __init__(self, provider: LLMProvider, model: str | None = None, temperature: float = 0.2):
        self.provider, self.model, self.temperature = provider, model, temperature
        self.calls = 0

    async def summarize(self, existing, new_messages, target_tokens):
        self.calls += 1
        new = "\n".join(f"[{m.role}] {m.content}" for m in new_messages)
        prompt = SUMMARY_PROMPT.format(target=target_tokens, existing=existing or "(none)", new=new)
        res = await self.provider.generate([ChatMessage("user", prompt)], model=self.model,
                                           temperature=self.temperature, max_tokens=max(256, target_tokens * 2))
        text = (res.content or "").strip()
        if not text:
            raise ValueError("empty summary from LLM")
        return text


class ExtractiveSummarizer:
    """Offline, deterministic, LLM-free incremental summarizer. Keeps sentences that look like decisions, facts,
    constraints, corrections or questions, dedups, and trims to the target size. Lower quality than an LLM summary."""

    def __init__(self, token_manager: TokenManager | None = None):
        self.tm = token_manager or TokenManager()
        self.calls = 0

    @staticmethod
    def _sentences(text):
        return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if len(s.strip()) > 3]

    def _value(self, s, role):
        v = 0.0
        if _CORRECTION.search(s):
            v += 3
        if _CONSTRAINT.search(s):
            v += 2.5
        c = len(_CUES.findall(s))
        if c:
            v += 1.0 + 0.5 * min(c, 3)  # cue density breaks ties between facts and chatter
        if v and s.endswith("?") and role == "user":
            v += 1  # cue-bearing question = possibly unresolved
        if v and role == "user":
            v += 0.5
        return v

    async def summarize(self, existing, new_messages, target_tokens):
        self.calls += 1
        lines = [l[2:] for l in (existing or "").splitlines() if l.startswith("- ")]
        seen = {re.sub(r"\W+", " ", l.lower()).strip() for l in lines}
        for m in new_messages:
            for s in self._sentences(m.content):
                key = re.sub(r"\W+", " ", s.lower()).strip()
                if key in seen or self._value(s, m.role) < 1.5:
                    continue
                seen.add(key)
                lines.append(("[user] " if m.role == "user" else "[assistant] ") + s)

        def cost(ls):
            return sum(self.tm.count_tokens(l) + 2 for l in ls)

        while lines and cost(lines) > target_tokens:  # drop lowest-value (oldest on ties), keep chronology
            vals = [(self._value(l, "user" if l.startswith("[user]") else "assistant"), i) for i, l in enumerate(lines)]
            lines.pop(min(vals)[1])
        return "\n".join("- " + l for l in lines)


class FallbackSummarizer:
    """Try the primary (LLM) summarizer; on ANY failure log and use the offline one. A summary problem must never
    break a chat turn."""

    def __init__(self, primary, fallback):
        self.primary, self.fallback = primary, fallback

    @property
    def calls(self):
        return getattr(self.primary, "calls", 0) + getattr(self.fallback, "calls", 0)

    async def summarize(self, existing, new_messages, target_tokens):
        try:
            return await self.primary.summarize(existing, new_messages, target_tokens)
        except Exception:
            logger.warning("llm_summary_failed_using_extractive", exc_info=True)
            return await self.fallback.summarize(existing, new_messages, target_tokens)
