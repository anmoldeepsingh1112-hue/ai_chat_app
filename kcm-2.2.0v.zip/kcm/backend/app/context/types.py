"""Plain data types for the context layer. No SQLAlchemy / FastAPI imports: the core is unit-testable on its own."""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from app.llm.base import ChatMessage

VALID_ROLES = {"system", "user", "assistant"}


def _now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class ContextMessage:
    id: str
    role: str
    content: str
    seq: int = -1  # position in the conversation (0-based, after role filtering)
    metadata: dict[str, Any] = field(default_factory=dict)  # importance, embedding_reference, ...
    token_count: int | None = None  # cached count (messages.token_count) when known

    def to_chat(self) -> ChatMessage:
        return ChatMessage(self.role, self.content)

    @classmethod
    def from_db(cls, m: Any, seq: int) -> "ContextMessage":
        """Duck-typed on purpose: works for the SQLAlchemy `Message` row or any object with the same attributes."""
        meta: dict[str, Any] = {}
        if getattr(m, "importance", None) is not None:
            meta["importance"] = float(m.importance)
        if getattr(m, "embedding_reference", None):
            meta["embedding_reference"] = m.embedding_reference
        return cls(id=m.id, role=m.role, content=m.content, seq=seq, metadata=meta,
                   token_count=getattr(m, "token_count", None))


def history_from_db(messages) -> list[ContextMessage]:
    """DB rows (chronological) -> context messages. Unknown roles (e.g. a future 'tool') are skipped, as in 2.1."""
    return [ContextMessage.from_db(m, i) for i, m in enumerate(x for x in messages if x.role in VALID_ROLES)]


@dataclass
class ModelConfig:
    name: str
    context_limit: int
    reserved_output_tokens: int = 1024
    provider: str = "generic"


@dataclass
class SummaryState:
    """In-memory form of a `conversation_summaries` row."""
    conversation_id: str
    summary: str
    covered_message_start: int
    covered_message_end: int  # inclusive position
    token_count: int
    version: int = 1
    created_at: datetime = field(default_factory=_now)
    updated_at: datetime = field(default_factory=_now)


@dataclass
class ContextTrace:
    request_id: str
    conversation_id: str
    original_message_count: int
    selected_message_count: int
    original_token_count: int
    selected_token_count: int
    summary_used: bool
    summary_tokens: int
    historical_messages_selected: int
    historical_messages_removed: int
    compression_level: int
    context_build_time: float  # seconds
    summary_updated: bool = False
    current_message_over_budget: bool = False


@dataclass
class ContextResult:
    messages: list[ChatMessage]  # final LLM input, logically ordered
    system_context: str
    recent_messages: list[ContextMessage]
    summary: str | None
    relevant_messages: list[ContextMessage]
    total_tokens: int
    available_tokens: int
    removed_messages: list[ContextMessage]
    compression_applied: int
    scores: dict[str, float] = field(default_factory=dict)
    trace: ContextTrace | None = None
    summary_used: bool = False
    summary_tokens: int = 0
    historical_messages_used: int = 0
    warnings: list[str] = field(default_factory=list)
