"""Wiring: one shared runtime per process (tokenizer, embedder, embedding cache) + one ContextManager per request."""
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.llm.base import LLMProvider

from .config import ContextConfig
from .manager import ContextManager
from .relevance import ContextRelevance, EmbeddingCache, HashingEmbedder
from .sql_store import SqlContextStore
from .summarizer import ExtractiveSummarizer, FallbackSummarizer, LLMSummarizer
from .token_manager import TokenManager


@dataclass
class ContextRuntime:
    config: ContextConfig
    token_manager: TokenManager
    embedder: object
    embedding_cache: EmbeddingCache


def build_runtime(settings: Settings, embedder=None, token_manager: TokenManager | None = None) -> ContextRuntime:
    cfg = ContextConfig.from_settings(settings)
    tm = token_manager or TokenManager(settings.llm_model, per_message_overhead=cfg.per_message_overhead_tokens)
    return ContextRuntime(cfg, tm, embedder or HashingEmbedder(), EmbeddingCache())


def build_context_manager(runtime: ContextRuntime, session: AsyncSession, provider: LLMProvider,
                          settings: Settings, system_prompt: str = "") -> ContextManager:
    extractive = ExtractiveSummarizer(runtime.token_manager)
    summarizer = (FallbackSummarizer(LLMSummarizer(provider, settings.llm_model), extractive)
                  if settings.context_summarizer == "llm" else extractive)
    return ContextManager(
        SqlContextStore(session), runtime.config, runtime.token_manager,
        ContextRelevance(runtime.embedder, runtime.config, runtime.embedding_cache), summarizer, system_prompt)
