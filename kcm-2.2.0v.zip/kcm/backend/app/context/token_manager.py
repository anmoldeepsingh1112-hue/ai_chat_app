import re
from collections.abc import Callable


class TokenManager:
    """Uses tiktoken when installed (exact for OpenAI-style models). Otherwise a heuristic ESTIMATE, which can be
    off for other tokenizers (report `exact` in diagnostics). Pass `counter=` for a provider-specific tokenizer,
    or `safety_margin>1` to stay conservative with the heuristic."""

    _piece = re.compile(r"\w+|[^\w\s]", re.UNICODE)

    def __init__(self, model: str | None = None, counter: Callable[[str], int] | None = None,
                 per_message_overhead: int = 4, safety_margin: float = 1.0):
        self.per_message_overhead = per_message_overhead
        self.safety_margin = safety_margin
        self._counter = counter
        self.exact = counter is not None
        if counter is None:
            try:
                import tiktoken

                try:
                    enc = tiktoken.encoding_for_model(model) if model else tiktoken.get_encoding("cl100k_base")
                except KeyError:
                    enc = tiktoken.get_encoding("cl100k_base")
                self._counter = lambda t: len(enc.encode(t, disallowed_special=()))
                self.exact = True
            except Exception:  # tiktoken missing, or its vocab file can't be fetched offline
                self._counter = self._heuristic

    @classmethod
    def _heuristic(cls, text: str) -> int:
        n = 0
        for p in cls._piece.findall(text):
            n += 1 if len(p) <= 4 else (len(p) + 3) // 4
        return n

    def count_tokens(self, text: str) -> int:
        if not text:
            return 0
        return int(self._counter(text) * self.safety_margin + 0.999)

    def count_message(self, m) -> int:
        """One message incl. per-message overhead. Uses a cached `token_count` when the object carries one."""
        cached = None if isinstance(m, dict) else getattr(m, "token_count", None)
        if cached is not None:
            return cached + self.per_message_overhead
        content = m["content"] if isinstance(m, dict) else m.content
        return self.count_tokens(content) + self.per_message_overhead

    def count_messages(self, messages) -> int:
        return sum(self.count_message(m) for m in messages)

    def calculate_budget(self, model_context_limit: int, reserved_output_tokens: int, system_tokens: int) -> int:
        return max(0, model_context_limit - reserved_output_tokens - system_tokens)
