"""In-memory summary/message store for unit tests and benchmarks (the app uses sql_store.SqlContextStore)."""
from .types import ContextMessage, SummaryState


class InMemoryStore:
    def __init__(self):
        self._msgs: dict[str, list[ContextMessage]] = {}
        self._sums: dict[str, SummaryState] = {}

    async def add_message(self, conversation_id: str, m: ContextMessage) -> ContextMessage:
        lst = self._msgs.setdefault(conversation_id, [])
        m.seq = len(lst)
        lst.append(m)
        return m

    async def get_messages(self, conversation_id: str) -> list[ContextMessage]:
        return list(self._msgs.get(conversation_id, []))

    async def get_summary(self, conversation_id: str):
        return self._sums.get(conversation_id)

    async def save_summary(self, s: SummaryState):
        self._sums[s.conversation_id] = s  # history is never deleted by summarizing
