"""SQLAlchemy-backed storage for the context layer (summaries + traces). Uses the request's session."""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import ContextTraceRow, ConversationSummary, utcnow

from .types import ContextTrace, SummaryState


class SqlContextStore:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_summary(self, conversation_id: str) -> SummaryState | None:
        row = await self.session.scalar(
            select(ConversationSummary).where(ConversationSummary.conversation_id == conversation_id))
        if row is None:
            return None
        return SummaryState(row.conversation_id, row.summary, row.covered_message_start, row.covered_message_end,
                            row.token_count, row.version, row.created_at, row.updated_at)

    async def save_summary(self, s: SummaryState) -> None:
        row = await self.session.scalar(
            select(ConversationSummary).where(ConversationSummary.conversation_id == s.conversation_id))
        if row is None:
            row = ConversationSummary(conversation_id=s.conversation_id, created_at=s.created_at)
            self.session.add(row)
        row.summary, row.covered_message_start, row.covered_message_end = s.summary, s.covered_message_start, s.covered_message_end
        row.token_count, row.version, row.updated_at = s.token_count, s.version, utcnow()
        await self.session.commit()


def make_trace_row(t: ContextTrace, tokenizer_exact: bool) -> ContextTraceRow:
    """Build (not add/commit) a trace row; the engine commits it together with the LLMRequest row."""
    return ContextTraceRow(
        request_id=t.request_id, conversation_id=t.conversation_id,
        original_message_count=t.original_message_count, selected_message_count=t.selected_message_count,
        original_token_count=t.original_token_count, selected_token_count=t.selected_token_count,
        summary_used=t.summary_used, summary_tokens=t.summary_tokens,
        historical_messages_selected=t.historical_messages_selected,
        historical_messages_removed=t.historical_messages_removed, compression_level=t.compression_level,
        context_build_ms=t.context_build_time * 1000, tokenizer_exact=tokenizer_exact)
