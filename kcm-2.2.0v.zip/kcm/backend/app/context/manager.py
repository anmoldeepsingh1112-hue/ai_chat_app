import time
import uuid

from app.core.logging import get_logger

from .builder import ContextBuilder
from .config import ContextConfig
from .relevance import ContextRelevance, message_importance
from .summarizer import ExtractiveSummarizer
from .token_manager import TokenManager
from .types import ContextMessage, ContextResult, ContextTrace, ModelConfig, SummaryState, _now

logger = get_logger(__name__)


class ContextManager:
    """KCM 2.2: decides WHAT reaches the LLM.
    Layers: P0 system, P1 current message, P2 recent window, P3 summary, P4 relevant older, P5 low-relevance (dropped).
    `store` needs: async get_summary(conversation_id), async save_summary(SummaryState) and, only when `history`
    isn't passed to build_context, async get_messages(conversation_id)."""

    def __init__(self, store, config: ContextConfig | None = None, token_manager: TokenManager | None = None,
                 relevance: ContextRelevance | None = None, summarizer=None, system_prompt: str = ""):
        self.cfg = config or ContextConfig()
        self.store = store
        self.tm = token_manager or TokenManager(per_message_overhead=self.cfg.per_message_overhead_tokens)
        self.relevance = relevance or ContextRelevance(config=self.cfg)
        self.summarizer = summarizer or ExtractiveSummarizer(self.tm)
        self.builder = ContextBuilder(self.tm, self.cfg)
        self.system_prompt = system_prompt
        self.traces: list[ContextTrace] = []  # in-process ring buffer; the engine also persists traces to the DB

    async def mark_important(self, history: list[ContextMessage], message_id: str, importance: float = 0.95):
        for m in history:
            if m.id == message_id:
                m.metadata["importance"] = importance

    async def _ensure_summary(self, conversation_id, older, persist=True, min_new=None):
        existing = await self.store.get_summary(conversation_id)
        end = existing.covered_message_end if existing else -1
        uncovered = [m for m in older if m.seq > end]
        min_new = self.cfg.summary_min_new_messages if min_new is None else min_new
        if not persist or not uncovered or (existing and len(uncovered) < min_new):
            return existing, False
        try:
            text = await self.summarizer.summarize(existing.summary if existing else None, uncovered,
                                                   self.cfg.summary_target_tokens)
        except Exception:  # never break a chat turn because summarizing failed; keep the old summary
            logger.warning("summary_update_failed", exc_info=True)
            return existing, False
        state = SummaryState(conversation_id, text, existing.covered_message_start if existing else older[0].seq,
                             older[-1].seq, self.tm.count_tokens(text),
                             version=(existing.version + 1) if existing else 1,
                             created_at=existing.created_at if existing else _now(), updated_at=_now())
        await self.store.save_summary(state)
        return state, True

    async def force_summarize(self, conversation_id, history: list[ContextMessage]):
        """Developer/testing: summarize everything older than the recent window now, ignoring size thresholds."""
        n = self.cfg.recent_message_limit
        older = history[:-n] if n else history
        if not older:
            return await self.store.get_summary(conversation_id)
        state, _ = await self._ensure_summary(conversation_id, older, min_new=1)
        return state

    async def build_context(self, conversation_id, current_message, model_config: ModelConfig, *,
                            history: list[ContextMessage] | None = None, system_prompt: str | None = None,
                            dry_run: bool = False) -> ContextResult:
        t0 = time.perf_counter()
        cfg, tm = self.cfg, self.tm
        cur_text = current_message.content if isinstance(current_message, ContextMessage) else current_message
        cur_id = current_message.id if isinstance(current_message, ContextMessage) else None
        if history is None:
            history = await self.store.get_messages(conversation_id)
        history = [m for m in history if m.id != cur_id]
        system_prompt = self.system_prompt if system_prompt is None else system_prompt

        limit = min(model_config.context_limit, cfg.max_context_tokens or model_config.context_limit)
        sys_tokens = tm.count_tokens(system_prompt) + (tm.per_message_overhead if system_prompt else 0)
        budget = tm.calculate_budget(limit, model_config.reserved_output_tokens, sys_tokens)
        cur_tokens = tm.count_tokens(cur_text) + tm.per_message_overhead
        remaining = max(0, budget - cur_tokens)
        level = cfg.compression_level

        # ---- P2 recent window (newest first, contiguous; at least the last 2 messages are tried for continuity)
        n = cfg.recent_message_limit
        if level == 0:
            recent_cand, older = history, []
        else:
            recent_cand, older = (history[-n:], history[:-n]) if n else ([], history)
        recent, used = [], 0
        cap = remaining if level == 0 else cfg.recent_budget_fraction * remaining
        for m in reversed(recent_cand):
            c = tm.count_message(m)
            if used + c > cap and len(recent) >= 2:
                break
            recent.insert(0, m)
            used += c

        # ---- P3 summary
        summary, summary_updated, historical = None, False, []
        older_tokens = tm.count_messages(older) if older else 0
        if older and level >= 2:
            if older_tokens > cfg.summary_trigger_tokens or await self.store.get_summary(conversation_id):
                s, summary_updated = await self._ensure_summary(conversation_id, older, persist=not dry_run)
                summary = s.summary if s else None

        # ---- P4 relevant older messages (P5 = below threshold, dropped)
        scores = {}
        if older and level in (1, 3):
            ranked = await self.relevance.score(cur_text, older, current_position=len(history))
            by_id = {m.id: m for m in older}
            protected, relevant = [], []
            for r in ranked:
                m = by_id[r["message_id"]]
                if message_importance(m) >= cfg.protected_importance:
                    protected.append((r, m))
                elif r["relevance"] >= cfg.min_relevance_score:
                    relevant.append((r, m))
            picked = protected[:cfg.max_protected_messages] + relevant[:cfg.max_relevant_messages]
            historical = [m for _, m in picked]
            scores = {r["message_id"]: r["score"] for r, _ in picked}
        elif older and level == 2 and summary is None:
            # below the summary trigger there is nothing to compress yet: keep older messages raw (builder trims)
            historical = older[-cfg.max_relevant_messages * 2:]
            scores = {m.id: m.seq / max(1, len(history)) for m in historical}

        res = await self.builder.build(system_prompt, cur_text, recent, summary, historical, budget, scores)
        res.compression_applied = level
        kept = {m.id for m in res.recent_messages} | {m.id for m in res.relevant_messages}
        res.removed_messages = [m for m in history if m.id not in kept]
        res.total_tokens += sys_tokens
        res.available_tokens = budget
        orig = tm.count_messages(history) + cur_tokens + sys_tokens
        res.trace = ContextTrace(
            request_id=uuid.uuid4().hex, conversation_id=conversation_id,
            original_message_count=len(history) + 1,
            selected_message_count=len(res.recent_messages) + len(res.relevant_messages) + 1,
            original_token_count=orig, selected_token_count=res.total_tokens, summary_used=res.summary_used,
            summary_tokens=res.summary_tokens, historical_messages_selected=len(res.relevant_messages),
            historical_messages_removed=max(0, len(older) - len(res.relevant_messages)), compression_level=level,
            context_build_time=time.perf_counter() - t0, summary_updated=summary_updated,
            current_message_over_budget="current_message_exceeds_budget" in res.warnings)
        if not dry_run:
            self.traces.append(res.trace)
            self.traces[:] = self.traces[-1000:]
        return res

    async def preview(self, conversation_id, model_config: ModelConfig, *, history=None, current_message=""):
        """Developer-only view behind GET /api/conversations/{id}/context-preview. Dry run: nothing is persisted."""
        r = await self.build_context(conversation_id, current_message or "(preview)", model_config,
                                     history=history, dry_run=True)
        t = r.trace
        return {"total_conversation_tokens": t.original_token_count, "selected_tokens": t.selected_token_count,
                "removed_tokens": max(0, t.original_token_count - t.selected_token_count),
                "summary_tokens": t.summary_tokens, "recent_message_count": len(r.recent_messages),
                "relevant_message_count": len(r.relevant_messages), "compression_level": t.compression_level,
                "available_tokens": r.available_tokens, "model_context_limit": model_config.context_limit,
                "context_scores": r.scores, "messages_selected": t.selected_message_count,
                "messages_total": t.original_message_count, "summary_used": t.summary_used,
                "tokenizer_exact": self.tm.exact}
