"""KCM 2.2 context management. Pure-Python core; the only DB-aware module is sql_store."""
from .builder import ContextBuilder
from .config import ContextConfig
from .manager import ContextManager
from .memory_store import InMemoryStore
from .relevance import ContextRelevance, EmbeddingCache, HashingEmbedder
from .summarizer import ExtractiveSummarizer, FallbackSummarizer, LLMSummarizer
from .token_manager import TokenManager
from .types import ContextMessage, ContextResult, ContextTrace, ModelConfig, SummaryState, history_from_db

__all__ = [n for n in dir() if not n.startswith("_")]
