import hashlib
import math
import re
from collections import OrderedDict

from .config import ContextConfig
from .types import ContextMessage

_STOP = set("a an the is are was were be been am do does did to of in on at for and or but with as by it this that these those "
            "i you we they he she me my our your its what which who how when where why can could should would will shall not no "
            "so if then than there here have has had about from into just".split())
_TOK = re.compile(r"[a-z0-9_+#.]+")
_CORRECTION = re.compile(r"\b(actually|correction|instead|no longer|changed? (?:it|that|to)|not .+, but|scratch that|i meant)\b", re.I)
_CONSTRAINT = re.compile(r"\b(must|never|always|do not|don't|required?|requirement|constraint|only use|cannot|can't|deadline|budget)\b", re.I)


def stem(w: str) -> str:
    for suf, minlen in (("ing", 6), ("ed", 5), ("s", 4)):
        if len(w) >= minlen and w.endswith(suf) and not w.endswith("ss"):
            return w[: -len(suf)]
    return w


def tokenize(text: str) -> list[str]:
    return [stem(w.strip(".")) for w in _TOK.findall(text.lower()) if w.strip(".") and w not in _STOP]


class HashingEmbedder:
    """Offline, dependency-free lexical embedding (hashed unigrams + bigrams). Captures word overlap, NOT deep
    semantics. Swap in a real model: any object with `async embed(texts) -> list[list[float]]` (unit vectors)."""

    def __init__(self, dim: int = 512):
        self.dim = dim

    def _h(self, tok: str) -> int:
        return int.from_bytes(hashlib.md5(tok.encode()).digest()[:4], "little") % self.dim

    async def embed(self, texts):
        out = []
        for t in texts:
            v = [0.0] * self.dim
            toks = tokenize(t)
            for w in toks:
                v[self._h(w)] += 1.0
            for a, b in zip(toks, toks[1:]):
                v[self._h(a + "_" + b)] += 0.5
            n = math.sqrt(sum(x * x for x in v)) or 1.0
            out.append([x / n for x in v])
        return out


class EmbeddingCache(OrderedDict):
    """Bounded LRU keyed by message id; shared across requests (messages are immutable once saved)."""

    def __init__(self, max_items: int = 20_000):
        super().__init__()
        self.max_items = max_items

    def __setitem__(self, k, v):
        super().__setitem__(k, v)
        self.move_to_end(k)
        while len(self) > self.max_items:
            self.popitem(last=False)


def cosine(a, b) -> float:
    return sum(x * y for x, y in zip(a, b))


def cue_importance(text: str) -> float:
    if _CORRECTION.search(text):
        return 0.85
    if _CONSTRAINT.search(text):
        return 0.8
    return 0.0


def message_importance(m: ContextMessage) -> float:
    """Explicit `metadata["importance"]` wins; otherwise correction/constraint cues in USER messages."""
    return max(float(m.metadata.get("importance", 0.0) or 0.0), cue_importance(m.content) if m.role == "user" else 0.0)


class ContextRelevance:
    """Conversation-context retrieval only (not long-term memory)."""

    def __init__(self, embedder=None, config: ContextConfig | None = None, cache: EmbeddingCache | None = None):
        self.embedder = embedder or HashingEmbedder()
        self.cfg = config or ContextConfig()
        self._cache = cache if cache is not None else EmbeddingCache()

    async def embeddings(self, messages):
        missing = [m for m in messages if m.id not in self._cache]
        if missing:
            for m, e in zip(missing, await self.embedder.embed([m.content for m in missing])):
                self._cache[m.id] = e
        for m in messages:
            m.metadata.setdefault("embedding_reference", m.id)
        return [self._cache[m.id] for m in messages]

    async def score(self, query: str, messages: list[ContextMessage], current_position: int | None = None):
        """-> [{message_id, score, relevance, recency, position}] sorted by score desc.
        score = alpha*R + beta*T + gamma*P (an engineering heuristic, not an optimum)."""
        if not messages:
            return []
        c = self.cfg
        q = (await self.embedder.embed([query]))[0]
        embs = await self.embeddings(messages)
        cur = current_position if current_position is not None else max(m.seq for m in messages) + 1
        out = []
        for m, e in zip(messages, embs):
            R = max(0.0, cosine(q, e))
            T = 0.5 ** (max(0, cur - m.seq) / max(1, c.recency_half_life))
            P = max(message_importance(m), 0.3 if m.seq < 3 else 0.0, 0.1 if m.role == "user" else 0.0)
            out.append({"message_id": m.id, "score": c.alpha * R + c.beta * T + c.gamma * P,
                        "relevance": R, "recency": T, "position": P})
        return sorted(out, key=lambda d: -d["score"])
