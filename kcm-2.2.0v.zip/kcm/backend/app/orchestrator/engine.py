"""KCMEngine: the single place that turns a user message into an assistant reply.

KCM 2.2 pipeline: load conversation -> ContextManager (recent + summary + relevant history, token budget)
-> LLM -> save -> return. Without a ContextManager the engine behaves exactly like KCM 2.1
(system prompt + last MAX_HISTORY_MESSAGES + user message).
Future phases (memory, tools, KCM model) plug in between "build context" and "LLM".
"""
import asyncio
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.context import ContextManager, ContextResult, ModelConfig, history_from_db
from app.context.sql_store import make_trace_row
from app.core.config import Settings
from app.core.errors import DatabaseError, KCMError
from app.core.logging import get_logger, request_id_var
from app.database.models import Conversation, LLMRequest, Message, utcnow
from app.llm.base import ChatMessage, LLMProvider, TokenUsage
from app.orchestrator.prompt_builder import PromptBuilder, validate_user_message
from app.services.conversation_service import ConversationService

logger = get_logger(__name__)


@dataclass
class EngineResult:
    conversation_id: str
    message: Message
    usage: TokenUsage | None = None


@dataclass
class EngineEvent:
    type: str  # start | delta | done
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class _Prepared:
    conversation: Conversation
    user_text: str
    received_at: datetime
    context: list[ChatMessage]
    first_message: bool
    ctx: ContextResult | None = None  # KCM 2.2 build result (None on the 2.1 path)


class KCMEngine:
    def __init__(self, session: AsyncSession, provider: LLMProvider, settings: Settings, prompt_builder: PromptBuilder,
                 context_manager: ContextManager | None = None):
        self.session = session
        self.provider = provider
        self.settings = settings
        self.prompt_builder = prompt_builder
        self.context_manager = context_manager  # None -> KCM 2.1 behaviour
        self.conversations = ConversationService(session)

    def model_config(self) -> ModelConfig:
        s = self.settings
        return ModelConfig(name=s.llm_model, context_limit=s.llm_context_limit,
                           reserved_output_tokens=s.llm_max_tokens or s.context_reserved_output_tokens,
                           provider=self.provider.name)

    # ---- public API -------------------------------------------------
    async def process_message(self, conversation_id: str, user_message: str, user_id: str) -> EngineResult:
        prep = await self._prepare(conversation_id, user_message, user_id)
        started = time.perf_counter()
        try:
            result = await self.provider.generate(
                prep.context,
                model=self.settings.llm_model,
                temperature=self.settings.llm_temperature,
                max_tokens=self.settings.llm_max_tokens,
            )
        except KCMError as e:
            await self._record(prep, started, None, "error", e.code, streamed=False)
            raise
        assistant = await self._persist(prep, result.content)
        await self._record(prep, started, result.usage, "ok", None, streamed=False)
        return EngineResult(prep.conversation.id, assistant, result.usage)

    async def stream_message(self, conversation_id: str, user_message: str, user_id: str) -> AsyncIterator[EngineEvent]:
        prep = await self._prepare(conversation_id, user_message, user_id)
        yield EngineEvent("start", {"conversation_id": prep.conversation.id})
        started = time.perf_counter()
        parts: list[str] = []
        usage: TokenUsage | None = None
        try:
            async for chunk in self.provider.stream(
                prep.context,
                model=self.settings.llm_model,
                temperature=self.settings.llm_temperature,
                max_tokens=self.settings.llm_max_tokens,
            ):
                if chunk.usage:
                    usage = chunk.usage
                if chunk.text:
                    parts.append(chunk.text)
                    yield EngineEvent("delta", {"content": chunk.text})
        except KCMError as e:
            await self._record(prep, started, usage, "error", e.code, streamed=True)
            raise
        except asyncio.CancelledError:  # client disconnected; nothing is saved for a partial reply
            logger.warning("stream_cancelled", extra={"conversation_id": prep.conversation.id})
            raise
        assistant = await self._persist(prep, "".join(parts))
        await self._record(prep, started, usage, "ok", None, streamed=True)
        done = {
            "conversation_id": prep.conversation.id,
            "message_id": assistant.id,
            "usage": _usage_dict(usage),
        }
        if self.settings.dev_mode and prep.ctx is not None:  # developer panel only; never sent in normal operation
            done["context"] = _context_stats(prep.ctx, self.settings.llm_context_limit)
        yield EngineEvent("done", done)

    # ---- internals --------------------------------------------------
    async def _prepare(self, conversation_id: str, user_message: str, user_id: str) -> _Prepared:
        text = validate_user_message(user_message, self.settings.max_message_chars)
        conv = await self.conversations.get(user_id, conversation_id, with_messages=True)
        context, ctx = await self._build_context(conv, text)
        return _Prepared(
            conversation=conv,
            user_text=text,
            received_at=utcnow(),
            context=context,
            first_message=len(conv.messages) == 0,
            ctx=ctx,
        )

    async def _build_context(self, conv: Conversation, text: str) -> tuple[list[ChatMessage], ContextResult | None]:
        if self.context_manager is None:  # KCM 2.1 path
            return self.prompt_builder.build(conv.messages, text), None
        try:
            ctx = await self.context_manager.build_context(
                conv.id, text, self.model_config(),
                history=history_from_db(conv.messages), system_prompt=self.prompt_builder.system_prompt,
            )
        except SQLAlchemyError as e:  # summary persistence failed: same contract as any other DB failure
            await self.session.rollback()
            raise DatabaseError(detail=repr(e)) from e
        except KCMError:
            raise
        except Exception:  # a context-management bug must degrade to 2.1 behaviour, not break chat
            logger.exception("context_manager_failed_falling_back")
            return self.prompt_builder.build(conv.messages, text), None
        if ctx.warnings:
            logger.warning("context_warnings", extra={"conversation_id": conv.id, "warnings": ctx.warnings})
        return ctx.messages, ctx

    async def _persist(self, prep: _Prepared, reply: str) -> Message:
        """Save the user message and assistant reply together (atomic)."""
        try:
            conv = prep.conversation
            tm = self.context_manager.tm if self.context_manager else None  # cache counts for later context builds
            self.conversations.add_message(conv, "user", prep.user_text, prep.received_at,
                                           token_count=tm.count_tokens(prep.user_text) if tm else None)
            assistant = self.conversations.add_message(conv, "assistant", reply,
                                                       token_count=tm.count_tokens(reply) if tm else None)
            conv.updated_at = utcnow()
            if prep.first_message and conv.title == "New conversation":
                conv.title = prep.user_text[:60]
            await self.session.commit()
            return assistant
        except SQLAlchemyError as e:
            await self.session.rollback()
            raise DatabaseError(detail=repr(e)) from e

    async def _record(self, prep: _Prepared, started: float, usage: TokenUsage | None, status: str,
                      error_code: str | None, streamed: bool) -> None:
        latency_ms = int((time.perf_counter() - started) * 1000)
        conv_id = prep.conversation.id
        logger.info(
            "llm_request",
            extra={
                "conversation_id": conv_id,
                "model": self.settings.llm_model,
                "latency_ms": latency_ms,
                "input_tokens": usage.input_tokens if usage else None,
                "output_tokens": usage.output_tokens if usage else None,
                "status": status,
                "error": error_code,
                "streamed": streamed,
            },
        )
        try:
            if prep.ctx is not None and prep.ctx.trace is not None:
                prep.ctx.trace.request_id = request_id_var.get()  # join key with llm_requests
                self.session.add(make_trace_row(prep.ctx.trace, self.context_manager.tm.exact))
            self.session.add(
                LLMRequest(
                    conversation_id=conv_id,
                    request_id=request_id_var.get(),
                    provider=self.provider.name,
                    model=self.settings.llm_model,
                    input_tokens=usage.input_tokens if usage else None,
                    output_tokens=usage.output_tokens if usage else None,
                    total_tokens=usage.total_tokens if usage else None,
                    latency_ms=latency_ms,
                    status=status,
                    error_code=error_code,
                    streamed=streamed,
                )
            )
            await self.session.commit()
        except SQLAlchemyError:  # usage tracking must never break a chat
            await self.session.rollback()
            logger.exception("llm_request_record_failed")


def _usage_dict(usage: TokenUsage | None) -> dict | None:
    if usage is None:
        return None
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "total_tokens": usage.total_tokens,
    }


def _context_stats(ctx: ContextResult, context_limit: int) -> dict:
    t = ctx.trace
    return {
        "selected_tokens": ctx.total_tokens,
        "available_tokens": ctx.available_tokens,
        "context_limit": context_limit,
        "original_tokens": t.original_token_count if t else None,
        "messages_selected": t.selected_message_count if t else None,
        "messages_total": t.original_message_count if t else None,
        "recent_messages": len(ctx.recent_messages),
        "relevant_messages": len(ctx.relevant_messages),
        "summary_used": ctx.summary_used,
        "summary_tokens": ctx.summary_tokens,
        "compression_level": ctx.compression_applied,
        "build_ms": round(t.context_build_time * 1000, 1) if t else None,
    }
