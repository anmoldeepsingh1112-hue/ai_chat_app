"""Basic context: system prompt + recent history + new user message (KCM 2.1)."""
from collections.abc import Sequence

from app.core.errors import InvalidRequestError
from app.database.models import Message
from app.llm.base import ChatMessage
from app.services.prompt_service import PromptService

_VALID_ROLES = {"system", "user", "assistant"}


def validate_user_message(text: str, max_chars: int) -> str:
    text = (text or "").strip()
    if not text:
        raise InvalidRequestError("Message must not be empty.")
    if len(text) > max_chars:
        raise InvalidRequestError(f"Message is too long (max {max_chars} characters).")
    return text


def to_chat_messages(history: Sequence[Message]) -> list[ChatMessage]:
    return [ChatMessage(m.role, m.content) for m in history if m.role in _VALID_ROLES]


class PromptBuilder:
    def __init__(self, prompts: PromptService, max_history_messages: int = 40):
        self._prompts = prompts
        self._max_history = max_history_messages

    @property
    def system_prompt(self) -> str:
        return self._prompts.system_prompt

    def build(self, history: Sequence[Message], user_message: str) -> list[ChatMessage]:
        past = to_chat_messages(history)
        if self._max_history > 0:
            past = past[-self._max_history :]
        return [
            ChatMessage("system", self._prompts.system_prompt),
            *past,
            ChatMessage("user", user_message),
        ]
