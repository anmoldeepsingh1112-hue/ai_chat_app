from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    # Optional: when omitted a new conversation is created and its id returned.
    conversation_id: str | None = Field(default=None, max_length=36)
    message: str = Field(min_length=1)  # max length enforced from settings (MAX_MESSAGE_CHARS)


class ChatResponse(BaseModel):
    conversation_id: str
    message_id: str
    role: str = "assistant"
    content: str
