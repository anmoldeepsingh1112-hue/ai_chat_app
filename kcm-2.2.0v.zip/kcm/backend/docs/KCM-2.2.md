# KCM 2.2 — Context Management Engine

KCM 2.1 sent `system + last N messages + user message`. KCM 2.2 decides **what** reaches the LLM:

```
KCMEngine._prepare
   └─ ContextManager.build_context()                 app/context/manager.py
        ├─ P2 recent window (RECENT_MESSAGE_LIMIT, newest first)
        ├─ P3 rolling summary (incremental, original messages never deleted)
        ├─ P4 relevant older messages (hybrid score S = αR + βT + γP, gated by raw similarity)
        │     P5 low-relevance history is dropped; protected messages (importance ≥ 0.8) are kept
        └─ TokenManager budget → ContextBuilder → [system, summary, relevant, recent…, current]
   └─ LLM → save (user+assistant, token_count cached) → trace row (context_traces)
```
P0 system prompt and P1 current message are never trimmed. Trim order when over budget: relevant → summary → oldest recent.
If the context layer throws an unexpected non-DB error, the engine logs it and falls back to the 2.1 prompt; a summarizer
failure keeps the old summary. `CONTEXT_MANAGER_ENABLED=false` restores exact 2.1 behaviour.

## Where things are
| Spec § | Code |
|---|---|
| 4,5,9,19 ContextManager, layers, priorities, levels | `app/context/manager.py` |
| 7,8 TokenManager | `app/context/token_manager.py` |
| 10,11,17 relevance, hybrid score, protection | `app/context/relevance.py` |
| 12–15 summaries (incremental, triggers) | `app/context/summarizer.py`, `manager._ensure_summary` |
| 16,18 builder, dedup | `app/context/builder.py` |
| 20 engine integration | `app/orchestrator/engine.py` (`_build_context`) |
| 21,24 dev endpoints | `app/api/routes/context_dev.py`, `dependencies.require_dev` |
| 22 trace | `ContextTraceRow` (`context_traces`), written with the `llm_requests` row |
| 23 DB | `ConversationSummary`, `ContextTraceRow`, `messages.{importance,token_count,embedding_reference}` |
| 25 frontend | `features/chat/context-debug/` (Ctrl+Shift+D) |
| 26 tests | `tests/unit/test_context_manager.py`, `test_engine_context.py`, `tests/integration/test_context_api.py` |
| 27–29 benchmark | `benchmarks/context_benchmark.py` |

## Upgrade an existing 2.1 database
`AUTO_CREATE_TABLES` creates the two new tables on a fresh DB but does **not** add columns to `messages`.
Run `migrations/2_2_context_postgres.sql` (SQLite: `ALTER TABLE messages ADD COLUMN …` ×3 with REAL/INTEGER/VARCHAR).

## Developer endpoints (hidden unless `DEV_MODE=true`)
`GET /api/conversations/{id}/context-preview?message=…` · `POST /api/conversations/{id}/summarize`
Both answer `404` unless `DEV_MODE=true` and, when `DEV_TOKEN` is set, the `X-KCM-Dev-Token` header matches. Ownership is enforced.
With `DEV_MODE=true` the final SSE `done` event also carries a `context` object for the Angular dev panel.
Set `LLM_CONTEXT_LIMIT` to your model's real window; the default (32 000) is a placeholder.

## Benchmark (synthetic, mock reader) — `python benchmarks/context_benchmark.py 10`
9 scenario types × 10 seeds, 400-message conversations, 8,192-token model, heuristic tokenizer.

| System | Avg input tokens | Reduction | Accuracy | Exceeds model limit |
|---|---|---|---|---|
| Baseline (full history) | 12,540 | — | 100% | 88.9% |
| Truncate oldest | 6,402 | 49.0% | 51.1% | 0% |
| KCM L1 relevance | 716 | 94.3% | 88.9% | 0% |
| KCM L2 summary | 1,192 | 90.5% | 77.8% | 0% |
| **KCM L3 summary + relevance** | **1,212** | **90.3%** | **88.9%** | 0% |

L3 is 100% in every scenario **except `paraphrase_hard` (0%)** (question and fact share no words; the offline lexical
embedder cannot bridge that). L2 alone loses early facts and topic-change facts (60% / 40%).
Context-build latency, 500 messages, pure Python: ~80 ms cold, ~23 ms with a warm embedding cache (the cache is shared
across requests in the app).

**What this does not show:** the reader is a deterministic mock that answers only from the context it receives, so this
measures *context retrieval*, not real answer quality, continuity, or LLM latency. Data and heuristics were written by the
same author (overfitting risk). Re-run with a real LLM and a real embedding model before drawing conclusions about the
research question.

## Known limitations
- Default embedder is lexical (`HashingEmbedder`). Plug in a real model: any object with `async embed(texts) -> unit vectors`
  passed to `build_runtime(settings, embedder=…)`. Embeddings are cached in memory only (`embedding_reference` is reserved
  for a persistent embedding store and is **not populated yet**).
- Token counts are a heuristic estimate unless `tiktoken` is installed or a provider tokenizer is passed
  (`TokenManager(counter=…)`); `context_traces.tokenizer_exact` records which was used. Cached `messages.token_count`
  values are tokenizer-specific.
- `messages.importance` is read when set, but no API sets it yet; correction/constraint cues in user messages are
  detected automatically.
- `CONTEXT_SUMMARIZER=llm` works with a real provider; with `LLM_PROVIDER=mock` the "summary" is mock text.
- Two concurrent requests on one conversation may both update the summary (last write wins).
