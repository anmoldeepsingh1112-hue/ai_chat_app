"""KCM 2.2 benchmark. Synthetic conversations + a deterministic *mock reader* that answers only from the
context it is given. That isolates CONTEXT RETRIEVAL quality (was the needed fact delivered?).
It does NOT measure real LLM answer quality or real LLM latency: rerun with a real LLM + real embeddings."""
import asyncio, json, random, re, statistics, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.context import ContextConfig, ContextManager, ContextMessage, InMemoryStore, ModelConfig, TokenManager

MODEL = ModelConfig("bench-8k", context_limit=8192, reserved_output_tokens=1000)
TOPICS = ["quantum mechanics", "gardening tomatoes", "medieval history", "jazz piano", "marathon training", "volcanoes",
          "coffee brewing", "chess openings", "bird migration", "sourdough baking"]
FILL = ["Let's talk about {t} for a while, I find it really interesting and want the details.",
        "Sure, here is a longer explanation of {t}, covering the history, the main ideas and some common misconceptions.",
        "Could you compare two different views on {t} and tell me which one you find more convincing?",
        "Thanks, that helps. One more thing about {t}: what would a beginner need to read first?",
        "The garden project needs mulch this spring, and I also wonder about {t}.",
        "Random thought about the database of bird songs I saw online while reading about {t}."]


def filler(rnd, i):
    return rnd.choice(FILL).format(t=rnd.choice(TOPICS)) + f" [{i}]"


def scenario(kind, rnd):
    """returns (messages{idx:text}, n, question, key_regex, options, expected)"""
    S = {}
    if kind == "short":
        n = 6; S[1] = "The project uses Python for the backend."
        return S, n, "What language does the project use?", r"project", ["Python", "Rust", "Go"], "Python"
    if kind == "long_early_fact":
        n = 400; S[rnd.randint(5, 30)] = "The project uses Python for the backend."
        return S, n, "What language does the project use?", r"project uses", ["Python", "Rust", "Go"], "Python"
    if kind == "long_late_fact":
        n = 400; S[rnd.randint(380, 395)] = "The project uses Python for the backend."
        return S, n, "What language does the project use?", r"project uses", ["Python", "Rust", "Go"], "Python"
    if kind == "topic_change":
        n = 300; S[10] = "We are building a chatbot called Orion for customer support."
        return S, n, "What is the chatbot we are building called?", r"chatbot called", ["Orion", "Atlas", "Nova"], "Orion"
    if kind == "repeated_topic":
        n = 400; S[20] = "The database is PostgreSQL."; S[150] = "Remember the database is PostgreSQL."; S[260] = "Still using PostgreSQL for the database."
        return S, n, "Which database do we use?", r"database", ["PostgreSQL", "MySQL", "SQLite"], "PostgreSQL"
    if kind == "correction":
        n = 400; S[30] = "The project database is PostgreSQL."; S[rnd.randint(150, 250)] = "Actually, the project database is now MySQL instead of PostgreSQL."
        return S, n, "Which database does the project use now?", r"project database", ["MySQL", "PostgreSQL"], "MySQL"
    if kind == "contradiction_no_cue":
        n = 400; S[40] = "The release deadline is March 3."; S[250] = "The release deadline is April 9."
        return S, n, "What is the release deadline?", r"release deadline", ["April 9", "March 3"], "April 9"
    if kind == "multi_project":
        n = 400; S[12] = "Project Alpha is written in Go."; S[60] = "Project Beta is written in Rust."; S[200] = "Project Gamma is written in Java."
        return S, n, "What is Project Beta written in?", r"Project Beta", ["Rust", "Go", "Java"], "Rust"
    if kind == "paraphrase_hard":     # no lexical overlap -> expected failure for the offline embedder
        n = 400; S[20] = "The backend is coded in Python."
        return S, n, "Which programming language powers the server side?", r"backend", ["Python", "Rust", "Go"], "Python"
    raise ValueError(kind)


KINDS = ["short", "long_early_fact", "long_late_fact", "topic_change", "repeated_topic", "correction",
         "contradiction_no_cue", "multi_project", "paraphrase_hard"]


def mock_read(context_msgs, key, options):
    last = None
    for m in context_msgs:
        for s in re.split(r"(?<=[.!?])\s+|\n", m["content"]):
            if re.search(key, s, re.I) and any(o.lower() in s.lower() for o in options):
                last = s
    if not last: return None
    return min(options, key=lambda o: last.lower().find(o.lower()) if o.lower() in last.lower() else 10**9)


def fresh_store(S, n, rnd):
    store = InMemoryStore()
    async def fill():
        for i in range(n):
            txt = S.get(i) or filler(rnd, i)
            await store.add_message("c", ContextMessage(f"m{i}", "user" if i % 2 == 0 else "assistant", txt))
    asyncio.run(fill()); return store


async def tok_truncate(store, tm, question, budget):
    hist = await store.get_messages("c"); out = [{"role": "user", "content": question}]; used = tm.count_messages(out)
    for m in reversed(hist):
        c = tm.count_tokens(m.content) + tm.per_message_overhead
        if used + c > budget: break
        out.insert(0, {"role": m.role, "content": m.content}); used += c
    return out


async def run_system(name, store, question, cfg_level, tm):
    t = time.perf_counter()
    if name == "baseline_full":
        hist = await store.get_messages("c")
        msgs = [{"role": m.role, "content": m.content} for m in hist] + [{"role": "user", "content": question}]
    elif name == "truncate_oldest":
        msgs = await tok_truncate(store, tm, question, MODEL.context_limit - MODEL.reserved_output_tokens)
    else:
        cm = ContextManager(store, ContextConfig(recent_message_limit=20, summary_trigger_tokens=2000, summary_target_tokens=600,
                                                 compression_level=cfg_level), tm)
        r = await cm.build_context("c", question, MODEL)
        msgs = [{"role": m.role, "content": m.content} for m in r.messages]
    return msgs, (time.perf_counter() - t) * 1000


def main(seeds=5):
    tm = TokenManager()
    systems = [("baseline_full", 0), ("truncate_oldest", 0), ("kcm_L1_relevance", 1), ("kcm_L2_summary", 2), ("kcm_L3_summary+relevance", 3)]
    rows = {s: {k: [] for k in ("tokens", "ok", "build_ms", "overflow")} for s, _ in systems}
    per_kind = {s: {k: [] for k in KINDS} for s, _ in systems}
    for kind in KINDS:
        for seed in range(seeds):
            rnd = random.Random(seed * 100 + hash(kind) % 97)
            S, n, q, key, opts, exp = scenario(kind, rnd)
            for name, lvl in systems:
                store = fresh_store(S, n, random.Random(seed))   # fresh per system: no summary carry-over
                msgs, ms = asyncio.run(run_system(name, store, q, lvl, tm))
                ans = mock_read(msgs, key, opts); toks = tm.count_messages(msgs)
                rows[name]["tokens"].append(toks); rows[name]["ok"].append(ans == exp); rows[name]["build_ms"].append(ms)
                rows[name]["overflow"].append(toks + MODEL.reserved_output_tokens > MODEL.context_limit)
                per_kind[name][kind].append(ans == exp)
    base = statistics.mean(rows["baseline_full"]["tokens"])
    out = {"seeds": seeds, "scenarios": len(KINDS), "model_limit": MODEL.context_limit, "tokenizer_exact": tm.exact, "summary": {}, "per_scenario_accuracy": {}}
    for s, _ in systems:
        r = rows[s]
        out["summary"][s] = {"avg_input_tokens": round(statistics.mean(r["tokens"])),
                             "token_reduction_vs_baseline_%": round(100 * (1 - statistics.mean(r["tokens"]) / base), 1),
                             "answer_accuracy_%": round(100 * statistics.mean(r["ok"]), 1),
                             "exceeds_model_limit_%": round(100 * statistics.mean(r["overflow"]), 1),
                             "context_build_ms_avg": round(statistics.mean(r["build_ms"]), 2)}
        out["per_scenario_accuracy"][s] = {k: round(100 * statistics.mean(v)) for k, v in per_kind[s].items()}
    print(json.dumps(out, indent=2)); json.dump(out, open(Path(__file__).with_name("benchmark_results.json"), "w"), indent=2)


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 5)
