-- KCM 2.1 -> 2.2 (PostgreSQL). Needed only for EXISTING databases: AUTO_CREATE_TABLES creates the new tables on a
-- fresh DB but never adds columns to an existing `messages` table. Safe to re-run.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS importance DOUBLE PRECISION;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS token_count INTEGER;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS embedding_reference VARCHAR(64);

CREATE TABLE IF NOT EXISTS conversation_summaries (
    id VARCHAR(36) PRIMARY KEY,
    conversation_id VARCHAR(36) NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
    summary TEXT NOT NULL,
    covered_message_start INTEGER NOT NULL,
    covered_message_end INTEGER NOT NULL,
    token_count INTEGER NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS context_traces (
    id VARCHAR(36) PRIMARY KEY,
    request_id VARCHAR(64),
    conversation_id VARCHAR(36) REFERENCES conversations(id) ON DELETE SET NULL,
    original_message_count INTEGER NOT NULL,
    selected_message_count INTEGER NOT NULL,
    original_token_count INTEGER NOT NULL,
    selected_token_count INTEGER NOT NULL,
    summary_used BOOLEAN NOT NULL DEFAULT FALSE,
    summary_tokens INTEGER NOT NULL DEFAULT 0,
    historical_messages_selected INTEGER NOT NULL DEFAULT 0,
    historical_messages_removed INTEGER NOT NULL DEFAULT 0,
    compression_level INTEGER NOT NULL,
    context_build_ms DOUBLE PRECISION NOT NULL,
    tokenizer_exact BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_context_traces_request_id ON context_traces(request_id);
CREATE INDEX IF NOT EXISTS ix_context_traces_conversation_id ON context_traces(conversation_id);
