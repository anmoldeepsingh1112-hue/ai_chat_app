import pytest
from sqlalchemy import select
from sqlalchemy.exc import OperationalError

from app.core.errors import LLMAuthError, LLMError, LLMRateLimitError, LLMTimeoutError
from app.database.models import LLMRequest
from app.llm.adapters.mock import MockLLMProvider
from app.services.conversation_service import ConversationService
from tests.conftest import make_settings, stream_events

U2 = {"X-Mock-User": "user-2"}


async def test_health(client):
    r = await client.get("/api/health")
    assert r.status_code == 200 and r.json() == {"status": "ok"}
    assert r.headers["x-request-id"]


async def test_conversation_crud(client):
    c = await client.post("/api/conversations", json={"title": "T"})
    assert c.status_code == 201
    cid = c.json()["id"]
    assert [x["id"] for x in (await client.get("/api/conversations")).json()] == [cid]
    got = await client.get(f"/api/conversations/{cid}")
    assert got.json()["title"] == "T" and got.json()["messages"] == []
    assert (await client.delete(f"/api/conversations/{cid}")).status_code == 204
    assert (await client.get(f"/api/conversations/{cid}")).status_code == 404


async def test_create_conversation_without_body(client):
    assert (await client.post("/api/conversations")).status_code == 201


async def test_user_isolation(client):
    cid = (await client.post("/api/conversations")).json()["id"]
    assert (await client.get(f"/api/conversations/{cid}", headers=U2)).status_code == 404
    assert (await client.delete(f"/api/conversations/{cid}", headers=U2)).status_code == 404
    assert (await client.get("/api/conversations", headers=U2)).json() == []
    r = await client.post("/api/chat", json={"conversation_id": cid, "message": "hi"}, headers=U2)
    assert r.status_code == 404
    assert (await client.get(f"/api/conversations/{cid}")).status_code == 200


async def test_chat_roundtrip_persists(client, mock_llm):
    cid = (await client.post("/api/conversations")).json()["id"]
    r = await client.post("/api/chat", json={"conversation_id": cid, "message": "Hello"})
    body = r.json()
    assert r.status_code == 200
    assert body["conversation_id"] == cid and body["role"] == "assistant" and body["content"] == "Hello! I am KCM."
    msgs = (await client.get(f"/api/conversations/{cid}")).json()["messages"]
    assert [(m["role"], m["content"]) for m in msgs] == [("user", "Hello"), ("assistant", "Hello! I am KCM.")]
    assert msgs[1]["id"] == body["message_id"]


async def test_chat_without_conversation_id_creates_one(client):
    r = await client.post("/api/chat", json={"message": "Hello"})
    assert r.status_code == 200
    assert len((await client.get("/api/conversations")).json()) == 1


async def test_token_usage_stored(app, client):
    await client.post("/api/chat", json={"message": "Hello"})
    async with app.state.session_factory() as s:
        row = (await s.scalars(select(LLMRequest))).one()
    assert row.status == "ok" and row.input_tokens > 0 and row.output_tokens > 0 and row.conversation_id


# ---- failure cases ----
@pytest.mark.parametrize("payload", [{"message": ""}, {"message": "   "}, {}, {"message": 5}])
async def test_invalid_or_empty_message(client, payload):
    r = await client.post("/api/chat", json=payload)
    assert r.status_code == 422 and r.json()["error"]["code"] == "INVALID_REQUEST"
    assert (await client.get("/api/conversations")).json() == []  # nothing created


async def test_very_long_message(client):
    r = await client.post("/api/chat", json={"message": "x" * 9000})
    assert r.status_code == 422 and r.json()["error"]["code"] == "INVALID_REQUEST"


async def test_request_size_limit(client):
    r = await client.post("/api/chat", json={"message": "x" * 100_000})
    assert r.status_code == 413 and r.json()["error"]["code"] == "REQUEST_TOO_LARGE"


async def test_invalid_conversation_id(client):
    r = await client.post("/api/chat", json={"conversation_id": "not-a-real-id", "message": "hi"})
    assert r.status_code == 404 and r.json()["error"]["code"] == "CONVERSATION_NOT_FOUND"
    r = await client.post("/api/chat/stream", json={"conversation_id": "nope", "message": "hi"})
    assert r.status_code == 404 and r.json()["error"]["code"] == "CONVERSATION_NOT_FOUND"


@pytest.mark.parametrize("exc,status,code", [
    (LLMTimeoutError(), 504, "LLM_TIMEOUT"),
    (LLMError(detail="secret internal stack"), 502, "LLM_ERROR"),
    (LLMRateLimitError(), 429, "LLM_RATE_LIMIT"),
    (LLMAuthError(detail="bad key sk-abc"), 502, "LLM_AUTH_ERROR"),
])
async def test_llm_failures_are_structured_and_safe(mock_llm, exc, status, code):
    import httpx
    from app.main import create_app
    llm = MockLLMProvider(fail_with=exc)
    app = create_app(make_settings(), provider=llm)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            r = await c.post("/api/chat", json={"message": "Hello"})
    assert r.status_code == status
    assert set(r.json()) == {"error"} and r.json()["error"]["code"] == code
    assert "secret" not in r.text and "sk-abc" not in r.text and "Traceback" not in r.text


async def test_llm_timeout_via_real_deadline():
    import httpx
    from app.main import create_app
    app = create_app(make_settings(llm_timeout=0.05, max_retries=0), provider=MockLLMProvider(delay=0.5))
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            r = await c.post("/api/chat", json={"message": "Hello"})
    assert r.status_code == 504 and r.json()["error"]["code"] == "LLM_TIMEOUT"


async def test_database_failure(client, monkeypatch):
    async def boom(self, *a, **k):
        raise OperationalError("SELECT secret_table", {}, Exception("pg down at 10.0.0.5"))

    monkeypatch.setattr(ConversationService, "list", boom)
    r = await client.get("/api/conversations")
    assert r.status_code == 500 and r.json()["error"]["code"] == "DATABASE_ERROR"
    assert "secret_table" not in r.text and "10.0.0.5" not in r.text


async def test_rate_limit(mock_llm):
    import httpx
    from app.main import create_app
    app = create_app(make_settings(rate_limit_per_minute=2), provider=mock_llm)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            codes = [(await c.post("/api/chat", json={"message": "Hello"})).status_code for _ in range(3)]
            other = await c.post("/api/chat", json={"message": "Hello"}, headers=U2)
    assert codes == [200, 200, 429] and other.status_code == 200


async def test_cors_allows_configured_origin_only(client):
    ok = await client.options("/api/chat", headers={"Origin": "http://localhost:4200", "Access-Control-Request-Method": "POST"})
    bad = await client.options("/api/chat", headers={"Origin": "http://evil.example", "Access-Control-Request-Method": "POST"})
    assert ok.headers.get("access-control-allow-origin") == "http://localhost:4200"
    assert ok.headers.get("access-control-allow-credentials") == "true"
    assert "access-control-allow-origin" not in bad.headers


def test_production_refuses_mock_auth():
    from app.main import create_app
    with pytest.raises(RuntimeError):
        create_app(make_settings(app_env="production", llm_provider="openai", llm_api_key="k"))


# ---- streaming ----
async def test_stream_chunks_reassemble_to_saved_message(client):
    cid = (await client.post("/api/conversations")).json()["id"]
    r, events = await stream_events(client, {"conversation_id": cid, "message": "Explain quantum mechanics"})
    assert r.headers["content-type"].startswith("text/event-stream")
    types = [t for t, _ in events]
    assert types[0] == "start" and types[-1] == "done" and types.count("delta") > 1
    full = "".join(d["content"] for t, d in events if t == "delta")
    saved = (await client.get(f"/api/conversations/{cid}")).json()["messages"]
    assert saved[-1]["content"] == full and saved[-1]["id"] == events[-1][1]["message_id"]
    assert events[-1][1]["usage"]["total_tokens"] > 0


async def test_stream_error_before_start_is_http_error():
    import httpx
    from app.main import create_app
    app = create_app(make_settings(max_retries=0), provider=MockLLMProvider(fail_with=LLMTimeoutError()))
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            r = await c.post("/api/chat/stream", json={"message": "Hello"})
    assert r.status_code in (200, 504)
    assert "LLM_TIMEOUT" in r.text


async def test_stream_interruption_emits_error_event_and_saves_nothing():
    import httpx
    from app.main import create_app
    llm = MockLLMProvider(response="one two three four", fail_after_chunks=2, fail_with=LLMError(detail="conn reset"))
    app = create_app(make_settings(), provider=llm)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            cid = (await c.post("/api/conversations")).json()["id"]
            r, events = await stream_events(c, {"conversation_id": cid, "message": "go"})
            msgs = (await c.get(f"/api/conversations/{cid}")).json()["messages"]
    assert [t for t, _ in events] == ["start", "delta", "delta", "error"]
    assert events[-1][1]["error"]["code"] == "STREAM_INTERRUPTED" and "conn reset" not in str(events)
    assert msgs == []
