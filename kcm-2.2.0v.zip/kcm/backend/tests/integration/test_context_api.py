"""KCM 2.2 over HTTP: dev-only endpoints, gating, bounded context through the real app."""
import contextlib

import httpx

from app.llm.adapters.mock import MockLLMProvider
from app.main import create_app
from tests.conftest import make_settings, stream_events

TOKEN = {"X-KCM-Dev-Token": "s3cret"}
U2 = {"X-Mock-User": "user-2"}


@contextlib.asynccontextmanager
async def make_client(llm=None, **settings_kw):
    llm = llm or MockLLMProvider()
    app = create_app(make_settings(**settings_kw), provider=llm)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
            yield c, llm


DEV = dict(dev_mode=True, dev_token="s3cret", recent_message_limit=4, summary_trigger_tokens=40,
           summary_min_new_messages=1, summary_target_tokens=200)


async def test_dev_endpoints_hidden_by_default():
    async with make_client() as (c, _):
        cid = (await c.post("/api/conversations")).json()["id"]
        assert (await c.get(f"/api/conversations/{cid}/context-preview")).status_code == 404
        assert (await c.post(f"/api/conversations/{cid}/summarize")).status_code == 404
        assert (await c.get(f"/api/conversations/{cid}")).status_code == 200  # normal API untouched


async def test_dev_endpoints_need_token_and_ownership():
    async with make_client(**DEV) as (c, _):
        cid = (await c.post("/api/conversations")).json()["id"]
        url = f"/api/conversations/{cid}/context-preview"
        assert (await c.get(url)).status_code == 404  # no token
        assert (await c.get(url, headers={"X-KCM-Dev-Token": "wrong"})).status_code == 404
        assert (await c.get(url, headers={**TOKEN, **U2})).status_code == 404  # not the owner
        r = await c.get(url, headers=TOKEN)
        assert r.status_code == 200
        for k in ("total_conversation_tokens", "selected_tokens", "removed_tokens", "summary_tokens",
                  "recent_message_count", "relevant_message_count", "compression_level", "context_scores"):
            assert k in r.json()


async def test_long_conversation_is_bounded_and_summarize_endpoint_works():
    async with make_client(**DEV) as (c, llm):
        cid = (await c.post("/api/conversations")).json()["id"]
        await c.post("/api/chat", json={"conversation_id": cid, "message": "We decided to use PostgreSQL. The project must ship in March."})
        for i in range(12):
            r = await c.post("/api/chat", json={"conversation_id": cid, "message": f"Tell me about gardening topic {i}."})
            assert r.status_code == 200
        assert len(llm.calls[-1]) < 12  # not 25 messages
        msgs = (await c.get(f"/api/conversations/{cid}")).json()["messages"]
        assert len(msgs) == 26  # full history still stored
        s = await c.post(f"/api/conversations/{cid}/summarize", headers=TOKEN)
        assert s.status_code == 200 and "PostgreSQL" in s.json()["summary"] and s.json()["version"] >= 1
        p = (await c.get(f"/api/conversations/{cid}/context-preview", headers=TOKEN)).json()
        assert p["summary_used"] and p["messages_selected"] < p["messages_total"]


async def test_stream_done_event_carries_context_stats_only_in_dev_mode():
    async with make_client(**DEV) as (c, _):
        cid = (await c.post("/api/conversations")).json()["id"]
        _, ev = await stream_events(c, {"conversation_id": cid, "message": "Hello"})
        assert ev[-1][0] == "done" and "selected_tokens" in ev[-1][1]["context"]
    async with make_client() as (c, _):
        cid = (await c.post("/api/conversations")).json()["id"]
        _, ev = await stream_events(c, {"conversation_id": cid, "message": "Hello"})
        assert "context" not in ev[-1][1]  # normal users never see context internals


async def test_context_manager_can_be_disabled_for_exact_2_1_behaviour():
    async with make_client(context_manager_enabled=False, **{k: v for k, v in DEV.items() if k != "dev_mode"}) as (c, llm):
        cid = (await c.post("/api/conversations")).json()["id"]
        for i in range(3):
            await c.post("/api/chat", json={"conversation_id": cid, "message": f"m{i}"})
        assert [m.role for m in llm.calls[-1]] == ["system", "user", "assistant", "user", "assistant", "user"]
