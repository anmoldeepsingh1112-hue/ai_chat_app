"""Section 24 of the spec, end to end over HTTP (mock LLM)."""
from tests.conftest import stream_events


async def test_create_stream_reload_delete(client):
    cid = (await client.post("/api/conversations")).json()["id"]

    r, events = await stream_events(client, {"conversation_id": cid, "message": "Explain quantum mechanics"})
    assert r.status_code == 200
    assert events[-1][0] == "done"

    convo = (await client.get(f"/api/conversations/{cid}")).json()
    assert convo["title"] == "Explain quantum mechanics"
    assert [m["role"] for m in convo["messages"]] == ["user", "assistant"]

    # second turn: context now includes the first exchange
    await stream_events(client, {"conversation_id": cid, "message": "And entanglement?"})
    assert len((await client.get(f"/api/conversations/{cid}")).json()["messages"]) == 4

    assert (await client.delete(f"/api/conversations/{cid}")).status_code == 204
    assert (await client.get("/api/conversations")).json() == []
