import json

import httpx
import pytest
import pytest_asyncio

from app.core.config import Settings
from app.llm.adapters.mock import MockLLMProvider
from app.main import create_app


def make_settings(**kw) -> Settings:
    base = dict(
        database_url="sqlite+aiosqlite:///:memory:",
        auto_create_tables=True,
        max_retries=1,
        retry_delay=0.0,
        llm_timeout=1.0,
        log_level="CRITICAL",
    )
    base.update(kw)
    return Settings(_env_file=None, **base)


@pytest.fixture
def settings() -> Settings:
    return make_settings()


@pytest.fixture
def mock_llm() -> MockLLMProvider:
    return MockLLMProvider()


@pytest_asyncio.fixture
async def app(settings, mock_llm):
    application = create_app(settings, provider=mock_llm)
    async with application.router.lifespan_context(application):
        yield application


@pytest_asyncio.fixture
async def client(app):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as c:
        yield c


def parse_sse(raw: str) -> list[tuple[str, dict]]:
    events = []
    for block in raw.strip().split("\n\n"):
        lines = dict(l.split(": ", 1) for l in block.splitlines())
        events.append((lines["event"], json.loads(lines["data"])))
    return events


async def stream_events(client, payload, headers=None):
    async with client.stream("POST", "/api/chat/stream", json=payload, headers=headers) as r:
        raw = (await r.aread()).decode()
        return r, (parse_sse(raw) if r.headers["content-type"].startswith("text/event-stream") else raw)
