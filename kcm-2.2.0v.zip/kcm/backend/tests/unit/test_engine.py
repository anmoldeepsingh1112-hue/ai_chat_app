import pytest
from sqlalchemy import select

from app.core.errors import ConversationNotFoundError, InvalidRequestError, LLMTimeoutError
from app.database.database import Base, make_engine, make_session_factory
from app.database.models import LLMRequest
from app.llm.adapters.mock import MockLLMProvider
from app.orchestrator.engine import KCMEngine
from app.orchestrator.prompt_builder import PromptBuilder
from app.services.conversation_service import ConversationService
from app.services.prompt_service import PromptService
from tests.conftest import make_settings


@pytest.fixture
async def env():
    settings = make_settings()
    eng = make_engine(settings.database_url)
    async with eng.begin() as c:
        await c.run_sync(Base.metadata.create_all)
    factory = make_session_factory(eng)
    async with factory() as session:
        yield session, settings
    await eng.dispose()


def engine_for(session, settings, provider):
    return KCMEngine(session, provider, settings, PromptBuilder(PromptService(settings)))


async def test_process_message_saves_both_and_sends_context(env):
    session, settings = env
    llm = MockLLMProvider()
    conv = await ConversationService(session).create("u1")
    e = engine_for(session, settings, llm)

    r1 = await e.process_message(conv.id, "Hello", "u1")
    assert r1.message.content == "Hello! I am KCM." and r1.message.role == "assistant"
    await e.process_message(conv.id, "Explain quantum mechanics.", "u1")

    sent = llm.calls[-1]
    assert [m.role for m in sent] == ["system", "user", "assistant", "user"]
    stored = (await ConversationService(session).get("u1", conv.id, True)).messages
    assert [m.role for m in stored] == ["user", "assistant", "user", "assistant"]


async def test_title_from_first_message_and_usage_row(env):
    session, settings = env
    conv = await ConversationService(session).create("u1")
    await engine_for(session, settings, MockLLMProvider()).process_message(conv.id, "Hello", "u1")
    assert conv.title == "Hello"
    row = (await session.scalars(select(LLMRequest))).one()
    assert row.status == "ok" and row.total_tokens == row.input_tokens + row.output_tokens and row.latency_ms >= 0


async def test_llm_failure_saves_nothing_and_records_error(env):
    session, settings = env
    conv = await ConversationService(session).create("u1")
    e = engine_for(session, settings, MockLLMProvider(fail_with=LLMTimeoutError()))
    with pytest.raises(LLMTimeoutError):
        await e.process_message(conv.id, "Hello", "u1")
    assert (await ConversationService(session).get("u1", conv.id, True)).messages == []
    row = (await session.scalars(select(LLMRequest))).one()
    assert (row.status, row.error_code) == ("error", "LLM_TIMEOUT")


async def test_not_found_wrong_user_and_empty(env):
    session, settings = env
    conv = await ConversationService(session).create("u1")
    e = engine_for(session, settings, MockLLMProvider())
    with pytest.raises(ConversationNotFoundError):
        await e.process_message("nope", "hi", "u1")
    with pytest.raises(ConversationNotFoundError):
        await e.process_message(conv.id, "hi", "someone-else")
    with pytest.raises(InvalidRequestError):
        await e.process_message(conv.id, "  ", "u1")


async def test_stream_events_and_final_content(env):
    session, settings = env
    conv = await ConversationService(session).create("u1")
    e = engine_for(session, settings, MockLLMProvider(response="a b c d"))
    events = [ev async for ev in e.stream_message(conv.id, "go", "u1")]
    assert [ev.type for ev in events] == ["start", "delta", "delta", "delta", "delta", "done"]
    saved = (await ConversationService(session).get("u1", conv.id, True)).messages[-1]
    assert saved.content == "a b c d" and events[-1].data["message_id"] == saved.id
