import pytest

from app.core.config import Settings
from app.core.errors import InvalidRequestError
from app.database.models import Message
from app.orchestrator.prompt_builder import PromptBuilder, to_chat_messages, validate_user_message
from app.services.prompt_service import DEFAULT_SYSTEM_PROMPT, PromptService
from tests.conftest import make_settings


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "openai")
    monkeypatch.setenv("LLM_TIMEOUT", "12.5")
    monkeypatch.setenv("MAX_RETRIES", "5")
    s = Settings(_env_file=None)
    assert (s.llm_provider, s.llm_timeout, s.max_retries) == ("openai", 12.5, 5)


def test_api_key_is_secret_in_repr():
    s = Settings(_env_file=None, llm_api_key="sk-super-secret")
    assert "sk-super-secret" not in repr(s)
    assert s.llm_api_key.get_secret_value() == "sk-super-secret"


def test_default_and_custom_system_prompt():
    assert PromptService(make_settings()).system_prompt == DEFAULT_SYSTEM_PROMPT
    assert PromptService(make_settings(system_prompt="Be terse.")).system_prompt == "Be terse."


def _msg(role, content):
    return Message(id="x", conversation_id="c", role=role, content=content)


def test_prompt_construction_order():
    b = PromptBuilder(PromptService(make_settings()))
    out = b.build([_msg("user", "Hello"), _msg("assistant", "Hi!")], "Explain quantum mechanics.")
    assert [m.role for m in out] == ["system", "user", "assistant", "user"]
    assert out[0].content == DEFAULT_SYSTEM_PROMPT
    assert out[-1].content == "Explain quantum mechanics."


def test_history_truncation_keeps_recent():
    b = PromptBuilder(PromptService(make_settings()), max_history_messages=2)
    hist = [_msg("user", str(i)) for i in range(5)]
    out = b.build(hist, "new")
    assert [m.content for m in out[1:]] == ["3", "4", "new"]


def test_message_conversion_drops_unknown_roles():
    out = to_chat_messages([_msg("tool", "x"), _msg("user", "y")])
    assert [(m.role, m.content) for m in out] == [("user", "y")]


@pytest.mark.parametrize("text", ["", "   ", "\n\t"])
def test_empty_message_rejected(text):
    with pytest.raises(InvalidRequestError):
        validate_user_message(text, 100)


def test_long_message_rejected_and_trimmed_ok():
    with pytest.raises(InvalidRequestError):
        validate_user_message("a" * 101, 100)
    assert validate_user_message("  hi  ", 100) == "hi"
