"""KCM 2.2 context-management tests (spec section 26, Tests 1-10 + extras). Pure logic: no DB, no HTTP."""
import random
from types import SimpleNamespace

from app.context import (ContextConfig, ContextManager, ContextMessage, ExtractiveSummarizer, FallbackSummarizer,
                         InMemoryStore, ModelConfig, TokenManager, history_from_db)
from app.llm.base import ChatMessage

MODEL = ModelConfig("test", context_limit=8000, reserved_output_tokens=500)
FILLER = ["Let's talk about {} for a while.", "I read that {} is fascinating in many respects.", "Could you explain more about {}?"]
TOPICS = ["quantum mechanics", "gardening tomatoes", "medieval history", "jazz piano", "marathon training", "volcanoes"]
CID = "c1"


def cfg(**kw):
    base = dict(recent_message_limit=10, summary_trigger_tokens=300, summary_target_tokens=200)
    base.update(kw)
    return ContextConfig(**base)


async def make(n, config=None, special=None):
    """n alternating user/assistant filler messages; `special` = {index: text}."""
    store, special, rnd = InMemoryStore(), special or {}, random.Random(1)
    for i in range(n):
        txt = special.get(i) or rnd.choice(FILLER).format(rnd.choice(TOPICS)) + f" (turn {i})"
        await store.add_message(CID, ContextMessage(f"m{i}", "user" if i % 2 == 0 else "assistant", txt))
    return store, ContextManager(store, config or cfg())


def texts(r):
    return [m.content for m in r.messages]


async def test01_short_conversation_keeps_all():
    store, cm = await make(5)
    r = await cm.build_context(CID, "And what about tomatoes?", MODEL)
    assert len(r.recent_messages) == 5 and r.removed_messages == []


async def test02_long_conversation_not_all_sent():
    store, cm = await make(500)
    r = await cm.build_context(CID, "What database architecture is best?", MODEL)
    assert len(r.messages) < 40
    assert r.trace.selected_token_count < r.trace.original_token_count / 5


async def test03_relevant_old_info_retrieved():
    store, cm = await make(200, special={20: "The project uses Python for the backend."})
    r = await cm.build_context(CID, "What language does the project use?", MODEL)
    assert any("Python" in t for t in texts(r))  # via summary or raw message
    cm.cfg.compression_level = 1  # relevance path only
    r = await cm.build_context(CID, "What language does the project use?", MODEL)
    assert "m20" in [m.id for m in r.relevant_messages]


async def test04_irrelevant_old_info_deprioritised():
    store, cm = await make(200, special={20: "Quantum mechanics: superposition collapses upon measurement."})
    r = await cm.build_context(CID, "Which database architecture is best for orders?", MODEL)
    assert "m20" not in [m.id for m in r.relevant_messages]
    assert r.historical_messages_used == len(r.relevant_messages)


async def test05_context_overflow_stays_in_budget():
    small = ModelConfig("tiny", context_limit=600, reserved_output_tokens=200)
    store, cm = await make(500, cfg(recent_message_limit=50))
    cm.system_prompt = "You are a helpful assistant."
    for lvl in (0, 1, 2, 3):
        cm.cfg.compression_level = lvl
        r = await cm.build_context(CID, "Summarise where we are.", small)
        assert r.total_tokens + small.reserved_output_tokens <= small.context_limit, f"level {lvl}"


async def test06_recent_kept_despite_low_similarity():
    store, cm = await make(100)
    r = await cm.build_context(CID, "zzz unrelated xylophone", MODEL)
    assert [m.id for m in r.recent_messages] == [f"m{i}" for i in range(90, 100)]


async def test07_summary_preserves_important_info():
    sp = {4: "I must deploy on Kubernetes and the deadline is March 3.", 6: "We decided to use PostgreSQL for the database."}
    store, cm = await make(120, special=sp)
    r = await cm.build_context(CID, "Continue.", MODEL)
    assert r.summary_used and "Kubernetes" in r.summary and "PostgreSQL" in r.summary
    assert len(await store.get_messages(CID)) == 120  # never deleted


async def test08_incremental_summary():
    store, cm = await make(120, special={4: "We decided to use PostgreSQL for the database."})
    await cm.build_context(CID, "go", MODEL)
    s1, calls1 = await store.get_summary(CID), cm.summarizer.calls
    for i in range(120, 140):
        await store.add_message(CID, ContextMessage(f"m{i}", "user" if i % 2 == 0 else "assistant",
                                                    "Actually we now use MySQL instead." if i == 126 else f"filler {i}"))
    await cm.build_context(CID, "go", MODEL)
    s2 = await store.get_summary(CID)
    assert s2.version == s1.version + 1 and cm.summarizer.calls == calls1 + 1
    assert "PostgreSQL" in s2.summary and "MySQL" in s2.summary and s2.covered_message_end > s1.covered_message_end
    await cm.build_context(CID, "again", MODEL)  # nothing new -> no extra summarizer call
    assert cm.summarizer.calls == calls1 + 1


async def test09_duplicates_removed():
    store, dup = InMemoryStore(), "The user is building an AI chatbot."
    for i in range(40):
        await store.add_message(CID, ContextMessage(f"m{i}", "user", dup if i in (2, 38) else f"chat {i} about weather"))
    cm = ContextManager(store, ContextConfig(recent_message_limit=5, compression_level=1))
    r = await cm.build_context(CID, "What chatbot is the user building?", MODEL)
    assert "m38" in [m.id for m in r.recent_messages]  # inside the recent window
    assert "m2" not in [m.id for m in r.relevant_messages]  # identical older copy dropped
    assert sum(dup in t for t in texts(r)) == 1


async def test10_current_message_never_removed():
    tiny = ModelConfig("tiny", context_limit=120, reserved_output_tokens=20)
    store, cm = await make(50)
    big = "Please analyse this. " + "word " * 300
    r = await cm.build_context(CID, big, tiny)
    assert r.messages[-1] == ChatMessage("user", big)
    assert "current_message_exceeds_budget" in r.warnings and r.recent_messages == []


async def test11_importance_protects_old_message():
    store, cm = await make(200, special={6: "Budget is fixed at 5000 dollars, hard limit."}, config=cfg(compression_level=1))
    await cm.mark_important(await store.get_messages(CID), "m6", 0.95)
    r = await cm.build_context(CID, "xylophone", MODEL)
    assert "m6" in [m.id for m in r.relevant_messages]


async def test12_correction_is_not_deduped_against_summary():
    """Regression (found by the benchmark): the summary holds ONLY the correction, the stale fact arrives as a raw
    message. Dedup must not drop the raw correction, otherwise the stale fact would be the last thing the model sees."""
    from app.context import ContextBuilder
    old = ContextMessage("old", "user", "The project database is PostgreSQL.", seq=30)
    fix = ContextMessage("fix", "user", "Actually, the project database is now MySQL instead of PostgreSQL.", seq=200)
    summary = "- [user] Actually, the project database is now MySQL instead of PostgreSQL."
    r = await ContextBuilder(TokenManager(), ContextConfig()).build(
        "", "Which database now?", [], summary, [old, fix], token_budget=5000, scores={"old": 0.9, "fix": 0.5})
    assert [m.id for m in r.relevant_messages] == ["old", "fix"]  # correction kept, chronological order preserved
    lines = [l for m in r.messages for l in m.content.splitlines() if "project database" in l]
    assert "MySQL" in lines[-1], lines


async def test13_dry_run_persists_nothing_and_traces_nothing():
    store, cm = await make(120, special={4: "We decided to use PostgreSQL for the database."})
    p = await cm.preview(CID, MODEL)
    assert await store.get_summary(CID) is None and cm.traces == []
    for k in ("total_conversation_tokens", "selected_tokens", "removed_tokens", "summary_tokens",
              "recent_message_count", "relevant_message_count", "compression_level", "context_scores"):
        assert k in p


async def test14_summarizer_failure_keeps_chat_working():
    class Boom:
        calls = 0

        async def summarize(self, *a):
            raise RuntimeError("llm down")

    store, cm = await make(120)
    cm.summarizer = Boom()
    r = await cm.build_context(CID, "go", MODEL)
    assert r.messages[-1].content == "go" and not r.summary_used
    cm.summarizer = FallbackSummarizer(Boom(), ExtractiveSummarizer())
    store2, cm2 = await make(120, special={4: "We decided to use PostgreSQL for the database."})
    cm2.summarizer = FallbackSummarizer(Boom(), ExtractiveSummarizer())
    assert "PostgreSQL" in (await cm2.build_context(CID, "go", MODEL)).summary


async def test15_cached_token_counts_are_used():
    tm = TokenManager()
    m = ContextMessage("x", "user", "word " * 100, token_count=7)
    assert tm.count_message(m) == 7 + tm.per_message_overhead


async def test16_db_rows_convert_and_unknown_roles_skipped():
    rows = [SimpleNamespace(id="a", role="user", content="hi", importance=0.9, token_count=3, embedding_reference=None),
            SimpleNamespace(id="b", role="tool", content="x", importance=None, token_count=None, embedding_reference=None),
            SimpleNamespace(id="c", role="assistant", content="yo", importance=None, token_count=None, embedding_reference="c")]
    h = history_from_db(rows)
    assert [m.id for m in h] == ["a", "c"] and [m.seq for m in h] == [0, 1]
    assert h[0].metadata["importance"] == 0.9 and h[0].token_count == 3


async def test17_history_argument_skips_store_lookup():
    store, cm = await make(0)
    hist = [ContextMessage(f"m{i}", "user" if i % 2 == 0 else "assistant", f"msg {i}", seq=i) for i in range(6)]
    r = await cm.build_context(CID, "next", MODEL, history=hist)  # store has no messages: history must be used
    assert len(r.recent_messages) == 6
