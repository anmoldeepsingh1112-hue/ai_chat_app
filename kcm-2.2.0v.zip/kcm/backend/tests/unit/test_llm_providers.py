import json

import httpx
import pytest

from app.core.errors import (
    LLMAuthError, LLMBadRequestError, LLMError, LLMRateLimitError, LLMTimeoutError, StreamInterruptedError,
)
from app.llm.adapters.mock import MockLLMProvider
from app.llm.adapters.openai_compatible import OpenAICompatibleProvider
from app.llm.base import ChatMessage, LLMProvider
from app.llm.provider import RetryingProvider, build_provider
from tests.conftest import make_settings

MSGS = [ChatMessage("system", "s"), ChatMessage("user", "Hello")]


async def collect(provider, msgs=MSGS):
    return [c async for c in provider.stream(msgs)]


# ---- mock ----
async def test_mock_is_deterministic_and_matches_interface():
    p = MockLLMProvider()
    assert isinstance(p, LLMProvider)
    assert (await p.generate(MSGS)).content == "Hello! I am KCM."
    assert (await p.generate(MSGS)).content == "Hello! I am KCM."


async def test_mock_stream_chunks_join_to_full_text_with_usage():
    chunks = await collect(MockLLMProvider())
    assert len([c for c in chunks if c.text]) > 1
    assert "".join(c.text for c in chunks) == "Hello! I am KCM."
    assert chunks[-1].usage and chunks[-1].usage.total_tokens


# ---- retry wrapper ----
def wrap(inner, retries=2, timeout=0.2):
    return RetryingProvider(inner, timeout=timeout, max_retries=retries, retry_delay=0.0)


async def test_retry_then_succeed():
    inner = MockLLMProvider(fail_with=LLMError(), fail_times=2)
    assert (await wrap(inner, retries=2).generate(MSGS)).content == "Hello! I am KCM."
    assert len(inner.calls) == 3


async def test_retries_are_bounded():
    inner = MockLLMProvider(fail_with=LLMRateLimitError())
    with pytest.raises(LLMRateLimitError):
        await wrap(inner, retries=2).generate(MSGS)
    assert len(inner.calls) == 3  # 1 try + 2 retries, never infinite


async def test_auth_error_not_retried():
    inner = MockLLMProvider(fail_with=LLMAuthError())
    with pytest.raises(LLMAuthError):
        await wrap(inner).generate(MSGS)
    assert len(inner.calls) == 1


async def test_timeout_raises_llm_timeout_after_retries():
    inner = MockLLMProvider(delay=0.5)
    with pytest.raises(LLMTimeoutError):
        await wrap(inner, retries=1, timeout=0.05).generate(MSGS)
    assert len(inner.calls) == 2


async def test_stream_retry_before_first_chunk():
    inner = MockLLMProvider(fail_with=LLMError(), fail_times=1)
    chunks = await collect(wrap(inner))
    assert "".join(c.text for c in chunks) == "Hello! I am KCM."


async def test_stream_failure_after_chunks_is_interruption_not_retry():
    inner = MockLLMProvider(response="one two three four", fail_after_chunks=2, fail_with=LLMError())
    got = []
    with pytest.raises(StreamInterruptedError):
        async for c in wrap(inner).stream(MSGS):
            got.append(c.text)
    assert got == ["one ", "two "]
    assert len(inner.calls) == 1


# ---- OpenAI-compatible adapter (no network: httpx.MockTransport) ----
def adapter(handler):
    return OpenAICompatibleProvider("sk-test", "http://llm/v1", "gpt-x", 5, httpx.MockTransport(handler))


async def test_openai_generate_parses_content_and_usage():
    seen = {}

    def handler(req: httpx.Request):
        seen["auth"], seen["body"] = req.headers["authorization"], json.loads(req.content)
        return httpx.Response(200, json={
            "choices": [{"message": {"content": "hi there"}}],
            "usage": {"prompt_tokens": 7, "completion_tokens": 3},
        })

    r = await adapter(handler).generate(MSGS, temperature=0.2, max_tokens=50)
    assert r.content == "hi there" and (r.usage.input_tokens, r.usage.output_tokens) == (7, 3)
    assert seen["auth"] == "Bearer sk-test"
    assert seen["body"]["model"] == "gpt-x" and seen["body"]["max_tokens"] == 50
    assert seen["body"]["messages"][1] == {"role": "user", "content": "Hello"}


async def test_openai_stream_parses_sse():
    lines = [
        {"choices": [{"delta": {"role": "assistant"}}]},
        {"choices": [{"delta": {"content": "Hel"}}]},
        {"choices": [{"delta": {"content": "lo"}}]},
        {"choices": [], "usage": {"prompt_tokens": 4, "completion_tokens": 2}},
    ]
    body = "".join(f"data: {json.dumps(l)}\n\n" for l in lines) + "data: [DONE]\n\n"
    chunks = await collect(adapter(lambda r: httpx.Response(200, content=body.encode())))
    assert "".join(c.text for c in chunks) == "Hello"
    assert chunks[-1].usage.total_tokens == 6


@pytest.mark.parametrize("status,exc", [
    (401, LLMAuthError), (403, LLMAuthError), (429, LLMRateLimitError),
    (504, LLMTimeoutError), (500, LLMError), (400, LLMBadRequestError),
])
async def test_openai_status_mapping(status, exc):
    p = adapter(lambda r: httpx.Response(status, text="boom"))
    with pytest.raises(exc):
        await p.generate(MSGS)
    with pytest.raises(exc):
        await collect(p)


async def test_openai_network_timeout_mapped():
    def handler(req):
        raise httpx.ReadTimeout("slow", request=req)

    with pytest.raises(LLMTimeoutError):
        await adapter(handler).generate(MSGS)


def test_adapter_repr_hides_key():
    assert "sk-test" not in repr(adapter(lambda r: httpx.Response(200)))


# ---- factory ----
def test_factory_builds_mock_and_rejects_unknown():
    assert build_provider(make_settings(llm_provider="mock")).name == "mock"
    with pytest.raises(Exception):
        build_provider(make_settings(llm_provider="nope"))


def test_factory_requires_key_for_openai():
    with pytest.raises(Exception):
        build_provider(make_settings(llm_provider="openai"))
    assert build_provider(make_settings(llm_provider="openai", llm_api_key="k")).name == "openai"
