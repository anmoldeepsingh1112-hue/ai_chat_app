"""KCM 2.2 engine integration against SQLite (mirrors tests/unit/test_engine.py)."""
import pytest
from sqlalchemy import select

from app.context.factory import build_context_manager, build_runtime
from app.database.database import Base, make_engine, make_session_factory
from app.database.models import ContextTraceRow, ConversationSummary, LLMRequest, Message
from app.llm.adapters.mock import MockLLMProvider
from app.orchestrator.engine import KCMEngine
from app.orchestrator.prompt_builder import PromptBuilder
from app.services.conversation_service import ConversationService
from app.services.prompt_service import PromptService
from tests.conftest import make_settings


@pytest.fixture
async def env():
    settings = make_settings(recent_message_limit=4, summary_trigger_tokens=40, summary_min_new_messages=2,
                             summary_target_tokens=200)
    eng = make_engine(settings.database_url)
    async with eng.begin() as c:
        await c.run_sync(Base.metadata.create_all)
    factory = make_session_factory(eng)
    async with factory() as session:
        yield session, settings
    await eng.dispose()


def engine_for(session, settings, provider):
    builder = PromptBuilder(PromptService(settings), settings.max_history_messages)
    cm = build_context_manager(build_runtime(settings), session, provider, settings, builder.system_prompt)
    return KCMEngine(session, provider, settings, builder, cm), cm


async def test_long_conversation_sends_bounded_context_and_records_everything(env):
    session, settings = env
    llm = MockLLMProvider()
    conv = await ConversationService(session).create("u1")
    e, _ = engine_for(session, settings, llm)
    await e.process_message(conv.id, "We decided to use PostgreSQL for the database. The project must ship in March.", "u1")
    for i in range(15):
        await e.process_message(conv.id, f"Tell me something about gardening topic {i}.", "u1")

    stored = (await ConversationService(session).get("u1", conv.id, True)).messages
    assert len(stored) == 32  # nothing is ever deleted
    assert len(llm.calls[-1]) < 12  # system + summary/relevant blocks + 4 recent + current, NOT 31 messages
    summary = (await session.scalars(select(ConversationSummary))).one()
    assert summary.version >= 1 and "PostgreSQL" in summary.summary
    traces = (await session.scalars(select(ContextTraceRow))).all()
    assert len(traces) == 16 and traces[-1].selected_token_count < traces[-1].original_token_count
    assert all(t.request_id is not None for t in traces)
    assert len((await session.scalars(select(LLMRequest))).all()) == 16  # 2.1 usage tracking unchanged
    assert all(m.token_count is not None for m in stored)  # counts cached for later builds


async def test_context_manager_bug_falls_back_to_2_1_behaviour(env):
    session, settings = env
    llm = MockLLMProvider()
    conv = await ConversationService(session).create("u1")
    e, cm = engine_for(session, settings, llm)

    async def boom(*a, **k):
        raise RuntimeError("bug in context layer")

    cm.build_context = boom
    out = await e.process_message(conv.id, "Hello", "u1")
    assert out.message.content == "Hello! I am KCM."
    assert [m.role for m in llm.calls[-1]] == ["system", "user"]  # plain 2.1 prompt
    assert (await session.scalars(select(ContextTraceRow))).all() == []


async def test_2_1_constructor_still_works_without_context_manager(env):
    session, settings = env
    llm = MockLLMProvider()
    conv = await ConversationService(session).create("u1")
    e = KCMEngine(session, llm, settings, PromptBuilder(PromptService(settings)))  # exact 2.1 signature
    await e.process_message(conv.id, "Hello", "u1")
    await e.process_message(conv.id, "Again", "u1")
    assert [m.role for m in llm.calls[-1]] == ["system", "user", "assistant", "user"]
    assert (await session.scalars(select(Message))).all()[0].token_count is None
