import { CommonModule } from '@angular/common';
import { Component, computed, inject, input } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectService } from '../../../core/services/project.service';
import { ConversationService } from '../../../core/services/conversation.service';
import { FileService } from '../../../core/services/file.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';

@Component({
  selector: 'app-project-detail',
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  templateUrl: './project-detail.component.html',
  styleUrl: './project-detail.component.scss',
})
export class ProjectDetailComponent {
  id = input.required<string>();

  private projects = inject(ProjectService);
  private conversations = inject(ConversationService);
  private router = inject(Router);
  fileService = inject(FileService);

  project = computed(() => this.projects.getById(this.id()));

  updateInstructions(value: string): void {
    this.projects.updateInstructions(this.id(), value);
  }

  newChatInProject(): void {
    const conv = this.conversations.create('balanced', this.id());
    this.router.navigate(['/chat', conv.id]);
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) this.projects.addFile(this.id(), file.name, file.size);
    input.value = '';
  }
}
