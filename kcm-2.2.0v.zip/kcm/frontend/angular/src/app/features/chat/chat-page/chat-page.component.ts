import { CommonModule } from '@angular/common';
import { Component, computed, effect, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AiModelId } from '../../../core/models/conversation.model';
import { Attachment } from '../../../core/models/attachment.model';
import { ConversationService } from '../../../core/services/conversation.service';
import { ChatService } from '../../../core/services/chat.service';
import { ChatMessageComponent } from '../chat-message/chat-message.component';
import { ChatComposerComponent } from '../chat-composer/chat-composer.component';

const SUGGESTIONS = [
  'Explain quantum mechanics',
  'Analyze a document',
  'Help me write code',
  'Research a topic',
  'Brainstorm an idea',
  'Explain this concept',
];

@Component({
  selector: 'app-chat-page',
  standalone: true,
  imports: [CommonModule, ChatMessageComponent, ChatComposerComponent],
  templateUrl: './chat-page.component.html',
  styleUrl: './chat-page.component.scss',
})
export class ChatPageComponent {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private conversationsSvc = inject(ConversationService);
  chat = inject(ChatService);

  suggestions = SUGGESTIONS;
  composerPrefill = signal('');

  conversationId = signal<string | null>(null);
  conversation = computed(() => {
    const id = this.conversationId();
    return id ? this.conversationsSvc.getById(id) : undefined;
  });
  messages = computed(() => {
    const id = this.conversationId();
    return id ? this.chat.messagesFor(id) : [];
  });
  model = computed<AiModelId>(() => this.conversation()?.model ?? 'balanced');
  isBusy = computed(() => this.chat.status() === 'thinking' || this.chat.status() === 'streaming');

  constructor() {
    this.route.paramMap.subscribe((params) => {
      this.conversationId.set(params.get('id'));
    });
  }

  useSuggestion(text: string): void {
    this.composerPrefill.set(text);
  }

  onModelChange(model: AiModelId): void {
    const id = this.conversationId();
    if (id) this.conversationsSvc.update(id, { model });
  }

  onSend(payload: { text: string; attachments: Attachment[] }): void {
    let id = this.conversationId();
    if (!id) {
      const conv = this.conversationsSvc.create(this.model());
      id = conv.id;
      this.router.navigate(['/chat', id]);
    }
    this.chat.sendMessage(id, payload.text, this.model());
    this.composerPrefill.set('');
  }

  onRegenerate(messageId: string): void {
    const id = this.conversationId();
    if (id) this.chat.regenerate(id, messageId, this.model());
  }

  onLike(messageId: string): void {
    this.toggleReaction(messageId, 'liked');
  }

  onDislike(messageId: string): void {
    this.toggleReaction(messageId, 'disliked');
  }

  private toggleReaction(messageId: string, field: 'liked' | 'disliked'): void {
    const id = this.conversationId();
    if (!id) return;
    const msgs = this.chat.messagesByConversation();
    const list = msgs[id] ?? [];
    const updated = list.map((m) => (m.id === messageId ? { ...m, [field]: !m[field] } : m));
    this.chat.messagesByConversation.set({ ...msgs, [id]: updated });
  }
}
