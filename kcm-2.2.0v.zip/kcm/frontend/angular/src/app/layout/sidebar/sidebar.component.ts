import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { ConversationService } from '../../core/services/conversation.service';
import { AuthService } from '../../core/services/auth.service';
import { AvatarComponent } from '../../shared/components/avatar/avatar.component';
import { DropdownComponent, DropdownItem } from '../../shared/components/dropdown/dropdown.component';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, AvatarComponent, DropdownComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent {
  @Output() collapsedChange = new EventEmitter<boolean>();

  collapsed = signal(false);
  conversations = inject(ConversationService);
  auth = inject(AuthService);
  private router = inject(Router);

  conversationActions: DropdownItem[] = [
    { id: 'rename', label: 'Rename' },
    { id: 'pin', label: 'Pin' },
    { id: 'archive', label: 'Archive' },
    { id: 'delete', label: 'Delete', danger: true },
  ];

  toggleCollapsed(): void {
    this.collapsed.update((v) => !v);
    this.collapsedChange.emit(this.collapsed());
  }

  newChat(): void {
    const conv = this.conversations.create();
    this.router.navigate(['/chat', conv.id]);
  }

  onConversationAction(id: string, item: DropdownItem): void {
    switch (item.id) {
      case 'rename': {
        const conv = this.conversations.getById(id);
        const title = window.prompt('Rename conversation', conv?.title ?? '');
        if (title) this.conversations.rename(id, title);
        break;
      }
      case 'pin':
        this.conversations.togglePin(id);
        break;
      case 'archive':
        this.conversations.toggleArchive(id);
        if (this.router.url === `/chat/${id}`) this.router.navigate(['/chat']);
        break;
      case 'delete':
        this.conversations.delete(id);
        if (this.router.url === `/chat/${id}`) this.router.navigate(['/chat']);
        break;
    }
  }

  footerAction(item: DropdownItem): void {
    if (item.id === 'logout') this.logout();
    if (item.id === 'settings') this.router.navigate(['/settings']);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/']);
  }
}
