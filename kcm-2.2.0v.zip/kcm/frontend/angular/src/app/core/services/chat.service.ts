import { Injectable, signal } from '@angular/core';
import { Subject, takeUntil, timer } from 'rxjs';
import { AiModelId, AiModelOption } from '../models/conversation.model';
import { ChatMessage, MessageStatus } from '../models/message.model';
import { ConversationService } from './conversation.service';

export const AI_MODELS: AiModelOption[] = [
  { id: 'fast', name: 'Fast', description: 'Quick everyday responses' },
  { id: 'balanced', name: 'Balanced', description: 'General-purpose AI' },
  { id: 'reasoning', name: 'Reasoning', description: 'Complex reasoning and analysis' },
  { id: 'advanced', name: 'Advanced', description: 'Maximum capability' },
];

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * ChatService owns the streaming lifecycle for a single active conversation.
 * In production this would open an SSE/WebSocket connection to POST /api/chat
 * and progressively append `data:` chunks. Here it's mocked with RxJS timers
 * so the UI, states, and cancellation logic are all real and swappable later.
 */
@Injectable({ providedIn: 'root' })
export class ChatService {
  readonly status = signal<MessageStatus>('idle');
  readonly messagesByConversation = signal<Record<string, ChatMessage[]>>({});

  private cancelStream$ = new Subject<void>();

  constructor(private conversations: ConversationService) {}

  messagesFor(conversationId: string): ChatMessage[] {
    return this.messagesByConversation()[conversationId] ?? [];
  }

  sendMessage(conversationId: string, text: string, model: AiModelId): void {
    const userMsg: ChatMessage = {
      id: uid('msg'),
      role: 'user',
      content: text,
      createdAt: Date.now(),
      status: 'completed',
    };
    this.appendMessage(conversationId, userMsg);
    this.conversations.deriveTitleFromFirstMessage(conversationId, text);

    const assistantId = uid('msg');
    const assistantMsg: ChatMessage = {
      id: assistantId,
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
      status: 'thinking',
    };
    this.appendMessage(conversationId, assistantMsg);
    this.status.set('thinking');

    this.cancelStream$.next();

    const reply = this.mockReplyFor(text, model);
    const words = reply.split(' ');

    timer(500)
      .pipe(takeUntil(this.cancelStream$))
      .subscribe(() => {
        this.status.set('streaming');
        this.updateMessage(conversationId, assistantId, { status: 'streaming' });
        this.streamWords(conversationId, assistantId, words, 0);
      });
  }

  regenerate(conversationId: string, assistantMessageId: string, model: AiModelId): void {
    const msgs = this.messagesFor(conversationId);
    const idx = msgs.findIndex((m) => m.id === assistantMessageId);
    const priorUserMsg = [...msgs.slice(0, idx)].reverse().find((m) => m.role === 'user');
    if (!priorUserMsg) return;

    this.updateMessage(conversationId, assistantMessageId, { content: '', status: 'thinking' });
    this.status.set('thinking');
    this.cancelStream$.next();

    const reply = this.mockReplyFor(priorUserMsg.content, model, true);
    const words = reply.split(' ');

    timer(400)
      .pipe(takeUntil(this.cancelStream$))
      .subscribe(() => {
        this.status.set('streaming');
        this.updateMessage(conversationId, assistantMessageId, { status: 'streaming' });
        this.streamWords(conversationId, assistantMessageId, words, 0);
      });
  }

  stopStreaming(): void {
    this.cancelStream$.next();
    this.status.set('idle');
  }

  private streamWords(conversationId: string, messageId: string, words: string[], index: number): void {
    if (index >= words.length) {
      this.updateMessage(conversationId, messageId, { status: 'completed' });
      this.status.set('completed');
      return;
    }
    timer(18 + Math.random() * 35)
      .pipe(takeUntil(this.cancelStream$))
      .subscribe(() => {
        const current = this.messagesFor(conversationId).find((m) => m.id === messageId);
        const nextContent = (current?.content ?? '') + (index === 0 ? '' : ' ') + words[index];
        this.updateMessage(conversationId, messageId, { content: nextContent, status: 'streaming' });
        this.streamWords(conversationId, messageId, words, index + 1);
      });
  }

  private appendMessage(conversationId: string, message: ChatMessage): void {
    this.messagesByConversation.update((map) => ({
      ...map,
      [conversationId]: [...(map[conversationId] ?? []), message],
    }));
  }

  private updateMessage(conversationId: string, messageId: string, patch: Partial<ChatMessage>): void {
    this.messagesByConversation.update((map) => ({
      ...map,
      [conversationId]: (map[conversationId] ?? []).map((m) =>
        m.id === messageId ? { ...m, ...patch } : m,
      ),
    }));
  }

  private mockReplyFor(prompt: string, model: AiModelId, regenerated = false): string {
    const prefix = regenerated ? "Here's another way to look at it: " : '';
    const modelNote = model === 'reasoning' || model === 'advanced'
      ? 'Let me work through this carefully step by step. '
      : '';
    return (
      prefix +
      modelNote +
      `Based on what you asked — "${prompt.slice(0, 60)}" — here is a helpful, structured response. ` +
      'This mock reply streams in progressively to demonstrate the SSE-style rendering pipeline, ' +
      'including markdown support, code blocks, and smooth token-by-token display. ' +
      'In production this text is replaced by real tokens forwarded from the backend AI gateway.'
    );
  }
}
