import { Injectable, computed, signal } from '@angular/core';
import { AiModelId, Conversation } from '../models/conversation.model';

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

const SEED: Conversation[] = [
  mk('Refactoring auth middleware', 1000 * 60 * 30),
  mk('Explain transformer attention', 1000 * 60 * 60 * 2),
  mk('Trip itinerary for Kyoto', 1000 * 60 * 60 * 5),
  mk('Weekly report summary', 1000 * 60 * 60 * 26),
  mk('Debugging RxJS memory leak', 1000 * 60 * 60 * 30),
  mk('SQL query optimization', 1000 * 60 * 60 * 24 * 4),
  mk('Brainstorming startup names', 1000 * 60 * 60 * 24 * 6),
];

function mk(title: string, ageMs: number): Conversation {
  const now = Date.now() - ageMs;
  return {
    id: uid('conv'),
    userId: 'usr_demo',
    title,
    createdAt: now,
    updatedAt: now,
    model: 'balanced',
    messages: [],
  };
}

@Injectable({ providedIn: 'root' })
export class ConversationService {
  private readonly _conversations = signal<Conversation[]>(SEED);

  readonly conversations = computed(() =>
    [...this._conversations()].sort((a, b) => b.updatedAt - a.updatedAt),
  );

  readonly pinned = computed(() => this.conversations().filter((c) => c.pinned && !c.archived));
  readonly active = computed(() => this.conversations().filter((c) => !c.archived));

  readonly grouped = computed(() => {
    const now = Date.now();
    const day = 1000 * 60 * 60 * 24;
    const groups: { label: string; items: Conversation[] }[] = [
      { label: 'Today', items: [] },
      { label: 'Yesterday', items: [] },
      { label: 'Previous 7 days', items: [] },
      { label: 'Older', items: [] },
    ];
    for (const c of this.active()) {
      if (c.pinned) continue;
      const age = now - c.updatedAt;
      if (age < day) groups[0].items.push(c);
      else if (age < 2 * day) groups[1].items.push(c);
      else if (age < 7 * day) groups[2].items.push(c);
      else groups[3].items.push(c);
    }
    return groups.filter((g) => g.items.length > 0);
  });

  getById(id: string): Conversation | undefined {
    return this._conversations().find((c) => c.id === id);
  }

  create(model: AiModelId = 'balanced', projectId?: string): Conversation {
    const conv: Conversation = {
      id: uid('conv'),
      userId: 'usr_demo',
      title: 'New chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      model,
      projectId,
      messages: [],
    };
    this._conversations.update((list) => [conv, ...list]);
    return conv;
  }

  update(id: string, patch: Partial<Conversation>): void {
    this._conversations.update((list) =>
      list.map((c) => (c.id === id ? { ...c, ...patch, updatedAt: Date.now() } : c)),
    );
  }

  rename(id: string, title: string): void {
    this.update(id, { title });
  }

  togglePin(id: string): void {
    const conv = this.getById(id);
    if (conv) this.update(id, { pinned: !conv.pinned });
  }

  toggleArchive(id: string): void {
    const conv = this.getById(id);
    if (conv) this.update(id, { archived: !conv.archived });
  }

  delete(id: string): void {
    this._conversations.update((list) => list.filter((c) => c.id !== id));
  }

  deriveTitleFromFirstMessage(id: string, text: string): void {
    const conv = this.getById(id);
    if (!conv || conv.title !== 'New chat') return;
    const trimmed = text.trim().replace(/\s+/g, ' ');
    const title = trimmed.length > 48 ? trimmed.slice(0, 48) + '…' : trimmed || 'New chat';
    this.rename(id, title);
  }
}
