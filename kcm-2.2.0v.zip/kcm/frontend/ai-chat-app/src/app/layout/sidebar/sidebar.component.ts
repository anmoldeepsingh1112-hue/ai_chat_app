import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { ChatService } from '../../core/services/chat.service';
import { ConversationService } from '../../core/services/conversation.service';
import { AuthService } from '../../core/services/auth.service';
import { AvatarComponent } from '../../shared/components/avatar/avatar.component';
import { DropdownComponent, DropdownItem } from '../../shared/components/dropdown/dropdown.component';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, AvatarComponent, DropdownComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent implements OnInit {
  @Output() collapsedChange = new EventEmitter<boolean>();

  collapsed = signal(false);
  conversations = inject(ConversationService);
  private chat = inject(ChatService);
  auth = inject(AuthService);
  private router = inject(Router);

  conversationActions: DropdownItem[] = [
    { id: 'rename', label: 'Rename' },
    { id: 'pin', label: 'Pin' },
    { id: 'archive', label: 'Archive' },
    { id: 'delete', label: 'Delete', danger: true },
  ];

  ngOnInit(): void {
    this.chat.getConversations().subscribe({ error: () => this.chat.error.set('Could not load conversations.') });
  }

  toggleCollapsed(): void {
    this.collapsed.update((v) => !v);
    this.collapsedChange.emit(this.collapsed());
  }

  newChat(): void {
    // The conversation is created on the server when the first message is sent.
    this.router.navigate(['/chat']);
  }

  onConversationAction(id: string, item: DropdownItem): void {
    switch (item.id) {
      case 'rename': {
        const conv = this.conversations.getById(id);
        const title = window.prompt('Rename conversation', conv?.title ?? '');
        if (title) this.conversations.rename(id, title);
        break;
      }
      case 'pin':
        this.conversations.togglePin(id);
        break;
      case 'archive':
        this.conversations.toggleArchive(id);
        if (this.router.url === `/chat/${id}`) this.router.navigate(['/chat']);
        break;
      case 'delete':
        this.chat.deleteConversation(id).subscribe({
          next: () => {
            if (this.router.url === `/chat/${id}`) this.router.navigate(['/chat']);
          },
          error: () => window.alert('Could not delete the conversation. Please try again.'),
        });
        break;
    }
  }

  footerAction(item: DropdownItem): void {
    if (item.id === 'logout') this.logout();
    if (item.id === 'settings') this.router.navigate(['/settings']);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/']);
  }
}
