import { Injectable, computed, signal } from '@angular/core';
import { Observable, delay, of, tap, throwError } from 'rxjs';
import { User } from '../models/user.model';

export interface LoginPayload {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface SignupPayload {
  fullName: string;
  email: string;
  password: string;
}

const TOKEN_KEY = 'nexus.token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly currentUser = signal<User | null>(this.restoreSession());

  readonly user = computed(() => this.currentUser());
  readonly isAuthenticated = computed(() => this.currentUser() !== null);

  login(payload: LoginPayload): Observable<User> {
    if (!payload.email || !payload.password) {
      return throwError(() => new Error('Email and password are required.'));
    }
    const user: User = {
      id: 'usr_' + Math.random().toString(36).slice(2, 9),
      name: payload.email.split('@')[0],
      email: payload.email,
      plan: 'free',
    };
    return of(user).pipe(
      delay(650),
      tap((u) => this.persistSession(u, payload.rememberMe)),
    );
  }

  signup(payload: SignupPayload): Observable<User> {
    if (payload.password.length < 8) {
      return throwError(() => new Error('Password must be at least 8 characters.'));
    }
    const user: User = {
      id: 'usr_' + Math.random().toString(36).slice(2, 9),
      name: payload.fullName,
      email: payload.email,
      plan: 'free',
    };
    return of(user).pipe(
      delay(800),
      tap((u) => this.persistSession(u, true)),
    );
  }

  loginWithProvider(provider: 'google' | 'apple' | 'github'): Observable<User> {
    const user: User = {
      id: 'usr_' + Math.random().toString(36).slice(2, 9),
      name: `${provider}-user`,
      email: `${provider}.user@example.com`,
      plan: 'free',
    };
    return of(user).pipe(delay(500), tap((u) => this.persistSession(u, true)));
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    this.currentUser.set(null);
  }

  private persistSession(user: User, remember = false): void {
    this.currentUser.set(user);
    const storage = remember ? localStorage : sessionStorage;
    storage.setItem(TOKEN_KEY, JSON.stringify(user));
  }

  private restoreSession(): User | null {
    const raw = localStorage.getItem(TOKEN_KEY) ?? sessionStorage.getItem(TOKEN_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }
}
