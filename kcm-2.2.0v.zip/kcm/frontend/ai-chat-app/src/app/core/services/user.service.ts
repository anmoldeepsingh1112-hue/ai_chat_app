import { Injectable, signal } from '@angular/core';

export interface AccountSettings {
  name: string;
  email: string;
}

export interface ChatPreferences {
  defaultModel: string;
  enterToSend: boolean;
  saveHistory: boolean;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  readonly account = signal<AccountSettings>({ name: 'Anmol', email: 'anmol@example.com' });
  readonly chatPreferences = signal<ChatPreferences>({
    defaultModel: 'balanced',
    enterToSend: true,
    saveHistory: true,
  });

  updateAccount(patch: Partial<AccountSettings>): void {
    this.account.update((a) => ({ ...a, ...patch }));
  }

  updateChatPreferences(patch: Partial<ChatPreferences>): void {
    this.chatPreferences.update((p) => ({ ...p, ...patch }));
  }
}
