import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, catchError, map, tap, throwError } from 'rxjs';
import { API_BASE_URL } from '../config/api.config';
import { ApiChatResponse, ApiError, ContextStats, NETWORK_ERROR, toApiError } from '../models/api.model';
import { AiModelId, AiModelOption, Conversation } from '../models/conversation.model';
import { ChatMessage, MessageStatus } from '../models/message.model';
import { parseSseChunk } from '../utils/sse';
import { AuthService } from './auth.service';
import { ConversationService } from './conversation.service';

/**
 * The model list is shown in the selector, but KCM 2.1 ignores it: the backend uses the
 * LLM_MODEL it is configured with. Wire it up when the API accepts a per-request model.
 */
export const AI_MODELS: AiModelOption[] = [
  { id: 'fast', name: 'Fast', description: 'Quick everyday responses' },
  { id: 'balanced', name: 'Balanced', description: 'General-purpose AI' },
  { id: 'reasoning', name: 'Reasoning', description: 'Complex reasoning and analysis' },
  { id: 'advanced', name: 'Advanced', description: 'Maximum capability' },
];

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * ChatService talks to the KCM backend:
 *   sendMessage()    POST /api/chat          (whole reply)
 *   streamMessage()  POST /api/chat/stream   (SSE: start -> delta* -> done | error)
 * plus conversation CRUD, delegated to ConversationService.
 * It owns the message cache and the status of the single active stream.
 */
@Injectable({ providedIn: 'root' })
export class ChatService {
  private http = inject(HttpClient);
  private api = inject(API_BASE_URL);
  private conversations = inject(ConversationService);
  private auth = inject(AuthService);
  private router = inject(Router);

  readonly status = signal<MessageStatus>('idle');
  readonly error = signal<string | null>(null);
  readonly messagesByConversation = signal<Record<string, ChatMessage[]>>({});

  /** Developer mode (hidden by default): shows KCM 2.2 context stats under the chat. */
  readonly devMode = signal<boolean>(this.readDevFlag());
  /** Context stats of the latest reply; null unless the backend runs with DEV_MODE=true. */
  readonly contextStats = signal<ContextStats | null>(null);

  private abort: AbortController | null = null;

  messagesFor(conversationId: string): ChatMessage[] {
    return this.messagesByConversation()[conversationId] ?? [];
  }

  // ---- conversations ---------------------------------------------------
  createConversation(model: AiModelId = 'balanced', projectId?: string): Observable<Conversation> {
    return this.conversations.createRemote(model, projectId);
  }

  getConversations(): Observable<Conversation[]> {
    return this.conversations.load();
  }

  /** Loads a conversation and its saved messages into the cache. */
  getConversation(id: string): Observable<Conversation> {
    return this.conversations.fetch(id).pipe(
      tap((conv) => this.messagesByConversation.update((map) => ({ ...map, [id]: conv.messages }))),
    );
  }

  deleteConversation(id: string): Observable<void> {
    return this.conversations.deleteRemote(id).pipe(
      tap(() =>
        this.messagesByConversation.update((map) => {
          const { [id]: _removed, ...rest } = map;
          return rest;
        }),
      ),
    );
  }

  // ---- non-streaming ---------------------------------------------------
  sendMessage(conversationId: string, text: string): Observable<ChatMessage> {
    this.error.set(null);
    this.appendMessage(conversationId, this.newUserMessage(text));
    this.status.set('thinking');
    return this.http
      .post<ApiChatResponse>(`${this.api}/chat`, { conversation_id: conversationId, message: text })
      .pipe(
        map((res): ChatMessage => ({
          id: res.message_id,
          role: 'assistant',
          content: res.content,
          createdAt: Date.now(),
          status: 'completed',
        })),
        tap((msg) => {
          this.appendMessage(conversationId, msg);
          this.status.set('completed');
          this.refreshList();
        }),
        catchError((e) => {
          const err = toApiError(e);
          this.status.set('error');
          this.error.set(err.message);
          if (err.status === 401) this.handleUnauthorized();
          return throwError(() => err);
        }),
      );
  }

  // ---- streaming -------------------------------------------------------
  /**
   * Streams the assistant reply token-by-token. The user message and an empty "thinking"
   * assistant message are added synchronously, before the first await, so callers can
   * navigate right after calling this without the page reloading an empty history.
   */
  async streamMessage(conversationId: string, text: string): Promise<void> {
    this.abort?.abort(); // only one active stream at a time
    const controller = new AbortController();
    this.abort = controller;
    this.error.set(null);

    this.appendMessage(conversationId, this.newUserMessage(text));
    let assistantId = uid('msg');
    this.appendMessage(conversationId, {
      id: assistantId,
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
      status: 'thinking',
    });
    this.status.set('thinking');

    let content = '';
    let finished = false;
    try {
      let res: Response;
      try {
        res = await fetch(`${this.api}/chat/stream`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
          body: JSON.stringify({ conversation_id: conversationId, message: text }),
          credentials: 'include',
          signal: controller.signal,
        });
      } catch (e) {
        if (controller.signal.aborted) throw e;
        throw NETWORK_ERROR;
      }
      if (!res.ok) throw await this.errorFromResponse(res);
      if (!res.body) throw new ApiError('STREAM_UNSUPPORTED', 'Streaming is not supported by this browser.');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parsed = parseSseChunk(buffer);
        buffer = parsed.rest;
        for (const ev of parsed.events) {
          if (ev.event === 'delta') {
            content += ev.data?.content ?? '';
            this.status.set('streaming');
            this.updateMessage(conversationId, assistantId, { content, status: 'streaming' });
          } else if (ev.event === 'done') {
            finished = true;
            this.contextStats.set(ev.data.context ?? null);
            const serverId: string = ev.data.message_id;
            this.updateMessage(conversationId, assistantId, { id: serverId, content, status: 'completed' });
            assistantId = serverId;
          } else if (ev.event === 'error') {
            throw new ApiError(ev.data?.error?.code ?? 'STREAM_ERROR', ev.data?.error?.message ?? 'The response failed.');
          }
        }
      }
      if (!finished) throw new ApiError('STREAM_INTERRUPTED', 'The response stream was interrupted.');
      this.status.set('completed');
      this.refreshList(); // server sets the title from the first message
    } catch (e) {
      if (controller.signal.aborted) {
        // Stopped by the user (or superseded by a new stream); status is handled by the caller.
        this.settleAborted(conversationId, assistantId, content);
        return;
      }
      const err = toApiError(e);
      this.status.set('error');
      this.error.set(err.message);
      this.updateMessage(conversationId, assistantId, {
        status: 'error',
        content: content || `⚠️ ${err.message}`,
      });
      if (err.status === 401) this.handleUnauthorized();
    } finally {
      if (this.abort === controller) this.abort = null;
    }
  }

  /**
   * The backend has no regenerate endpoint, so this re-sends the preceding user prompt as a
   * new turn (it appears as a new exchange and is saved as one).
   */
  regenerate(conversationId: string, assistantMessageId: string): void {
    const msgs = this.messagesFor(conversationId);
    const idx = msgs.findIndex((m) => m.id === assistantMessageId);
    const prior = [...msgs.slice(0, idx)].reverse().find((m) => m.role === 'user');
    if (prior) void this.streamMessage(conversationId, prior.content);
  }

  /** Stops the active stream. Note: the backend does not save a reply that was cut off. */
  stopStreaming(): void {
    this.abort?.abort();
    this.status.set('idle');
  }

  toggleDevMode(): void {
    const next = !this.devMode();
    this.devMode.set(next);
    try {
      localStorage.setItem('kcm_dev', next ? '1' : '0');
    } catch {
      /* storage unavailable: the toggle just lasts for this session */
    }
  }

  // ---- internals -------------------------------------------------------
  private readDevFlag(): boolean {
    try {
      return localStorage.getItem('kcm_dev') === '1';
    } catch {
      return false;
    }
  }

  private newUserMessage(text: string): ChatMessage {
    return { id: uid('msg'), role: 'user', content: text, createdAt: Date.now(), status: 'completed' };
  }

  private async errorFromResponse(res: Response): Promise<ApiError> {
    let code = 'HTTP_ERROR';
    let message = `Request failed (${res.status}).`;
    try {
      const body = await res.json();
      code = body?.error?.code ?? code;
      message = body?.error?.message ?? message;
    } catch {
      /* non-JSON body */
    }
    return new ApiError(code, message, res.status);
  }

  private settleAborted(conversationId: string, messageId: string, content: string): void {
    if (content) {
      this.updateMessage(conversationId, messageId, { status: 'completed' });
    } else {
      this.messagesByConversation.update((map) => ({
        ...map,
        [conversationId]: (map[conversationId] ?? []).filter((m) => m.id !== messageId),
      }));
    }
  }

  private handleUnauthorized(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  private refreshList(): void {
    this.conversations.load().subscribe({ error: () => undefined });
  }

  private appendMessage(conversationId: string, message: ChatMessage): void {
    this.messagesByConversation.update((map) => ({
      ...map,
      [conversationId]: [...(map[conversationId] ?? []), message],
    }));
  }

  private updateMessage(conversationId: string, messageId: string, patch: Partial<ChatMessage>): void {
    this.messagesByConversation.update((map) => ({
      ...map,
      [conversationId]: (map[conversationId] ?? []).map((m) => (m.id === messageId ? { ...m, ...patch } : m)),
    }));
  }
}
