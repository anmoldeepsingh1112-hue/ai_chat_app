import { Injectable, signal } from '@angular/core';

export interface PlanUsage {
  planName: 'Free' | 'Pro' | 'Business';
  messagesUsed: number;
  messagesLimit: number;
  renewsOn: string;
}

@Injectable({ providedIn: 'root' })
export class SubscriptionService {
  readonly usage = signal<PlanUsage>({
    planName: 'Free',
    messagesUsed: 34,
    messagesLimit: 50,
    renewsOn: 'Oct 27, 2026',
  });

  upgrade(plan: 'Pro' | 'Business'): void {
    this.usage.update((u) => ({
      ...u,
      planName: plan,
      messagesLimit: plan === 'Pro' ? 1000 : 5000,
    }));
  }
}
