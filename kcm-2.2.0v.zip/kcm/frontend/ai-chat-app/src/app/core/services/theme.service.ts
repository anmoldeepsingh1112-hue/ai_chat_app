import { Injectable, effect, signal } from '@angular/core';

export type ThemePreference = 'light' | 'dark' | 'system';

const STORAGE_KEY = 'nexus.theme';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  readonly preference = signal<ThemePreference>(this.readStored());

  constructor() {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener('change', () => this.apply());

    effect(() => {
      const pref = this.preference();
      localStorage.setItem(STORAGE_KEY, pref);
      this.apply();
    });
  }

  setPreference(pref: ThemePreference): void {
    this.preference.set(pref);
  }

  private apply(): void {
    const pref = this.preference();
    const resolved = pref === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : pref;
    document.documentElement.setAttribute('data-theme', resolved);
  }

  private readStored(): ThemePreference {
    const stored = localStorage.getItem(STORAGE_KEY) as ThemePreference | null;
    return stored ?? 'system';
  }
}
