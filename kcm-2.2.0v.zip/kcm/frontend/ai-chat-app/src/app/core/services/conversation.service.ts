import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, map, tap } from 'rxjs';
import { API_BASE_URL } from '../config/api.config';
import { ApiConversation, ApiMessage, toTimestamp } from '../models/api.model';
import { AiModelId, Conversation } from '../models/conversation.model';
import { ChatMessage } from '../models/message.model';

function toMessage(m: ApiMessage): ChatMessage {
  return {
    id: m.id,
    role: m.role === 'assistant' ? 'assistant' : 'user',
    content: m.content,
    createdAt: toTimestamp(m.created_at),
    status: 'completed',
  };
}

/**
 * Conversation list backed by the KCM API (the server is the source of truth for
 * ids, titles, timestamps and messages). Pin / archive / rename / model / project are
 * client-side only for now (the backend has no endpoints for them), so they last for the
 * session and are re-applied whenever the list is refreshed.
 */
@Injectable({ providedIn: 'root' })
export class ConversationService {
  private http = inject(HttpClient);
  private api = inject(API_BASE_URL);

  private readonly _conversations = signal<Conversation[]>([]);
  private readonly renamed = new Set<string>();

  readonly conversations = computed(() =>
    [...this._conversations()].sort((a, b) => b.updatedAt - a.updatedAt),
  );

  readonly pinned = computed(() => this.conversations().filter((c) => c.pinned && !c.archived));
  readonly active = computed(() => this.conversations().filter((c) => !c.archived));

  readonly grouped = computed(() => {
    const now = Date.now();
    const day = 1000 * 60 * 60 * 24;
    const groups: { label: string; items: Conversation[] }[] = [
      { label: 'Today', items: [] },
      { label: 'Yesterday', items: [] },
      { label: 'Previous 7 days', items: [] },
      { label: 'Older', items: [] },
    ];
    for (const c of this.active()) {
      if (c.pinned) continue;
      const age = now - c.updatedAt;
      if (age < day) groups[0].items.push(c);
      else if (age < 2 * day) groups[1].items.push(c);
      else if (age < 7 * day) groups[2].items.push(c);
      else groups[3].items.push(c);
    }
    return groups.filter((g) => g.items.length > 0);
  });

  getById(id: string): Conversation | undefined {
    return this._conversations().find((c) => c.id === id);
  }

  // ---- backend calls ---------------------------------------------------
  /** GET /conversations */
  load(): Observable<Conversation[]> {
    return this.http.get<ApiConversation[]>(`${this.api}/conversations`).pipe(
      map((list) => list.map((c) => this.fromApi(c))),
      tap((list) => this._conversations.set(list)),
    );
  }

  /** GET /conversations/{id} (with messages); also upserts into the list. */
  fetch(id: string): Observable<Conversation> {
    return this.http.get<ApiConversation>(`${this.api}/conversations/${id}`).pipe(
      map((c) => this.fromApi(c)),
      tap((conv) => this.upsert(conv)),
    );
  }

  /** POST /conversations */
  createRemote(model: AiModelId = 'balanced', projectId?: string): Observable<Conversation> {
    return this.http.post<ApiConversation>(`${this.api}/conversations`, {}).pipe(
      map((c) => ({ ...this.fromApi(c), model, projectId })),
      tap((conv) => this._conversations.update((list) => [conv, ...list])),
    );
  }

  /** DELETE /conversations/{id}; removed locally only after the server confirms. */
  deleteRemote(id: string): Observable<void> {
    return this.http.delete<void>(`${this.api}/conversations/${id}`).pipe(
      tap(() => {
        this.renamed.delete(id);
        this._conversations.update((list) => list.filter((c) => c.id !== id));
      }),
    );
  }

  // ---- client-side only ------------------------------------------------
  update(id: string, patch: Partial<Conversation>): void {
    this._conversations.update((list) =>
      list.map((c) => (c.id === id ? { ...c, ...patch, updatedAt: Date.now() } : c)),
    );
  }

  rename(id: string, title: string): void {
    this.renamed.add(id);
    this.update(id, { title });
  }

  togglePin(id: string): void {
    const conv = this.getById(id);
    if (conv) this.update(id, { pinned: !conv.pinned });
  }

  toggleArchive(id: string): void {
    const conv = this.getById(id);
    if (conv) this.update(id, { archived: !conv.archived });
  }

  // ---- helpers ---------------------------------------------------------
  private fromApi(c: ApiConversation): Conversation {
    const prev = this.getById(c.id);
    return {
      id: c.id,
      userId: prev?.userId ?? '',
      title: this.renamed.has(c.id) && prev ? prev.title : c.title,
      createdAt: toTimestamp(c.created_at),
      updatedAt: toTimestamp(c.updated_at),
      model: prev?.model ?? 'balanced',
      pinned: prev?.pinned,
      archived: prev?.archived,
      projectId: prev?.projectId,
      messages: (c.messages ?? []).map(toMessage),
    };
  }

  private upsert(conv: Conversation): void {
    this._conversations.update((list) =>
      list.some((c) => c.id === conv.id) ? list.map((c) => (c.id === conv.id ? conv : c)) : [conv, ...list],
    );
  }
}
