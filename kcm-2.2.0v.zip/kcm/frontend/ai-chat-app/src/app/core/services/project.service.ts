import { Injectable, computed, signal } from '@angular/core';
import { Project } from '../models/project.model';

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

@Injectable({ providedIn: 'root' })
export class ProjectService {
  private readonly _projects = signal<Project[]>([
    {
      id: uid('proj'),
      name: 'Product Launch Q1',
      instructions: 'Act as a senior product marketing strategist. Keep tone confident and concise.',
      createdAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
      files: [{ id: uid('file'), name: 'positioning.docx', sizeBytes: 48213 }],
      conversationIds: [],
    },
    {
      id: uid('proj'),
      name: 'Codebase Migration',
      instructions: 'Assist with migrating the legacy service to TypeScript. Prefer strict types.',
      createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
      files: [],
      conversationIds: [],
    },
  ]);

  readonly projects = computed(() => [...this._projects()].sort((a, b) => b.createdAt - a.createdAt));

  getById(id: string): Project | undefined {
    return this._projects().find((p) => p.id === id);
  }

  create(name: string): Project {
    const project: Project = {
      id: uid('proj'),
      name,
      instructions: '',
      createdAt: Date.now(),
      files: [],
      conversationIds: [],
    };
    this._projects.update((list) => [project, ...list]);
    return project;
  }

  rename(id: string, name: string): void {
    this._projects.update((list) => list.map((p) => (p.id === id ? { ...p, name } : p)));
  }

  updateInstructions(id: string, instructions: string): void {
    this._projects.update((list) => list.map((p) => (p.id === id ? { ...p, instructions } : p)));
  }

  delete(id: string): void {
    this._projects.update((list) => list.filter((p) => p.id !== id));
  }

  addFile(id: string, name: string, sizeBytes: number): void {
    this._projects.update((list) =>
      list.map((p) =>
        p.id === id ? { ...p, files: [...p.files, { id: uid('file'), name, sizeBytes }] } : p,
      ),
    );
  }
}
