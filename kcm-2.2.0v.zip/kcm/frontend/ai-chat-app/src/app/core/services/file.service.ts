import { Injectable } from '@angular/core';
import { Observable, Subscriber, interval, takeWhile } from 'rxjs';
import { Attachment } from '../models/attachment.model';

const ACCEPTED_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain',
  'text/csv',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'image/png',
  'image/jpeg',
  'image/webp',
];
const MAX_SIZE_BYTES = 25 * 1024 * 1024;

export interface FileValidationResult {
  valid: boolean;
  error?: string;
}

@Injectable({ providedIn: 'root' })
export class FileService {
  validate(file: File): FileValidationResult {
    const isCode = /\.(ts|js|py|java|go|rs|cpp|c|json|yaml|yml|md)$/i.test(file.name);
    if (!ACCEPTED_TYPES.includes(file.type) && !isCode) {
      return { valid: false, error: `Unsupported file type: ${file.type || 'unknown'}` };
    }
    if (file.size > MAX_SIZE_BYTES) {
      return { valid: false, error: 'File exceeds the 25MB limit.' };
    }
    return { valid: true };
  }

  /** Simulates a chunked upload with progress; swap for real HttpClient multipart request. */
  upload(file: File): Observable<Attachment> {
    const attachment: Attachment = {
      id: 'att_' + Math.random().toString(36).slice(2, 9),
      fileName: file.name,
      fileType: file.type || 'text/plain',
      fileSizeBytes: file.size,
      progress: 0,
      status: 'uploading',
      previewUrl: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined,
    };

    return new Observable<Attachment>((subscriber: Subscriber<Attachment>) => {
      subscriber.next({ ...attachment });
      const sub = interval(120)
        .pipe(takeWhile((tick) => tick <= 10))
        .subscribe({
          next: (tick) => {
            const progress = Math.min(100, tick * 10);
            subscriber.next({
              ...attachment,
              progress,
              status: progress >= 100 ? 'done' : 'uploading',
            });
            if (progress >= 100) subscriber.complete();
          },
        });
      return () => sub.unsubscribe();
    });
  }

  formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
}
