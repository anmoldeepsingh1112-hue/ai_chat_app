import { Injectable } from '@angular/core';
import { Observable, delay, of } from 'rxjs';
import { ConversationService } from './conversation.service';
import { ProjectService } from './project.service';

export interface SearchResult {
  kind: 'conversation' | 'project' | 'file';
  id: string;
  title: string;
  snippet: string;
  updatedAt: number;
}

@Injectable({ providedIn: 'root' })
export class SearchService {
  constructor(
    private conversations: ConversationService,
    private projects: ProjectService,
  ) {}

  search(query: string): Observable<SearchResult[]> {
    const q = query.trim().toLowerCase();
    if (!q) return of([]).pipe(delay(120));

    const convResults: SearchResult[] = this.conversations
      .conversations()
      .filter((c) => c.title.toLowerCase().includes(q))
      .map((c) => ({
        kind: 'conversation',
        id: c.id,
        title: c.title,
        snippet: 'Conversation match',
        updatedAt: c.updatedAt,
      }));

    const projResults: SearchResult[] = this.projects
      .projects()
      .filter((p) => p.name.toLowerCase().includes(q))
      .map((p) => ({
        kind: 'project',
        id: p.id,
        title: p.name,
        snippet: 'Project match',
        updatedAt: p.createdAt,
      }));

    return of([...convResults, ...projResults]).pipe(delay(200));
  }
}
