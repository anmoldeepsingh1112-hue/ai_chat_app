/**
 * Minimal Server-Sent Events parser. The backend streams `event:` / `data:` frames
 * (data is JSON) over a POST response, so the browser's EventSource (GET-only) can't be
 * used; ChatService reads the response body with fetch() and feeds the text through here.
 */
export interface SseEvent {
  event: string;
  data: any;
}

export function parseSseChunk(buffer: string): { events: SseEvent[]; rest: string } {
  const blocks = buffer.replace(/\r\n/g, '\n').split('\n\n');
  const rest = blocks.pop() ?? ''; // trailing partial frame, completed by the next chunk
  const events: SseEvent[] = [];
  for (const block of blocks) {
    let event = 'message';
    const data: string[] = [];
    for (const line of block.split('\n')) {
      if (!line || line.startsWith(':')) continue; // blank line / comment (keep-alive)
      const i = line.indexOf(':');
      const field = i < 0 ? line : line.slice(0, i);
      const value = i < 0 ? '' : line.slice(i + 1).replace(/^ /, '');
      if (field === 'event') event = value;
      else if (field === 'data') data.push(value);
    }
    if (!data.length) continue;
    try {
      events.push({ event, data: JSON.parse(data.join('\n')) });
    } catch {
      /* ignore malformed frame */
    }
  }
  return { events, rest };
}
