import { InjectionToken } from '@angular/core';

/**
 * Base URL of the KCM FastAPI backend. Override in app.config.ts providers
 * (e.g. { provide: API_BASE_URL, useValue: '/api' } behind a reverse proxy).
 * The backend's CORS_ORIGINS must include the origin this app is served from.
 */
export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL', {
  providedIn: 'root',
  factory: () => 'http://localhost:8000/api',
});
