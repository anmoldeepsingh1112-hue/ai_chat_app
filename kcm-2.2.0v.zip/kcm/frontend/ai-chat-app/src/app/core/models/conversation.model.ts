import { ChatMessage } from './message.model';

export type AiModelId = 'fast' | 'balanced' | 'reasoning' | 'advanced';

export interface AiModelOption {
  id: AiModelId;
  name: string;
  description: string;
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  model: AiModelId;
  pinned?: boolean;
  archived?: boolean;
  projectId?: string;
  messages: ChatMessage[];
}
