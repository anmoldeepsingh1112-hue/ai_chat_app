import { Attachment } from './attachment.model';

export type MessageRole = 'user' | 'assistant';
export type MessageStatus = 'idle' | 'thinking' | 'streaming' | 'completed' | 'error';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  createdAt: number;
  status: MessageStatus;
  attachments?: Attachment[];
  liked?: boolean;
  disliked?: boolean;
}
