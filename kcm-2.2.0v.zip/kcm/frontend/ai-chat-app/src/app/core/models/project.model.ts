export interface ProjectFile {
  id: string;
  name: string;
  sizeBytes: number;
}

export interface Project {
  id: string;
  name: string;
  instructions: string;
  createdAt: number;
  files: ProjectFile[];
  conversationIds: string[];
}
