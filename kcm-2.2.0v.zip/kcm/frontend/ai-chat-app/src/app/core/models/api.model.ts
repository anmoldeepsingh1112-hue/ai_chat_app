import { HttpErrorResponse } from '@angular/common/http';

/** Wire formats returned by the KCM backend (snake_case). */
export interface ApiMessage {
  id: string;
  conversation_id: string;
  role: string;
  content: string;
  created_at: string;
}

export interface ApiConversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  messages?: ApiMessage[];
}

export interface ApiChatResponse {
  conversation_id: string;
  message_id: string;
  role: string;
  content: string;
}

/** KCM 2.2 context stats; only present in the final stream event when the backend runs with DEV_MODE=true. */
export interface ContextStats {
  selected_tokens: number;
  available_tokens: number;
  context_limit: number;
  original_tokens: number | null;
  messages_selected: number | null;
  messages_total: number | null;
  recent_messages: number;
  relevant_messages: number;
  summary_used: boolean;
  summary_tokens: number;
  compression_level: number;
  build_ms: number | null;
}

/** Structured backend error: { error: { code, message } }. Never contains internals. */
export class ApiError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly status?: number,
  ) {
    super(message);
  }
}

export const NETWORK_ERROR = new ApiError(
  'NETWORK_ERROR',
  'Could not reach the server. Please check that the backend is running.',
);

export function toApiError(err: unknown): ApiError {
  if (err instanceof ApiError) return err;
  if (err instanceof HttpErrorResponse) {
    if (err.status === 0) return NETWORK_ERROR;
    const body = err.error?.error;
    return new ApiError(body?.code ?? 'HTTP_ERROR', body?.message ?? `Request failed (${err.status}).`, err.status);
  }
  return new ApiError('UNKNOWN', 'Something went wrong.');
}

/** Backend timestamps are UTC ISO strings; SQLite drops the offset, so assume UTC when absent. */
export function toTimestamp(iso: string): number {
  const hasZone = /([zZ]|[+-]\d{2}:?\d{2})$/.test(iso);
  return Date.parse(hasZone ? iso : iso + 'Z');
}
