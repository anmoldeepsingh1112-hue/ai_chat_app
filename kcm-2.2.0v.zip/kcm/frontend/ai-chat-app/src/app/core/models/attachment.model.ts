export type AttachmentStatus = 'uploading' | 'done' | 'error';

export interface Attachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSizeBytes: number;
  progress: number;
  status: AttachmentStatus;
  previewUrl?: string;
}
