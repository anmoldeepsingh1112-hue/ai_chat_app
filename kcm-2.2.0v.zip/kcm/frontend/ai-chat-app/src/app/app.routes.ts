import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/landing/landing.component').then((m) => m.LandingComponent),
  },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'signup',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/signup/signup.component').then((m) => m.SignupComponent),
  },
  {
    path: 'pricing',
    loadComponent: () => import('./features/pricing/pricing.component').then((m) => m.PricingComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/app-shell/app-shell.component').then((m) => m.AppShellComponent),
    children: [
      {
        path: 'chat',
        loadComponent: () => import('./features/chat/chat-page/chat-page.component').then((m) => m.ChatPageComponent),
      },
      {
        path: 'chat/:id',
        loadComponent: () => import('./features/chat/chat-page/chat-page.component').then((m) => m.ChatPageComponent),
      },
      {
        path: 'search',
        loadComponent: () => import('./features/search/search.component').then((m) => m.SearchComponent),
      },
      {
        path: 'projects',
        loadComponent: () => import('./features/projects/project-list/project-list.component').then((m) => m.ProjectListComponent),
      },
      {
        path: 'projects/:id',
        loadComponent: () => import('./features/projects/project-detail/project-detail.component').then((m) => m.ProjectDetailComponent),
      },
      {
        path: 'files',
        loadComponent: () => import('./features/files/files.component').then((m) => m.FilesComponent),
      },
      {
        path: 'settings',
        loadComponent: () => import('./features/settings/settings-layout/settings-layout.component').then((m) => m.SettingsLayoutComponent),
        children: [
          { path: '', redirectTo: 'account', pathMatch: 'full' },
          { path: 'account', loadComponent: () => import('./features/settings/account/account.component').then((m) => m.AccountSettingsComponent) },
          { path: 'appearance', loadComponent: () => import('./features/settings/appearance/appearance.component').then((m) => m.AppearanceSettingsComponent) },
          { path: 'privacy', loadComponent: () => import('./features/settings/privacy/privacy.component').then((m) => m.PrivacySettingsComponent) },
          { path: 'billing', loadComponent: () => import('./features/settings/billing/billing.component').then((m) => m.BillingSettingsComponent) },
        ],
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
