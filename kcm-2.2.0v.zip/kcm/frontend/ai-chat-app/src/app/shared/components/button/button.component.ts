import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      [attr.type]="type"
      class="btn"
      [class]="'btn--' + variant + ' btn--' + size"
      [disabled]="disabled || loading"
      (click)="clicked.emit($event)"
    >
      <span class="btn__spinner" *ngIf="loading" aria-hidden="true"></span>
      <ng-content select="[icon]" />
      <span [class.btn__label--hidden]="loading"><ng-content /></span>
    </button>
  `,
  styleUrl: './button.component.scss',
})
export class ButtonComponent {
  @Input() variant: ButtonVariant = 'primary';
  @Input() size: ButtonSize = 'md';
  @Input() type: 'button' | 'submit' = 'button';
  @Input() disabled = false;
  @Input() loading = false;
  @Output() clicked = new EventEmitter<Event>();
}
