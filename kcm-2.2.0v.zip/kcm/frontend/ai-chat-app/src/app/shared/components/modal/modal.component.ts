import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-backdrop" *ngIf="open" (click)="close.emit()">
      <div class="modal" role="dialog" [attr.aria-label]="title" (click)="$event.stopPropagation()">
        <header class="modal__header">
          <h2>{{ title }}</h2>
          <button class="modal__close" (click)="close.emit()" aria-label="Close dialog">✕</button>
        </header>
        <div class="modal__body"><ng-content /></div>
      </div>
    </div>
  `,
  styleUrl: './modal.component.scss',
})
export class ModalComponent {
  @Input() open = false;
  @Input() title = '';
  @Output() close = new EventEmitter<void>();
}
