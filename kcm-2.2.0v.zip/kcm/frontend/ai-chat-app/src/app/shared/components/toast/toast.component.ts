import { CommonModule } from '@angular/common';
import { Component, Injectable, signal } from '@angular/core';

export interface ToastMessage {
  id: number;
  text: string;
  variant: 'info' | 'success' | 'error';
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly toasts = signal<ToastMessage[]>([]);
  private counter = 0;

  show(text: string, variant: ToastMessage['variant'] = 'info'): void {
    const id = ++this.counter;
    this.toasts.update((list) => [...list, { id, text, variant }]);
    setTimeout(() => this.dismiss(id), 3200);
  }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}

@Component({
  selector: 'app-toast-tray',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-tray">
      <div *ngFor="let t of toastService.toasts()" class="toast" [class]="'toast--' + t.variant">
        {{ t.text }}
      </div>
    </div>
  `,
  styleUrl: './toast.component.scss',
})
export class ToastTrayComponent {
  constructor(public toastService: ToastService) {}
}
