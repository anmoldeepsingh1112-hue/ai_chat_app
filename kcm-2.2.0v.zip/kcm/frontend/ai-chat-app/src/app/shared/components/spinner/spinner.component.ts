import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-spinner',
  standalone: true,
  template: `<span class="spinner" [style.width.px]="size" [style.height.px]="size"></span>`,
  styleUrl: './spinner.component.scss',
})
export class SpinnerComponent {
  @Input() size = 18;
}
