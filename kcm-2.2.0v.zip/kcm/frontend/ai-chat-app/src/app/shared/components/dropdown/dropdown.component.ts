import { CommonModule } from '@angular/common';
import { Component, ElementRef, HostListener, Input, signal } from '@angular/core';

export interface DropdownItem {
  id: string;
  label: string;
  danger?: boolean;
  icon?: string;
}

@Component({
  selector: 'app-dropdown',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dropdown">
      <button class="dropdown__trigger" (click)="toggle()" [attr.aria-expanded]="isOpen()">
        <ng-content select="[trigger]" />
      </button>
      <div class="dropdown__menu" *ngIf="isOpen()" role="menu">
        <button
          *ngFor="let item of items"
          class="dropdown__item"
          [class.dropdown__item--danger]="item.danger"
          role="menuitem"
          (click)="select(item)"
        >
          {{ item.label }}
        </button>
      </div>
    </div>
  `,
  styleUrl: './dropdown.component.scss',
})
export class DropdownComponent {
  @Input() items: DropdownItem[] = [];
  @Input() onSelect: (item: DropdownItem) => void = () => {};
  isOpen = signal(false);

  constructor(private host: ElementRef) {}

  @HostListener('document:click', ['$event'])
  onDocClick(e: MouseEvent) {
    if (!this.host.nativeElement.contains(e.target)) this.isOpen.set(false);
  }

  toggle(): void {
    this.isOpen.update((v) => !v);
  }

  select(item: DropdownItem): void {
    this.isOpen.set(false);
    this.onSelect(item);
  }
}
