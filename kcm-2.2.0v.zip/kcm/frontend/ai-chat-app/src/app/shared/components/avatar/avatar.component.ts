import { CommonModule } from '@angular/common';
import { Component, Input, computed } from '@angular/core';

@Component({
  selector: 'app-avatar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="avatar" [class]="'avatar--' + size" [style.background]="color()">
      <img *ngIf="src" [src]="src" [alt]="name" />
      <span *ngIf="!src">{{ initials() }}</span>
    </div>
  `,
  styleUrl: './avatar.component.scss',
})
export class AvatarComponent {
  @Input() name = '';
  @Input() src?: string;
  @Input() size: 'sm' | 'md' | 'lg' = 'md';

  initials = computed(() =>
    this.name
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase())
      .join('') || '?',
  );

  color = computed(() => {
    const palette = ['#7c5cff', '#34d399', '#fbbf24', '#f87171', '#38bdf8'];
    const hash = this.name.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    return palette[hash % palette.length];
  });
}
