import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-badge',
  standalone: true,
  template: `<span class="badge" [class]="'badge--' + tone"><ng-content /></span>`,
  styleUrl: './badge.component.scss',
})
export class BadgeComponent {
  @Input() tone: 'neutral' | 'accent' | 'success' | 'warning' = 'neutral';
}
