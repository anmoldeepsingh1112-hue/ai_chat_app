import { Pipe, PipeTransform, SecurityContext } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import DOMPurify from 'dompurify';
import { marked } from 'marked';

/** Renders assistant markdown (incl. fenced code, tables) safely via DOMPurify. */
@Pipe({
  name: 'markdown',
  standalone: true,
  pure: true,
})
export class MarkdownPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string | null | undefined): SafeHtml {
    if (!value) return '';
    const rawHtml = marked.parse(value, { breaks: true, async: false }) as string;
    const clean = DOMPurify.sanitize(rawHtml, { ADD_ATTR: ['target'] });
    return this.sanitizer.bypassSecurityTrustHtml(clean);
  }
}
