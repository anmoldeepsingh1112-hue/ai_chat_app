import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subject, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { RouterLink } from '@angular/router';
import { SearchResult, SearchService } from '../../core/services/search.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './search.component.html',
  styleUrl: './search.component.scss',
})
export class SearchComponent {
  private searchSvc = inject(SearchService);
  private query$ = new Subject<string>();

  query = signal('');
  results = signal<SearchResult[]>([]);
  loading = signal(false);

  constructor() {
    this.query$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((q) => {
          this.loading.set(true);
          return this.searchSvc.search(q);
        }),
      )
      .subscribe((res) => {
        this.results.set(res);
        this.loading.set(false);
      });
  }

  onInput(value: string): void {
    this.query.set(value);
    this.query$.next(value);
  }

  linkFor(result: SearchResult): string[] {
    if (result.kind === 'conversation') return ['/chat', result.id];
    if (result.kind === 'project') return ['/projects', result.id];
    return ['/files'];
  }
}
