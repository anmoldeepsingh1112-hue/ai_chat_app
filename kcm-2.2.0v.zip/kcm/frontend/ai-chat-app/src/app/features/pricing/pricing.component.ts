import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

interface Plan {
  name: string;
  price: string;
  period: string;
  features: string[];
  cta: string;
  highlighted?: boolean;
}

@Component({
  selector: 'app-pricing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pricing.component.html',
  styleUrl: './pricing.component.scss',
})
export class PricingComponent {
  auth = inject(AuthService);

  plans: Plan[] = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      features: ['Basic AI model', 'Limited messages / day', 'Limited file uploads', 'Community support'],
      cta: 'Get started',
    },
    {
      name: 'Pro',
      price: '$20',
      period: 'per month',
      features: ['Higher usage limits', 'Advanced & reasoning models', 'Full file analysis', 'Priority support'],
      cta: 'Upgrade to Pro',
      highlighted: true,
    },
    {
      name: 'Business',
      price: '$35',
      period: 'per user / month',
      features: ['Team workspace', 'Shared projects', 'Admin controls', 'Highest usage limits', 'SSO (coming soon)'],
      cta: 'Contact sales',
    },
  ];
}
