import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { UserService } from '../../../core/services/user.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { ToastService } from '../../../shared/components/toast/toast.component';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-privacy-settings',
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  templateUrl: './privacy.component.html',
  styleUrl: '../settings-shared.scss',
})
export class PrivacySettingsComponent {
  users = inject(UserService);
  private toast = inject(ToastService);
  private auth = inject(AuthService);
  private router = inject(Router);

  exporting = signal(false);

  toggleSaveHistory(): void {
    this.users.updateChatPreferences({ saveHistory: !this.users.chatPreferences().saveHistory });
  }

  exportData(): void {
    this.exporting.set(true);
    setTimeout(() => {
      this.exporting.set(false);
      this.toast.show('Export ready — check your email', 'success');
    }, 900);
  }

  deleteAccount(): void {
    const confirmed = window.confirm('This will permanently delete your account. Continue?');
    if (!confirmed) return;
    this.auth.logout();
    this.router.navigate(['/']);
    this.toast.show('Account deleted', 'success');
  }
}
