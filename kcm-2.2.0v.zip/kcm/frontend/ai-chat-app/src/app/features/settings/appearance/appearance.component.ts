import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ThemePreference, ThemeService } from '../../../core/services/theme.service';
import { UserService } from '../../../core/services/user.service';

@Component({
  selector: 'app-appearance-settings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './appearance.component.html',
  styleUrl: '../settings-shared.scss',
})
export class AppearanceSettingsComponent {
  theme = inject(ThemeService);
  users = inject(UserService);

  fontSizes = ['Small', 'Medium', 'Large'];
  selectedFontSize = 'Medium';
  density: 'compact' | 'comfortable' = 'comfortable';

  setTheme(pref: ThemePreference): void {
    this.theme.setPreference(pref);
  }
}
