import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from '../../../core/services/user.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { AvatarComponent } from '../../../shared/components/avatar/avatar.component';
import { ToastService } from '../../../shared/components/toast/toast.component';

@Component({
  selector: 'app-account-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ButtonComponent, AvatarComponent],
  templateUrl: './account.component.html',
  styleUrl: '../settings-shared.scss',
})
export class AccountSettingsComponent {
  private fb = inject(FormBuilder);
  private users = inject(UserService);
  private toast = inject(ToastService);

  account = this.users.account;

  form = this.fb.nonNullable.group({
    name: [this.account().name, Validators.required],
    email: [this.account().email, [Validators.required, Validators.email]],
  });

  passwordForm = this.fb.nonNullable.group({
    current: ['', Validators.required],
    next: ['', [Validators.required, Validators.minLength(8)]],
  });

  saveProfile(): void {
    if (this.form.invalid) return;
    this.users.updateAccount(this.form.getRawValue());
    this.toast.show('Profile updated', 'success');
  }

  changePassword(): void {
    if (this.passwordForm.invalid) return;
    this.passwordForm.reset({ current: '', next: '' });
    this.toast.show('Password changed', 'success');
  }
}
