import { CommonModule } from '@angular/common';
import { Component, computed, inject } from '@angular/core';
import { SubscriptionService } from '../../../core/services/subscription.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { ToastService } from '../../../shared/components/toast/toast.component';

@Component({
  selector: 'app-billing-settings',
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  templateUrl: './billing.component.html',
  styleUrl: '../settings-shared.scss',
})
export class BillingSettingsComponent {
  subscription = inject(SubscriptionService);
  private toast = inject(ToastService);

  usagePercent = computed(() => {
    const u = this.subscription.usage();
    return Math.min(100, Math.round((u.messagesUsed / u.messagesLimit) * 100));
  });

  upgrade(plan: 'Pro' | 'Business'): void {
    this.subscription.upgrade(plan);
    this.toast.show(`Upgraded to ${plan}`, 'success');
  }
}
