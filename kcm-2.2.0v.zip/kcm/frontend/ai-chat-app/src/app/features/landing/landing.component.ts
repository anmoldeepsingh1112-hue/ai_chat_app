import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

interface Feature {
  icon: string;
  title: string;
  desc: string;
}

interface FaqItem {
  q: string;
  a: string;
  open?: boolean;
}

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.scss',
})
export class LandingComponent {
  features: Feature[] = [
    { icon: '💬', title: 'AI conversation', desc: 'Natural, fluid dialogue that remembers context and adapts to your style.' },
    { icon: '🧠', title: 'Reasoning', desc: 'Step-by-step logical thinking for complex, multi-part problems.' },
    { icon: '📄', title: 'File analysis', desc: 'Upload documents, spreadsheets, and PDFs for instant insight.' },
    { icon: '🖼️', title: 'Image understanding', desc: 'Describe, analyze, and reason over images you share.' },
    { icon: '💻', title: 'Coding', desc: 'Write, debug, and refactor code across dozens of languages.' },
    { icon: '🔬', title: 'Research', desc: 'Synthesize information from multiple sources into clear answers.' },
    { icon: '📁', title: 'Projects', desc: 'Group conversations, files, and instructions into focused workspaces.' },
    { icon: '🧩', title: 'Memory', desc: 'Nexus remembers your preferences so every chat starts smarter.' },
  ];

  faqs = signal<FaqItem[]>([
    { q: 'Is there a free plan?', a: 'Yes — the Free plan gives you a generous number of messages every month with no credit card required.' },
    { q: 'Can I cancel anytime?', a: 'Absolutely. You can upgrade, downgrade, or cancel your subscription at any time from Settings → Billing.' },
    { q: 'Is my data private?', a: 'Your conversations are encrypted in transit and at rest. You control export and deletion from Settings → Privacy.' },
    { q: 'Which AI models are available?', a: 'Nexus offers Fast, Balanced, Reasoning, and Advanced models tuned for different kinds of tasks.' },
  ]);

  toggleFaq(index: number): void {
    this.faqs.update((list) => list.map((f, i) => (i === index ? { ...f, open: !f.open } : f)));
  }
}
