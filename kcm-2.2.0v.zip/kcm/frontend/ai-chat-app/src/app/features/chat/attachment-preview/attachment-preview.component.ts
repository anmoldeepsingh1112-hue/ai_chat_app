import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { Attachment } from '../../../core/models/attachment.model';
import { FileService } from '../../../core/services/file.service';

@Component({
  selector: 'app-attachment-preview',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './attachment-preview.component.html',
  styleUrl: './attachment-preview.component.scss',
})
export class AttachmentPreviewComponent {
  @Input({ required: true }) attachment!: Attachment;
  @Output() remove = new EventEmitter<string>();

  fileService = inject(FileService);

  get sizeLabel(): string {
    return this.fileService.formatSize(this.attachment.fileSizeBytes);
  }

  get extension(): string {
    return this.attachment.fileName.split('.').pop()?.toUpperCase() ?? 'FILE';
  }
}
