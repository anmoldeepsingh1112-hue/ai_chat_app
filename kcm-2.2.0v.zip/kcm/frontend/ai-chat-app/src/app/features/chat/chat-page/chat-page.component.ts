import { CommonModule } from '@angular/common';
import { Component, HostListener, computed, effect, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AiModelId } from '../../../core/models/conversation.model';
import { toApiError } from '../../../core/models/api.model';
import { Attachment } from '../../../core/models/attachment.model';
import { ConversationService } from '../../../core/services/conversation.service';
import { ChatService } from '../../../core/services/chat.service';
import { ChatMessageComponent } from '../chat-message/chat-message.component';
import { ChatComposerComponent } from '../chat-composer/chat-composer.component';
import { ContextDebugComponent } from '../context-debug/context-debug.component';

const SUGGESTIONS = [
  'Explain quantum mechanics',
  'Analyze a document',
  'Help me write code',
  'Research a topic',
  'Brainstorm an idea',
  'Explain this concept',
];

@Component({
  selector: 'app-chat-page',
  standalone: true,
  imports: [CommonModule, ChatMessageComponent, ChatComposerComponent, ContextDebugComponent],
  templateUrl: './chat-page.component.html',
  styleUrl: './chat-page.component.scss',
})
export class ChatPageComponent {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private conversationsSvc = inject(ConversationService);
  chat = inject(ChatService);

  suggestions = SUGGESTIONS;
  composerPrefill = signal('');

  conversationId = signal<string | null>(null);
  conversation = computed(() => {
    const id = this.conversationId();
    return id ? this.conversationsSvc.getById(id) : undefined;
  });
  messages = computed(() => {
    const id = this.conversationId();
    return id ? this.chat.messagesFor(id) : [];
  });
  model = computed<AiModelId>(() => this.conversation()?.model ?? 'balanced');
  isBusy = computed(() => this.chat.status() === 'thinking' || this.chat.status() === 'streaming');

  constructor() {
    this.route.paramMap.subscribe((params) => {
      const id = params.get('id');
      this.conversationId.set(id);
      // Load saved messages unless we already hold them (e.g. a stream that is in progress).
      if (id && this.chat.messagesByConversation()[id] === undefined) {
        this.chat.getConversation(id).subscribe({
          error: (e) => {
            const err = toApiError(e);
            if (err.code === 'CONVERSATION_NOT_FOUND') this.router.navigate(['/chat']);
            else this.chat.error.set(err.message);
          },
        });
      }
    });
  }

  /** Ctrl+Shift+D toggles the developer context panel (KCM 2.2). */
  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent): void {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd') {
      e.preventDefault();
      this.chat.toggleDevMode();
    }
  }

  useSuggestion(text: string): void {
    this.composerPrefill.set(text);
  }

  onModelChange(model: AiModelId): void {
    const id = this.conversationId();
    if (id) this.conversationsSvc.update(id, { model });
  }

  onSend(payload: { text: string; attachments: Attachment[] }): void {
    // Attachments are not supported by the KCM 2.1 backend yet; only the text is sent.
    const id = this.conversationId();
    if (id) {
      void this.chat.streamMessage(id, payload.text);
      this.composerPrefill.set('');
      return;
    }
    this.chat.createConversation(this.model()).subscribe({
      next: (conv) => {
        // streamMessage adds the messages synchronously, so navigate only after calling it.
        void this.chat.streamMessage(conv.id, payload.text);
        this.router.navigate(['/chat', conv.id]);
        this.composerPrefill.set('');
      },
      error: (e) => this.chat.error.set(toApiError(e).message),
    });
  }

  onRegenerate(messageId: string): void {
    const id = this.conversationId();
    if (id) this.chat.regenerate(id, messageId);
  }

  onLike(messageId: string): void {
    this.toggleReaction(messageId, 'liked');
  }

  onDislike(messageId: string): void {
    this.toggleReaction(messageId, 'disliked');
  }

  private toggleReaction(messageId: string, field: 'liked' | 'disliked'): void {
    const id = this.conversationId();
    if (!id) return;
    const msgs = this.chat.messagesByConversation();
    const list = msgs[id] ?? [];
    const updated = list.map((m) => (m.id === messageId ? { ...m, [field]: !m[field] } : m));
    this.chat.messagesByConversation.set({ ...msgs, [id]: updated });
  }
}
