import { CommonModule, DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ChatMessage } from '../../../core/models/message.model';
import { MarkdownPipe } from '../../../shared/pipes/markdown.pipe';
import { AvatarComponent } from '../../../shared/components/avatar/avatar.component';

@Component({
  selector: 'app-message',
  standalone: true,
  imports: [CommonModule, DatePipe, MarkdownPipe, AvatarComponent],
  templateUrl: './chat-message.component.html',
  styleUrl: './chat-message.component.scss',
})
export class ChatMessageComponent {
  @Input({ required: true }) message!: ChatMessage;
  @Input() userName = 'You';

  @Output() regenerate = new EventEmitter<string>();
  @Output() like = new EventEmitter<string>();
  @Output() dislike = new EventEmitter<string>();
  @Output() edit = new EventEmitter<string>();
  @Output() copy = new EventEmitter<string>();

  copied = false;

  onCopy(): void {
    navigator.clipboard?.writeText(this.message.content).catch(() => {});
    this.copied = true;
    setTimeout(() => (this.copied = false), 1500);
    this.copy.emit(this.message.id);
  }
}
