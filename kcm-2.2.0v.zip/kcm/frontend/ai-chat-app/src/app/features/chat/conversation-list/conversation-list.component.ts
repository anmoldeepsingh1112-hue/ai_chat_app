import { CommonModule, DatePipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Conversation } from '../../../core/models/conversation.model';

@Component({
  selector: 'app-conversation-list',
  standalone: true,
  imports: [CommonModule, DatePipe, RouterLink],
  template: `
    <div class="conv-list">
      <a *ngFor="let c of conversations" [routerLink]="['/chat', c.id]" class="conv-list__item">
        <span class="conv-list__title">{{ c.title }}</span>
        <time class="conv-list__date">{{ c.updatedAt | date: 'MMM d' }}</time>
      </a>
      <p class="conv-list__empty" *ngIf="!conversations.length">No conversations found.</p>
    </div>
  `,
  styleUrl: './conversation-list.component.scss',
})
export class ConversationListComponent {
  @Input() conversations: Conversation[] = [];
}
