import { CommonModule } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnChanges, Output, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AiModelId } from '../../../core/models/conversation.model';
import { Attachment } from '../../../core/models/attachment.model';
import { FileService } from '../../../core/services/file.service';
import { ToastService } from '../../../shared/components/toast/toast.component';
import { AutosizeDirective } from '../../../shared/directives/autosize.directive';
import { ModelSelectorComponent } from '../model-selector/model-selector.component';
import { AttachmentPreviewComponent } from '../attachment-preview/attachment-preview.component';

@Component({
  selector: 'app-chat-composer',
  standalone: true,
  imports: [CommonModule, FormsModule, AutosizeDirective, ModelSelectorComponent, AttachmentPreviewComponent],
  templateUrl: './chat-composer.component.html',
  styleUrl: './chat-composer.component.scss',
})
export class ChatComposerComponent implements OnChanges {
  @Input() model: AiModelId = 'balanced';
  @Input() disabled = false;
  @Input() prefill = '';
  @Output() modelChange = new EventEmitter<AiModelId>();
  @Output() send = new EventEmitter<{ text: string; attachments: Attachment[] }>();

  @ViewChild('textarea') textareaRef?: ElementRef<HTMLTextAreaElement>;
  @ViewChild('fileInput') fileInputRef?: ElementRef<HTMLInputElement>;

  text = signal('');
  attachments = signal<Attachment[]>([]);

  private fileService = inject(FileService);
  private toast = inject(ToastService);

  ngOnChanges(): void {
    if (this.prefill) this.text.set(this.prefill);
  }

  get canSend(): boolean {
    return !this.disabled && (this.text().trim().length > 0 || this.attachments().length > 0);
  }

  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submit();
    }
  }

  triggerFileInput(): void {
    this.fileInputRef?.nativeElement.click();
  }

  onFilesSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    for (const file of files) {
      const validation = this.fileService.validate(file);
      if (!validation.valid) {
        this.toast.show(validation.error ?? 'Invalid file', 'error');
        continue;
      }
      this.fileService.upload(file).subscribe({
        next: (att) => this.upsertAttachment(att),
        error: () => this.toast.show(`Failed to upload ${file.name}`, 'error'),
      });
    }
    input.value = '';
  }

  removeAttachment(id: string): void {
    this.attachments.update((list) => list.filter((a) => a.id !== id));
  }

  submit(): void {
    if (!this.canSend) return;
    this.send.emit({ text: this.text().trim(), attachments: this.attachments() });
    this.text.set('');
    this.attachments.set([]);
  }

  private upsertAttachment(att: Attachment): void {
    this.attachments.update((list) => {
      const idx = list.findIndex((a) => a.id === att.id);
      if (idx === -1) return [...list, att];
      const copy = [...list];
      copy[idx] = att;
      return copy;
    });
  }
}
