import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { ContextStats } from '../../../core/models/api.model';

/**
 * Developer-only readout of what KCM 2.2's context manager sent to the model for the last reply.
 * Rendered by ChatPageComponent only when developer mode is on (Ctrl+Shift+D) AND the backend runs
 * with DEV_MODE=true (otherwise the stats are simply absent). Normal users never see it.
 */
@Component({
  selector: 'app-context-debug',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="ctx" role="status" aria-label="Context debug">
      <div class="ctx__row">
        <span class="ctx__k">Context</span>
        <span>{{ stats.selected_tokens | number }} / {{ stats.context_limit | number }} tokens</span>
        <span class="ctx__muted" *ngIf="stats.original_tokens">(full history: {{ stats.original_tokens | number }})</span>
      </div>
      <div class="ctx__row">
        <span class="ctx__k">Messages</span>
        <span>{{ stats.messages_selected }} selected / {{ stats.messages_total }} total</span>
        <span class="ctx__muted">({{ stats.recent_messages }} recent, {{ stats.relevant_messages }} relevant)</span>
      </div>
      <div class="ctx__row">
        <span class="ctx__k">Summary</span>
        <span>{{ stats.summary_used ? 'Used (' + stats.summary_tokens + ' tokens)' : 'Not used' }}</span>
        <span class="ctx__k">Compression</span>
        <span>Level {{ stats.compression_level }}</span>
        <span class="ctx__muted" *ngIf="stats.build_ms !== null">{{ stats.build_ms }} ms</span>
      </div>
    </div>
  `,
  styles: [
    `
      .ctx { margin: 0 auto 8px; max-width: 760px; padding: 8px 12px; border-radius: var(--radius-lg);
        border: 1px dashed var(--border-subtle); background: var(--bg-surface); color: var(--text-secondary);
        font: 12px/1.6 ui-monospace, SFMono-Regular, Menlo, monospace; }
      .ctx__row { display: flex; flex-wrap: wrap; gap: 4px 12px; }
      .ctx__k { color: var(--accent); }
      .ctx__muted { opacity: 0.7; }
    `,
  ],
})
export class ContextDebugComponent {
  @Input({ required: true }) stats!: ContextStats;
}
