import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { AiModelId } from '../../../core/models/conversation.model';
import { AI_MODELS } from '../../../core/services/chat.service';

@Component({
  selector: 'app-model-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './model-selector.component.html',
  styleUrl: './model-selector.component.scss',
})
export class ModelSelectorComponent {
  @Input() selected: AiModelId = 'balanced';
  @Output() selectedChange = new EventEmitter<AiModelId>();

  models = AI_MODELS;
  open = signal(false);

  get selectedModel() {
    return this.models.find((m) => m.id === this.selected) ?? this.models[1];
  }

  choose(id: AiModelId): void {
    this.selectedChange.emit(id);
    this.open.set(false);
  }
}
