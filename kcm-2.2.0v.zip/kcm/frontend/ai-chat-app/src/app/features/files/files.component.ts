import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { Attachment } from '../../core/models/attachment.model';
import { FileService } from '../../core/services/file.service';
import { ToastService } from '../../shared/components/toast/toast.component';
import { AttachmentPreviewComponent } from '../chat/attachment-preview/attachment-preview.component';

@Component({
  selector: 'app-files',
  standalone: true,
  imports: [CommonModule, AttachmentPreviewComponent],
  templateUrl: './files.component.html',
  styleUrl: './files.component.scss',
})
export class FilesComponent {
  fileService = inject(FileService);
  private toast = inject(ToastService);

  files = signal<Attachment[]>([]);

  onFilesSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const selected = input.files ? Array.from(input.files) : [];
    for (const file of selected) {
      const validation = this.fileService.validate(file);
      if (!validation.valid) {
        this.toast.show(validation.error ?? 'Invalid file', 'error');
        continue;
      }
      this.fileService.upload(file).subscribe((att) => this.upsert(att));
    }
    input.value = '';
  }

  remove(id: string): void {
    this.files.update((list) => list.filter((f) => f.id !== id));
  }

  private upsert(att: Attachment): void {
    this.files.update((list) => {
      const idx = list.findIndex((f) => f.id === att.id);
      if (idx === -1) return [...list, att];
      const copy = [...list];
      copy[idx] = att;
      return copy;
    });
  }
}
